{
    'name': 'Ramsha Invoice (ARETX)',
    'version': '19.0.1.1.0',
    'category': 'Accounting',
    'summary': 'Show POS receipt header address on customer invoice',
    'depends': ['account', 'point_of_sale', 'web'],
    'data': [
        'views/report_templates.xml',
        'views/invoice_report.xml',
        ],
    'license': 'LGPL-3',
    'installable': True,
    'application': True,
}