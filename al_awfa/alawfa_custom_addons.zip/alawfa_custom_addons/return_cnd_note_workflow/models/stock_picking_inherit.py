from odoo import models, fields
from odoo.exceptions import UserError
from collections import defaultdict

class StockPicking(models.Model):
    _inherit = 'stock.picking'

    is_return = fields.Boolean(compute='_compute_is_return')

    def _compute_is_return(self):
        for rec in self:
            rec.is_return = any(m.origin_returned_move_id for m in rec.move_ids)

    credit_debit_count = fields.Integer(
        compute="_compute_credit_debit_count"
    )

    def _compute_credit_debit_count(self):
        for rec in self:
            rec.credit_debit_count = self.env['account.move'].search_count([
                ('return_picking_id', '=', rec.id)
            ])

    def action_view_credit_debit_notes(self):
        self.ensure_one()

        notes = self.env['account.move'].search([
            ('return_picking_id', '=', self.id)
        ])

        return {
            'name': 'Credit/Debit Notes',
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'tree,form',
            'domain': [('id', 'in', notes.ids)],
            'context': {'create': False},
        }

    # def action_open_reversal_wizard_1(self):
    #     self.ensure_one()
    # #
    # #     # Get linked invoice (you said it's already attached)
    # #     # invoice = self.env['account.move'].search([
    # #     #     ('invoice_origin', '=', self.origin),
    # #     #     ('state', '=', 'posted'),
    # #     #     ('move_type', 'in', ['out_invoice', 'in_invoice'])
    # #     # ], limit=1)
    # #
    # #     sale = self.sale_id
    # #     purchase = self.purchase_id
    # #     invoice = self.env['account.move'].search([
    # #         ('invoice_origin', '=', sale.name),
    # #         ('move_type', '=', 'out_invoice'),
    # #     ],
    # #     limit=1)
    # #
    # #     bill = self.env['account.move'].search([('invoice_origin', '=', purchase.name),
    # #         ('move_type', '=', 'in_invoice'),])
    # #
    # #     if not invoice and not bill:
    # #         raise UserError("No posted invoice/bill found for this return.")
    # #
    # #     return {
    # #         'name': 'Create Credit/Debit Note',
    # #         'type': 'ir.actions.act_window',
    # #         'res_model': 'account.move.reversal',
    # #         'view_mode': 'form',
    # #         'target': 'new',
    # #         'context': {
    # #             'active_model': 'account.move',
    # #             'active_ids': [invoice.id],
    # #
    # #             # optional defaults
    # #             'default_reason': f"Return of {self.name}",
    # #             'default_refund_method': 'refund',  # partial/full options handled in wizard
    # #         }
    # #     }
    #
    #     invoice = False
    #
    #     # 🔹 Sales Flow → Customer Invoice → Credit Note
    #     if self.sale_id:
    #         invoice = self.env['account.move'].search([
    #             ('invoice_origin', '=', self.sale_id.name),
    #             ('move_type', '=', 'out_invoice'),
    #             ('state', '=', 'posted')
    #         ], limit=1)
    #
    #     # 🔹 Purchase Flow → Vendor Bill → Debit Note
    #     elif self.purchase_id:
    #         invoice = self.env['account.move'].search([
    #             ('invoice_origin', '=', self.purchase_id.name),
    #             ('move_type', '=', 'in_invoice'),
    #             ('state', '=', 'posted')
    #         ], limit=1)
    #
    #     if not invoice:
    #         raise UserError("No posted invoice/bill found for this return.")
    #
    #     return {
    #         'name': 'Create Credit/Debit Note',
    #         'type': 'ir.actions.act_window',
    #         'res_model': 'account.move.reversal',
    #         'view_mode': 'form',
    #         'target': 'new',
    #         'context': {
    #             'active_model': 'account.move',
    #             'active_ids': invoice.ids,  # ✅ works for both
    #
    #             'default_reason': f"Return of {self.name}",
    #             'default_refund_method': 'refund',
    #         }
    #     }
    #
    # def action_open_reversal_wizard(self):
    #     self.ensure_one()
    #     print("credit note new one")
    #     invoice = False
    #
    #     if self.sale_id:
    #         invoice = self.env['account.move'].search([
    #             ('invoice_origin', '=', self.sale_id.name),
    #             ('move_type', '=', 'out_invoice'),
    #             ('state', '=', 'posted')
    #         ], limit=1)
    #
    #     elif self.purchase_id:
    #         invoice = self.env['account.move'].search([
    #             ('invoice_origin', '=', self.purchase_id.name),
    #             ('move_type', '=', 'in_invoice'),
    #             ('state', '=', 'posted')
    #         ], limit=1)
    #
    #     if not invoice:
    #         raise UserError("No posted invoice/bill found for this return.")
    #
    #     return {
    #         'name': 'Create Credit/Debit Note',
    #         'type': 'ir.actions.act_window',
    #         'res_model': 'account.move.reversal',
    #         'view_mode': 'form',
    #         'target': 'new',
    #         'context': {
    #             'active_model': 'account.move',
    #             'active_ids': invoice.ids,
    #
    #             'default_reason': f"Return of {self.name}",
    #             'default_refund_method': 'refund',
    #
    #             # 🔥 REQUIRED
    #             'from_return_picking_id': self.id,
    #         }
    #     }

    # def action_create_debit_credit_note_1(self):
    #     self.ensure_one()
    #
    #     if self.state != 'done':
    #         raise UserError("Return must be validated first.")
    #
    #     invoice = False
    #     move_type = False
    #
    #     # SALES → Credit Note
    #     if self.sale_id:
    #         invoice = self.env['account.move'].search([
    #             ('invoice_origin', '=', self.sale_id.name),
    #             ('move_type', '=', 'out_invoice'),
    #             ('state', '=', 'posted')
    #         ], limit=1)
    #         move_type = 'out_refund'
    #
    #     # PURCHASE → Debit Note
    #     elif self.purchase_id:
    #         invoice = self.env['account.move'].search([
    #             ('invoice_origin', '=', self.purchase_id.name),
    #             ('move_type', '=', 'in_invoice'),
    #             ('state', '=', 'posted')
    #         ], limit=1)
    #         move_type = 'in_refund'
    #
    #     if not invoice:
    #         raise UserError("No posted invoice/bill found.")
    #
    #     # 🔥 Create note header
    #     new_move = self.env['account.move'].create({
    #         'move_type': move_type,
    #         'partner_id': invoice.partner_id.id,
    #         'invoice_origin': invoice.name,
    #         'ref': f"Return of {self.name}",
    #         'invoice_date': fields.Date.today(),
    #         'invoice_line_ids': [],
    #     })
    #
    #     # 🔹 Build invoice line map (for price lookup)
    #     price_map = {}
    #
    #     for line in invoice.invoice_line_ids:
    #         key = (
    #             line.product_id.id,
    #             line.price_unit,
    #             tuple(sorted(line.tax_ids.ids))
    #         )
    #         price_map.setdefault(line.product_id.id, []).append(line)
    #
    #     # 🔹 Create lines from return
    #     for move in self.move_ids:
    #         if not move.quantity:
    #             continue
    #
    #         product = move.product_id
    #         qty = move.quantity
    #
    #         # 🔥 Find matching invoice line (for price)
    #         inv_lines = price_map.get(product.id)
    #
    #         if not inv_lines:
    #             continue  # or raise error
    #
    #         inv_line = inv_lines[0]  # simple case (can improve later)
    #
    #         self.env['account.move.line'].create({
    #             'move_id': new_move.id,
    #             'product_id': product.id,
    #             'name': inv_line.name,
    #             'quantity': qty,
    #             'price_unit': inv_line.price_unit,
    #             'tax_ids': [(6, 0, inv_line.tax_ids.ids)],
    #             'account_id': inv_line.account_id.id,
    #         })
    #
    #     return {
    #         'type': 'ir.actions.act_window',
    #         'res_model': 'account.move',
    #         'view_mode': 'form',
    #         'res_id': new_move.id,
    #     }


    def action_create_debit_credit_note(self):
        self.ensure_one()
        print("Create Credit/Debit Note final")
        if self.state != 'done':
            raise UserError("Return must be validated first.")

        invoice = False
        move_type = False

        # 🔹 Identify invoice
        if self.sale_id:
            invoice = self.env['account.move'].search([
                ('invoice_origin', '=', self.sale_id.name),
                ('move_type', '=', 'out_invoice'),
                ('state', '=', 'posted')
            ])
            move_type = 'out_refund'

        elif self.purchase_id:
            invoice = self.env['account.move'].search([
                ('invoice_origin', '=', self.purchase_id.name),
                ('move_type', '=', 'in_invoice'),
                ('state', '=', 'posted')
            ])
            move_type = 'in_refund'

        if not invoice:
            raise UserError("No posted invoice/bill found.")

        # 🔥 Step 1: Build returned qty per invoice line
        returned_map = defaultdict(float)

        for move in self.move_ids:
            qty = sum(move.move_line_ids.mapped('quantity'))
            if not qty:
                continue

            # SALES FLOW
            if move.sale_line_id:
                sol = move.sale_line_id

                inv_lines = invoice.mapped('invoice_line_ids').filtered(
                    lambda l: sol in l.sale_line_ids
                )

                if not inv_lines:
                    continue

                # 🔥 distribute qty properly if multiple lines
                qty_per_line = qty / len(inv_lines)

                for line in inv_lines:
                    returned_map[line.id] += qty_per_line

            # PURCHASE FLOW
            elif move.purchase_line_id:
                pol = move.purchase_line_id

                inv_lines = invoice.mapped('invoice_line_ids').filtered(
                    lambda l: l.purchase_line_id == pol
                )

                if not inv_lines:
                    continue

                qty_per_line = qty / len(inv_lines)

                for line in inv_lines:
                    returned_map[line.id] += qty_per_line

        # 🔥 Step 2: Create Credit/Debit Note
        new_move = self.env['account.move'].create({
            'move_type': move_type,
            'partner_id': invoice[0].partner_id.id,
            'invoice_origin': ', '.join(invoice.mapped('name')),
            'ref': f"Return of {self.name}",
            'invoice_date': fields.Date.today(),
            'return_picking_id': self.id,
        })

        # 🔥 Step 3: Create lines EXACTLY from invoice lines
        for inv_line_id, qty in returned_map.items():
            if not qty:
                continue

            inv_line = self.env['account.move.line'].browse(inv_line_id)

            self.env['account.move.line'].create({
                'move_id': new_move.id,
                'product_id': inv_line.product_id.id,
                'name': inv_line.name,
                'quantity': qty,
                'price_unit': inv_line.price_unit,
                'discount': inv_line.discount,
                'tax_ids': [(6, 0, inv_line.tax_ids.ids)],
                'account_id': inv_line.account_id.id,
            })

        if not new_move.invoice_line_ids:
            raise UserError("No matching invoice lines found for returned products.")

        return {
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'form',
            'res_id': new_move.id,
        }