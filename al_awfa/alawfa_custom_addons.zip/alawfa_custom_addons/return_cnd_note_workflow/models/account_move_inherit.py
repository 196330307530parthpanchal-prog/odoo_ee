from odoo import models,fields,api
from num2words import num2words

class AccountMove(models.Model):
    _inherit = 'account.move'

    return_picking_id = fields.Many2one(
        'stock.picking',
        string="Return Picking",
        index=True
    )

    amount_in_words = fields.Char(string="Amount in Words", compute="compute_amount_in_words")

    @api.depends('amount_residual', 'currency_id')
    def compute_amount_in_words(self):
        print('why am i running')
        for record in self:
            if record.currency_id:
                lang = record.env.user.lang or 'en'
                try:
                    print(record.amount_residual)
                    record.amount_in_words = num2words(
                        record.amount_residual,
                        lang=lang
                    ).title() + " " + record.currency_id.name
                    print(record.amount_in_words)
                except:
                    record.amount_in_words = ""

    def get_amount_in_words(self, amount, currency):
        return currency.amount_to_text(amount)
