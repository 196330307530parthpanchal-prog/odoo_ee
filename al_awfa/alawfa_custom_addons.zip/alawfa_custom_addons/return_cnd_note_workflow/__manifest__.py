{
"name": "Stock Return Credit/Debit Note",
"version": "17.0.1.0.0",
"summary": "Create Credit/Debit Notes from Return Pickings",
"description": """
This module adds a button on return pickings to generate Credit Notes (Sales)
and Debit Notes (Purchases) using Odoo's native reversal mechanism.

Key Features:

* Button on return picking form
* Opens standard Credit/Debit Note wizard
* Supports both Sales and Purchase flows
* Ensures linkage with original invoice/bill
* No custom accounting logic (uses Odoo core)
  """,
  "author": "Your Company",
  "website": "https://yourcompany.com",
  "category": "Inventory/Accounting",
  "license": "LGPL-3",
  "depends": [
  "stock",
  "account",
  "sale_management",
  "purchase"
  ],
  "data": [
  "views/stock_picking_views.xml",
  "views/account_move_template.xml",
  ],
  "installable": True,
  "application": False,
  "auto_install": False,
  }
