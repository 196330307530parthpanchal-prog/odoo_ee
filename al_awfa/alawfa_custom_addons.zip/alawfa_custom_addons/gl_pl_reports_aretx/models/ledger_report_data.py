from odoo import api, models

import logging
_logger = logging.getLogger(__name__)

# Same page size Odoo's own account_reports uses for "Load more"
GL_PAGE_SIZE = 80


class LedgerReportData(models.AbstractModel):
    """Server-side data layer for the custom ledgers.

    Odoo's own reports never pull journal items into the browser. They
      1. aggregate totals / opening balances in SQL (one grouped query),
      2. fetch the lines of a group only when it is expanded,
      3. fetch them one page at a time ("Load more").
    This model gives the General Ledger the same behaviour.
    """
    _name = 'gl.pl.ledger.data'
    _description = 'Ledger report data (server-side aggregation)'

    # ------------------------------------------------------------------
    # helpers
    # ------------------------------------------------------------------
    @api.model
    def _base_params(self, date_from, date_to, account_id, account_ids):
        self.env['account.move.line'].check_access_rights('read')
        return {
            'cids': tuple(self.env.companies.ids) or (0,),
            'df': date_from or None,
            'dt': date_to or None,
            'acc': int(account_id) if account_id else None,
            'accs': list(account_ids) if account_ids is not None else None,
        }

    _ACCOUNT_FILTER = """
        AND (%(acc)s::int IS NULL OR aml.account_id = %(acc)s::int)
        AND (%(accs)s::int[] IS NULL OR aml.account_id = ANY(%(accs)s::int[]))
    """

    # ------------------------------------------------------------------
    # 1. totals + opening balance per account  (one SQL query, no lines)
    # ------------------------------------------------------------------
    @api.model
    def get_gl_summary(self, date_from=None, date_to=None, account_id=False,
                       account_ids=None):
        params = self._base_params(date_from, date_to, account_id, account_ids)
        query = """
            SELECT aml.account_id,
                   COALESCE(SUM(aml.debit)  FILTER (WHERE %(df)s::date IS NOT NULL
                            AND aml.date < %(df)s::date
                            AND (aa.deprecated IS NOT TRUE OR %(acc)s::int IS NOT NULL)), 0) AS open_debit,
                   COALESCE(SUM(aml.credit) FILTER (WHERE %(df)s::date IS NOT NULL
                            AND aml.date < %(df)s::date
                            AND (aa.deprecated IS NOT TRUE OR %(acc)s::int IS NOT NULL)), 0) AS open_credit,
                   COALESCE(SUM(aml.debit)  FILTER (WHERE (%(df)s::date IS NULL OR aml.date >= %(df)s::date)), 0) AS per_debit,
                   COALESCE(SUM(aml.credit) FILTER (WHERE (%(df)s::date IS NULL OR aml.date >= %(df)s::date)), 0) AS per_credit,
                   COUNT(*) FILTER (WHERE (%(df)s::date IS NULL OR aml.date >= %(df)s::date)
                            AND (aml.debit <> 0 OR aml.credit <> 0 OR aml.balance <> 0)) AS line_count
              FROM account_move_line aml
              JOIN account_account aa ON aa.id = aml.account_id
             WHERE aml.parent_state = 'posted'
               AND aml.company_id IN %(cids)s
               AND (%(dt)s::date IS NULL OR aml.date <= %(dt)s::date)
        """ + self._ACCOUNT_FILTER + """
          GROUP BY aml.account_id
          ORDER BY aml.account_id
        """
        self.env.cr.execute(query, params)
        rows = self.env.cr.dictfetchall()

        rows = [
            r for r in rows
            if r['line_count'] or r['open_debit'] or r['open_credit']
        ]
        accounts = self.env['account.account'].browse([r['account_id'] for r in rows])
        names = {a.id: a.display_name for a in accounts}

        result, tot_d, tot_c = [], 0.0, 0.0
        for r in rows:
            debit = r['open_debit'] + r['per_debit']
            credit = r['open_credit'] + r['per_credit']
            tot_d += debit
            tot_c += credit
            result.append({
                'id': r['account_id'],
                'name': names.get(r['account_id'], ''),
                'debit': debit,
                'credit': credit,
                'balance': debit - credit,
                'opening_debit': r['open_debit'],
                'opening_credit': r['open_credit'],
                'line_count': r['line_count'],
            })
        return {
            'accounts': result,
            'totals': {'debit': tot_d, 'credit': tot_c, 'balance': tot_d - tot_c},
            'page_size': GL_PAGE_SIZE,
        }

    # ------------------------------------------------------------------
    # 2. one page of lines of ONE account (running balance in SQL)
    # ------------------------------------------------------------------
    @api.model
    def get_gl_lines(self, account_id, date_from=None, date_to=None,
                     offset=0, limit=GL_PAGE_SIZE, descending=False):
        params = self._base_params(date_from, date_to, account_id, None)
        params.update({'offset': int(offset or 0),
                       'limit': int(limit) if limit else None})
        direction = 'DESC' if descending else 'ASC'
        query = """
            WITH opening AS (
                SELECT COALESCE(SUM(aml.debit - aml.credit), 0) AS amount
                  FROM account_move_line aml
                 WHERE aml.parent_state = 'posted'
                   AND aml.company_id IN %(cids)s
                   AND aml.account_id = %(acc)s::int
                   AND %(df)s::date IS NOT NULL
                   AND aml.date < %(df)s::date
            ), ordered AS (
                SELECT aml.id, aml.move_id, aml.move_name, aml.date, aml.name,
                       aml.partner_id, aml.currency_id, aml.amount_currency,
                       aml.debit, aml.credit,
                       (SELECT amount FROM opening)
                         + SUM(aml.debit - aml.credit)
                           OVER (ORDER BY aml.date, aml.move_name, aml.id) AS running
                  FROM account_move_line aml
                 WHERE aml.parent_state = 'posted'
                   AND aml.company_id IN %(cids)s
                   AND aml.account_id = %(acc)s::int
                   AND (%(df)s::date IS NULL OR aml.date >= %(df)s::date)
                   AND (%(dt)s::date IS NULL OR aml.date <= %(dt)s::date)
                   AND (aml.debit <> 0 OR aml.credit <> 0 OR aml.balance <> 0)
            )
            SELECT * FROM ordered
             ORDER BY date """ + direction + """, move_name """ + direction + """, id """ + direction + """
            LIMIT %(limit)s OFFSET %(offset)s
        """
        self.env.cr.execute(query, params)
        rows = self.env.cr.dictfetchall()

        partners = self.env['res.partner'].browse(
            list({r['partner_id'] for r in rows if r['partner_id']}))
        pnames = {p.id: p.display_name for p in partners}
        currencies = self.env['res.currency'].browse(
            list({r['currency_id'] for r in rows if r['currency_id']}))
        cmap = {c.id: (c.name, c.symbol) for c in currencies}
        company_symbol = self.env.company.currency_id.symbol

        lines = []
        for r in rows:
            cur = cmap.get(r['currency_id'])
            lines.append({
                'id': r['id'],
                'move_id': [r['move_id'], r['move_name'] or ''],
                'move_name': r['move_name'] or '',
                'date': str(r['date']) if r['date'] else False,
                'name': r['name'] or '',
                'partner_id': [r['partner_id'], pnames.get(r['partner_id'], '')]
                              if r['partner_id'] else False,
                'account_id': [account_id, ''],
                'currency_id': [r['currency_id'], cur[0]] if cur else False,
                'currency_symbol': (cur[1] or cur[0]) if cur else company_symbol,
                'amount_currency': r['amount_currency'],
                'debit': r['debit'],
                'credit': r['credit'],
                'balance': r['running'],   # running balance, same meaning as before
            })
        return lines

    # ==================================================================
    # PARTNER LEDGER  (same approach: SQL totals, lazy paged lines)
    # ==================================================================
    @api.model
    def _pl_types(self, account_type):
        if account_type == 'receivable':
            return ['asset_receivable']
        if account_type == 'payable':
            return ['liability_payable']
        return ['asset_receivable', 'liability_payable']

    @api.model
    def _pl_params(self, date_from, date_to, account_type, account_id):
        self.env['account.move.line'].check_access_rights('read')
        return {
            'cids': tuple(self.env.companies.ids) or (0,),
            'df': date_from or None,
            'dt': date_to or None,
            'types': self._pl_types(account_type),
            'acc': int(account_id) if account_id else None,
        }

    @api.model
    def get_partner_summary(self, date_from=None, date_to=None,
                            account_type='all', account_id=False,
                            search_text=''):
        """One row per partner: period debit/credit, opening balance, line
        count. No journal line is sent to the browser."""
        params = self._pl_params(date_from, date_to, account_type, account_id)
        period = "(%(df)s::date IS NULL OR aml.date >= %(df)s::date) " \
                 "AND (%(acc)s::int IS NULL OR aml.account_id = %(acc)s::int)"
        query = """
            SELECT aml.partner_id,
                   COALESCE(SUM(aml.balance) FILTER (WHERE %(df)s::date IS NOT NULL
                            AND aml.date < %(df)s::date), 0) AS open_balance,
                   COALESCE(SUM(aml.debit)   FILTER (WHERE """ + period + """), 0) AS per_debit,
                   COALESCE(SUM(aml.credit)  FILTER (WHERE """ + period + """), 0) AS per_credit,
                   COALESCE(SUM(aml.balance) FILTER (WHERE """ + period + """), 0) AS per_balance,
                   COUNT(*) FILTER (WHERE """ + period + """
                            AND (aml.debit <> 0 OR aml.credit <> 0 OR aml.balance <> 0)) AS line_count
              FROM account_move_line aml
                  JOIN account_account aa ON aa.id = aml.account_id
             WHERE aml.parent_state = 'posted'
               AND aml.company_id IN %(cids)s
               AND aml.partner_id IS NOT NULL
               AND aa.account_type = ANY(%(types)s)
               AND (%(dt)s::date IS NULL OR aml.date <= %(dt)s::date)
          GROUP BY aml.partner_id
        """
        self.env.cr.execute(query, params)
        rows = [r for r in self.env.cr.dictfetchall()
                if r['line_count'] or r['open_balance']]

        partners = self.env['res.partner'].browse([r['partner_id'] for r in rows])
        names = {p.id: p.display_name for p in partners}

        # same partner name -> one group (as the screen always did)
        words = (search_text or '').lower().split()
        groups = {}
        for r in rows:
            name = names.get(r['partner_id'], '')
            if words and not all(w in name.lower() for w in words):
                continue
            g = groups.setdefault(name, {
                'partner_name': name, 'partner_ids': [],
                'debit': 0.0, 'credit': 0.0, 'balance': 0.0,
                'opening_balance': 0.0, 'line_count': 0,
            })
            g['partner_ids'].append(r['partner_id'])
            g['debit'] += r['per_debit']
            g['credit'] += r['per_credit']
            g['balance'] += r['open_balance'] + r['per_balance']
            g['opening_balance'] += r['open_balance']
            g['line_count'] += r['line_count']

        result = sorted(groups.values(), key=lambda g: g['partner_name'].lower())
        totals = {
            'debit': sum(g['debit'] for g in result),
            'credit': sum(g['credit'] for g in result),
            'balance': sum(g['balance'] for g in result),
        }
        return {'partners': result, 'totals': totals, 'page_size': GL_PAGE_SIZE}

    @api.model
    def get_partner_lines(self, partner_ids, date_from=None, date_to=None,
                          account_type='all', account_id=False,
                          offset=0, limit=GL_PAGE_SIZE, descending=False):
        params = self._pl_params(date_from, date_to, account_type, account_id)
        params.update({
            'pids': [int(i) for i in partner_ids],
            'offset': int(offset or 0),
            'limit': int(limit) if limit else None,
        })
        direction = 'DESC' if descending else 'ASC'
        query = """
            WITH opening AS (
                SELECT COALESCE(SUM(aml.balance), 0) AS amount
                  FROM account_move_line aml
                  JOIN account_account aa ON aa.id = aml.account_id
                 WHERE aml.parent_state = 'posted'
                   AND aml.company_id IN %(cids)s
                   AND aml.partner_id = ANY(%(pids)s::int[])
                   AND aa.account_type = ANY(%(types)s)
                   AND %(df)s::date IS NOT NULL
                   AND aml.date < %(df)s::date
            ), ordered AS (
                SELECT aml.id, aml.move_id, aml.move_name, aml.date, aml.date_maturity,
                       aml.name, aml.partner_id, aml.account_id, aa.account_type,
                       aml.currency_id, aml.amount_currency, aml.debit, aml.credit,
                       (SELECT amount FROM opening)
                         + SUM(aml.debit - aml.credit)
                           OVER (ORDER BY aml.date, aml.id) AS running
                  FROM account_move_line aml
                  JOIN account_account aa ON aa.id = aml.account_id
                 WHERE aml.parent_state = 'posted'
                   AND aml.company_id IN %(cids)s
                   AND aml.partner_id = ANY(%(pids)s::int[])
                   AND aa.account_type = ANY(%(types)s)
                   AND (%(df)s::date IS NULL OR aml.date >= %(df)s::date)
                   AND (%(dt)s::date IS NULL OR aml.date <= %(dt)s::date)
                   AND (%(acc)s::int IS NULL OR aml.account_id = %(acc)s::int)
                   AND (aml.debit <> 0 OR aml.credit <> 0 OR aml.balance <> 0)
            )
            SELECT * FROM ordered
             ORDER BY date """ + direction + """, id """ + direction + """
            LIMIT %(limit)s OFFSET %(offset)s
        """
        self.env.cr.execute(query, params)
        rows = self.env.cr.dictfetchall()

        partners = self.env['res.partner'].browse(
            list({r['partner_id'] for r in rows}))
        pnames = {p.id: p.display_name for p in partners}
        accounts = self.env['account.account'].browse(
            list({r['account_id'] for r in rows}))
        anames = {a.id: a.display_name for a in accounts}
        currencies = self.env['res.currency'].browse(
            list({r['currency_id'] for r in rows if r['currency_id']}))
        cmap = {c.id: (c.name, c.symbol) for c in currencies}
        company_symbol = self.env.company.currency_id.symbol

        lines = []
        for r in rows:
            cur = cmap.get(r['currency_id'])
            lines.append({
                'id': r['id'],
                'move_id': [r['move_id'], r['move_name'] or ''],
                'move_name': r['move_name'] or '',
                'date': str(r['date']) if r['date'] else False,
                'date_maturity': str(r['date_maturity']) if r['date_maturity'] else False,
                'name': r['name'] or '',
                'partner_id': [r['partner_id'], pnames.get(r['partner_id'], '')],
                'account_id': [r['account_id'], anames.get(r['account_id'], '')],
                'account_type': r['account_type'],
                'currency_id': [r['currency_id'], cur[0]] if cur else False,
                'currency_symbol': (cur[1] or cur[0]) if cur else company_symbol,
                'amount_currency': r['amount_currency'],
                'debit': r['debit'],
                'credit': r['credit'],
                'balance': r['running'],
            })
        return lines