/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState, onWillStart, onMounted, useRef } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

const configModel = 'general.ledger.report.config';

export class GeneralLedgerReport extends Component {
    setup() {
        this.state = useState({
            ledgerData: [],
            groupedData: {},
            dateFrom: "",
            dateTo: "",
            selectedAccount: "",
            selectedYear: new Date().getFullYear(),
            availableYears: Array.from(
                { length: 100 },
                (_, i) => new Date().getFullYear() - i
            ),
            accounts: [],
            totals: {
                debit: 0,
                credit: 0,
                balance: 0
            },
            collapsedAccounts: {},
            visibleLinesCount: {},
            fyDates: null,
            isDebug: Boolean(odoo.debug),
            companyCurrency: { id: false, name: '', symbol: '' },
            searchAccountIds: null, // ids of the accounts matched by the search box (null = no search)
            sortDirection: 'asc', // added for date sorting     
            config: {
                show_journal: true,
                show_date: true,
                show_communication: true,
                show_partner: true,
                show_currency: true,
                show_debit: true,
                show_credit: true,
                show_balance: true,
            },
        });

        this.ui = useService("ui");
        this.orm = useService("orm");
        // P&L Account Navigation Context
        const ctx = this.props.action?.context || {};

        this.plAccountId =
            ctx.profit_loss_account_id || false;

        this.plDateFrom =
            ctx.profit_loss_date_from || false;

        this.plDateTo =
            ctx.profit_loss_date_to || false;

        this.dateFromRef = useRef("date-from");
        this.dateToRef = useRef("date-to");
        this.accountRef = useRef("account-filter");
        this.searchInput = useRef("search-input");

        onWillStart(async () => {
            await this.loadCompanyCurrency();
            await this.loadConfig();
            await this.loadAccounts();
            await this.initializeFinancialYearDates();
        
            if (this.plAccountId) {

                this.state.selectedAccount =
                    String(this.plAccountId);
            
            }
            
            if (this.plDateFrom) {
            
                this.state.dateFrom =
                    this.plDateFrom;
            
            }
            
            if (this.plDateTo) {
            
                this.state.dateTo =
                    this.plDateTo;
            
            }

            if (this.plDateFrom || this.plDateTo) {
                this.state.dateType = 'Custom';
            }
        
            await this.loadLedgerData();
        });

        onMounted(() => {
            // Set date picker values after DOM is ready
            if (this.state.fyDates) {
                if (this.dateFromRef.el) {
                    this.dateFromRef.el.value = this.state.fyDates.start;
                }
                if (this.dateToRef.el) {
                    this.dateToRef.el.value = this.state.fyDates.end;
                }
            }
            // When page loads again, restores to which accounts were open/closed
            // Rows stay open only when coming back from a drill-down (journal entry /
            // ledger); opening the report any other way always starts collapsed.
            const restoreUntil = parseInt(localStorage.getItem("general_ledger_restore_until") || "0");
            localStorage.removeItem("general_ledger_restore_until");
            const shouldRestore = restoreUntil > Date.now();

            const savedCollapsed = shouldRestore
                ? localStorage.getItem("general_ledger_collapsed_accounts")
                : null;

            if (savedCollapsed) {
                this.state.collapsedAccounts =
                    JSON.parse(savedCollapsed);
                this.loadOpenAccounts();
            }

            const savedScroll = shouldRestore
                ? localStorage.getItem("general_ledger_scroll")
                : null;

            if (savedScroll) {
                setTimeout(() => {
                    requestAnimationFrame(() => {

                        const content =
                            document.querySelector('.o_content');
                        if (content) {
                        
                        content.scrollTop =
                                parseInt(savedScroll);
                        }
            
                    });
            
                }, 500);
            }
                    });
                
                    this.action = useService("action");

                    
                }

    async sortByDate() {

        // Toggle asc/desc
        this.state.sortDirection =
            this.state.sortDirection === 'asc'
                ? 'desc'
                : 'asc';

        // Re-fetch the first page of every open account in the new order
        for (const group of Object.values(this.state.groupedData)) {
            group.fetched = [];
            group.loaded = false;
            group.lines = [];
        }
        await this.loadOpenAccounts();
    }

    goToHome() {
        // Like a website's home button: forget the saved open/closed rows and the
        // scroll position, then reload so filters, dates and search start fresh.
        localStorage.removeItem("general_ledger_collapsed_accounts");
        localStorage.removeItem("general_ledger_scroll");
        localStorage.removeItem("general_ledger_restore_until");
        window.location.reload();
    }

    reloadPage() {
        window.location.reload();
    }

    async loadConfig() {
        if (!this.state.isDebug) {
            return;
        }
        try {
            const configRecord = await this.orm.call(
                configModel,
                'get_active_config',
                []
            );

            // Assuming configRecord contains fields like show_journal, etc.
            if (configRecord) {
                this.state.config = {
                    show_journal: configRecord.show_journal,
                    show_date: configRecord.show_date,
                    show_communication: configRecord.show_communication,
                    show_partner: configRecord.show_partner,
                    show_currency: configRecord.show_currency,
                    show_debit: configRecord.show_debit,
                    show_credit: configRecord.show_credit,
                    show_balance: configRecord.show_balance,
                };
                await this.loadLedgerData();
            }
        } catch (error) {
            console.error("Failed to load General Ledger Configuration:", error);
            // Default config is used
        }
    }

    openDebugConfig = async function () {
        try {
            // 1. Call the Python method to get the active (and initialized) config record.
            const configRecord = await this.orm.call(
                configModel,
                'get_active_config',
                [] // No arguments for the @api.model method
            );

            // The ORM call returns the ID of the record.
            const configId = configRecord.id;

            // 2. Open the form view for the retrieved record ID.
            await this.action.doAction({
                type: "ir.actions.act_window",
                res_model: configModel,
                res_id: configId, // Pass the specific record ID
                view_mode: "form",
                target: "new",
                views: [[false, "form"]],
                name: "General Ledger Configuration",
                onClose: async () => {
                    console.log("CONFIG CLOSED");
                    await this.loadConfig();
                    window.location.reload();
                },
            });

        

        } catch (error) {
            console.error("Failed to retrieve or initialize General Ledger Configuration:", error);
            // Optionally show a user-facing notification about the error
            this.env.services.notification.add(
                "Could not load the General Ledger Configuration.",
                { type: 'danger' }
            );
        }
    }

    

    async loadAccounts() {
        this.state.accounts = await this.orm.searchRead(
            "account.account",
            [['deprecated', '=', false]],
            ["name", "code"]
        );
    }

    async initializeFinancialYearDates() {
        if (!this.state.dateFrom || !this.state.dateTo) {
            // Fetch current company's country
            // Default period = the current month
            const today = new Date();
            const pad = (n) => String(n).padStart(2, "0");
            const y = today.getFullYear();
            const m = today.getMonth();
            const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
            const monthRange = {
                start: `${y}-${pad(m + 1)}-01`,
                end: `${y}-${pad(m + 1)}-${pad(new Date(y, m + 1, 0).getDate())}`,
            };

            this.state.dateType = 'Month';
            this.state.selectedMonth = monthNames[m];
            this.state.selectedYear = y;
            this.state.dateFrom = monthRange.start;
            this.state.dateTo = monthRange.end;
            this.state.fyDates = monthRange; // Store for later use in onMounted
        }
    }

    _ledgerFilters() {
        return {
            date_from: this.state.dateFrom || false,
            date_to: this.state.dateTo || false,
            account_id: this.state.selectedAccount ? parseInt(this.state.selectedAccount) : false,
            account_ids: this.state.searchAccountIds || null,
        };
    }

    async loadLedgerData() {
        // Same idea as Odoo's own reports: the server aggregates (one SQL query),
        // the browser only receives one row per account. Lines are fetched later,
        // per account, when it is expanded.
        const f = this._ledgerFilters();
        const summary = await this.orm.call(
            "gl.pl.ledger.data", "get_gl_summary", [],
            { date_from: f.date_from, date_to: f.date_to,
              account_id: f.account_id, account_ids: f.account_ids }
        );
        this.state.pageSize = summary.page_size;
        this.state.visibleLinesCount = {};
        this.state.ledgerData = [];
        const grouped = {};
        for (const acc of summary.accounts) {
            grouped[acc.id] = {
                accountName: acc.name,
                lines: [],
                fetched: [],
                lineCount: acc.line_count,
                hasMore: acc.line_count > 0,
                loaded: false,
                opening: { debit: acc.opening_debit, credit: acc.opening_credit },
                totals: {
                    debit: acc.debit,
                    credit: acc.credit,
                    balance: acc.balance,
                    runningBalance: acc.balance,
                },
            };
            if (!(acc.id in this.state.collapsedAccounts)) {
                this.state.collapsedAccounts[acc.id] = true;
            }
        }
        this.state.groupedData = grouped;
        this.state.totals = summary.totals;

        // Force open account when arriving from P&L
        if (this.plAccountId) {
            const accountId = parseInt(this.plAccountId);
            this.state.collapsedAccounts[accountId] = false;
            localStorage.setItem(
                "general_ledger_collapsed_accounts",
                JSON.stringify(this.state.collapsedAccounts)
            );
        }
        await this.loadOpenAccounts();
    }

    // Load lines only for the accounts that are currently expanded
    async loadOpenAccounts() {
        const ids = Object.keys(this.state.groupedData).filter(
            id => this.state.collapsedAccounts[id] === false
        );
        await Promise.all(ids.map(id => this.loadAccountLines(id)));
    }

    _rebuildRows(group) {
        const f = this._ledgerFilters();
        const desc = this.state.sortDirection === 'desc';
        const op = group.opening;
        const hasOpening = f.date_from && (op.debit || op.credit);
        const rows = [...group.fetched];
        if (hasOpening) {
            const initial = {
                move_name: "Initial Balance",
                move_id: [null, "Initial Balance"],
                date: f.date_from,
                name: "",
                partner_id: null,
                currency_id: false,
                debit: op.debit,
                credit: op.credit,
                balance: op.debit - op.credit,
                currency_symbol: this.state.companyCurrency.symbol,
            };
            if (desc) {
                rows.push(initial);
            } else {
                rows.unshift(initial);
            }
        }
        group.lines = rows;
        group.hasMore = group.fetched.length < group.lineCount;
    }

    async loadAccountLines(accountId, append = false) {
        const group = this.state.groupedData[accountId];
        if (!group || group.loading) return;
        if (!append && group.loaded) return;
        group.loading = true;
        try {
            const f = this._ledgerFilters();
            const page = await this.orm.call(
                "gl.pl.ledger.data", "get_gl_lines", [],
                {
                    account_id: parseInt(accountId),
                    date_from: f.date_from,
                    date_to: f.date_to,
                    offset: append ? group.fetched.length : 0,
                    limit: this.state.pageSize || 80,
                    descending: this.state.sortDirection === 'desc',
                }
            );
            group.fetched = append ? group.fetched.concat(page) : page;
            group.loaded = true;
            this._rebuildRows(group);
        } finally {
            group.loading = false;
        }
    }

    async addInitialBalances() {
        // Opening balances now come from the server (get_gl_summary).
    }

    getFinancialYearRange(countryCode, startYear = null) {
        // First month of the financial year:
        // April for IN / JP / CAD, July for AU / NZD / PKR, otherwise January.
        let startMonth = 0;
        switch (countryCode) {
            case 'IN':
            case 'JP':
            case 'CAD':
                startMonth = 3;
                break;
            case 'AU':
            case 'NZD':
            case 'PKR':
                startMonth = 6;
                break;
        }

        const today = new Date();
        if (startYear === null) {
            // current financial year
            startYear = today.getMonth() >= startMonth
                ? today.getFullYear()
                : today.getFullYear() - 1;
        }

        const start = new Date(startYear, startMonth, 1);
        const end = new Date(startYear + 1, startMonth, 0); // day before the next year starts

        // Build YYYY-MM-DD from the local date parts. toISOString() converts to UTC
        // and moves the date back one day in time zones ahead of UTC (Qatar, India).
        const pad = (n) => String(n).padStart(2, "0");
        const formatDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
        return { start: formatDate(start), end: formatDate(end) };
    }

    toggleAccount(accountId) {

        this.state.collapsedAccounts[accountId] =
            !this.state.collapsedAccounts[accountId];

        if (!this.state.collapsedAccounts[accountId]) {
            this.loadAccountLines(accountId);   // lazy: fetch on first expand
        }
    }

    groupDataByAccount() {
        // Grouping is done on the server now (get_gl_summary).
    }

    // Load more method (next page from the server)
    async loadMore(accountId) {
        await this.loadAccountLines(accountId, true);
    }

    calculateTotals() {
        // Totals come from the server now (get_gl_summary).
    }

    async addCurrencySymbols(lines) {
        // Fetch all unique currency IDs from the lines
        const currencyIds = [...new Set(lines.map(line => line.currency_id ? line.currency_id[0] : false).filter(Boolean))];
        if (!currencyIds.length) return lines;

        const currencies = await this.orm.searchRead(
            "res.currency",
            [['id', 'in', currencyIds]],
            ["name", "symbol"]
        );

        const currencyMap = {};
        currencies.forEach(c => {
            currencyMap[c.id] = c.symbol;
        });

        // Add symbol to each line
        lines.forEach(line => {
            if (line.currency_id && line.currency_id[0]) {
                line.currency_symbol = currencyMap[line.currency_id[0]] || line.currency_id[1];
            } else {
                line.currency_symbol = this.state.companyCurrency.symbol; // default
            }
        });

        return lines;
    }

    onSearchKeydown(ev) {
        if (ev.key === "Enter") {
            this.searchJournal();
        }
    }

    async searchJournal() {
        // The search looks only at the account rows (code + name), never at the
        // lines inside them. Every word typed must appear in the code or the name.
        const text = this.searchInput.el.value.trim();

        if (!text) {
            this.state.searchAccountIds = null;
        } else {
            const domain = [];
            for (const word of text.split(/\s+/)) {
                domain.push('|', ['name', 'ilike', word], ['code', 'ilike', word]);
            }
            const accounts = await this.orm.searchRead("account.account", domain, ["id"]);
            this.state.searchAccountIds = accounts.map(account => account.id);
        }

        await this.loadLedgerData();
    }

    selectDateType(type) {
        this.state.dateType = type;
        // Reset previous selections
        this.state.selectedMonth = null;
        this.state.selectedQuarter = null;
        this.state.selectedYear = null;
        if (type === 'Custom') {
            this.state.dateFrom = this.dateFromRef.el?.value || '';
            this.state.dateTo = this.dateToRef.el?.value || '';
        }

        if (type === 'Year') {
            // open on the current financial year straight away (e.g. 2026)
            const current = this.getFinancialYearRange(this.state.companyCurrency.country_code);
            this.selectFinancialYear(parseInt(current.start.slice(0, 4), 10));
        }
    }

    selectMonth(month) {
        this.state.selectedMonth = month;
        if (!this.state.selectedYear) {
            this.state.selectedYear = new Date().getFullYear();
        }
        // set dateFrom/dateTo accordingly
        const monthIndex = ['January','February','March','April','May','June','July','August','September','October','November','December'].indexOf(month);
        const year = this.state.selectedYear;
        this.state.dateFrom = `${year}-${String(monthIndex+1)   .padStart(2,'0')}-01`;
        this.state.dateTo = `${year}-${String(monthIndex+1).padStart(2,'0')}-${new Date(year, monthIndex+1, 0).getDate()}`;
        this.loadLedgerData();
    }

    onYearSelect(year) {
        this.state.selectedYear = year;
    
        if (this.state.dateType === 'Month' && this.state.selectedMonth) {
            this.selectMonth(this.state.selectedMonth);
        }
    
        if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
            this.selectQuarter(this.state.selectedQuarter);
        }
    
        if (this.state.dateType === 'Year') {
            this.onYearChange({
                target: { value: year }
            });
        }
    }

    selectQuarter(quarter) {
        this.state.selectedQuarter = quarter;
        if (!this.state.selectedYear) {
            this.state.selectedYear = new Date().getFullYear();
        }
        const year = this.state.selectedYear || new Date().getFullYear();
        switch(quarter) {
            case 'Q1': this.state.dateFrom=`${year}-01-01`; this.state.dateTo=`${year}-03-31`; break;
            case 'Q2': this.state.dateFrom=`${year}-04-01`; this.state.dateTo=`${year}-06-30`; break;
            case 'Q3': this.state.dateFrom=`${year}-07-01`; this.state.dateTo=`${year}-09-30`; break;
            case 'Q4': this.state.dateFrom=`${year}-10-01`; this.state.dateTo=`${year}-12-31`; break;
        }
        this.loadLedgerData();
    }

    onYearChange(ev) {
        const year = parseInt(ev.target.value);
        if (!isNaN(year)) {
            const range = this.getFinancialYearRange(
                this.state.companyCurrency.country_code,
                year
            );
            this.state.dateFrom = range.start;
            this.state.dateTo = range.end;
            this.loadLedgerData();
        }
    }

    selectFinancialYear(year) {
        this.state.selectedYear = year;
        this.onYearChange({
            target: { value: year }
        });
    }

    onCustomDateFromChange(ev) {
        const fromDate = ev.target.value;
        this.state.dateFrom = fromDate;

        // Restrict 'To' date
        if (this.dateToRef.el) {
            this.dateToRef.el.min = fromDate;

            // Optional: if current 'To' date is before 'From', reset it
            if (this.dateToRef.el.value && this.dateToRef.el.value < fromDate) {
                this.dateToRef.el.value = fromDate;
                this.state.dateTo = fromDate;
            }
        }
    }

    async applyFilters() {
        // Read the filter inputs, then let the server do the work
        this.state.dateFrom = this.dateFromRef.el?.value;
        this.state.dateTo = this.dateToRef.el?.value;
        this.state.selectedAccount = this.accountRef.el?.value || null;
        await this.loadLedgerData();
    }

    getActiveDateRangeLabel() {
        // Month
        if (this.state.dateType === "Month" && this.state.selectedMonth) {
            return `Month: ${this.state.selectedMonth}`;
        }

        // Quarter with month range
        if (this.state.dateType === "Quarter" && this.state.selectedQuarter) {
            const quarterMap = {
                Q1: "Jan-Mar",
                Q2: "Apr-Jun",
                Q3: "Jul-Sep",
                Q4: "Oct-Dec",
            };
            return `Quarter: ${this.state.selectedQuarter} (${quarterMap[this.state.selectedQuarter] || ""})`;
        }

        // Year
        if (this.state.dateType === "Year" && this.state.dateFrom && this.state.dateTo) {
            const year = String(this.state.dateFrom).slice(0, 4);
            return `Year: ${year}`;
        }

        // Custom date range
        if (this.state.dateType === "Custom" && this.state.dateFrom && this.state.dateTo) {
            // "YYYY-MM-DD" is split, not parsed with Date(), which moves the day
            // back by one in browsers whose time zone is behind UTC.
            const formatDate = (d) => {
                const [year, month, day] = String(d).slice(0, 10).split("-");
                return `${day}-${month}-${year}`;
            };
            return `Custom: ${formatDate(this.state.dateFrom)} → ${formatDate(this.state.dateTo)}`;
        }

        // Financial year
        if (this.state.fyDates) {
            // "YYYY-MM-DD" is split, not parsed with Date(), which moves the day
            // back by one in browsers whose time zone is behind UTC.
            const formatDate = (d) => {
                const [year, month, day] = String(d).slice(0, 10).split("-");
                return `${day}-${month}-${year}`;
            };
            return `Financial Year: ${formatDate(this.state.fyDates.start)} → ${formatDate(this.state.fyDates.end)}`;
        }

        return "All Records";
    }

    async loadCompanyCurrency() {
        // Currency of the active company, so no symbol is hardcoded
        try {
            this.state.companyCurrency = await this.orm.call(
                "res.company",
                "get_company_currency",
                []
            );
        } catch (error) {
            console.error("Failed to load company currency:", error);
        }
    }

    formatCurrency(amount, currencySymbol = this.state.companyCurrency.symbol, currencyName = null) {
        // Determine if it's INR based on symbol or currency name
        const isINR = currencySymbol === '₹' ||
                      (currencyName && currencyName.toUpperCase().includes('INR')) ||
                      (currencyName && currencyName.toUpperCase().includes('RUPEE'));

        const isWhole = Number.isInteger(amount);

        if (isINR) {
            // Indian format: ₹ 1,05,000 (lakhs and crores system)
            let x = amount.toFixed(isWhole ? 0 : 2).split('.');
            let intPart = x[0];
            let decPart = x.length > 1 && x[1] !== '00' ? '.' + x[1] : '';

            // Handle Indian numbering system
            if (intPart.length > 3) {
                // Take last 3 digits
                let lastThree = intPart.substring(intPart.length - 3);
                let otherNumbers = intPart.substring(0, intPart.length - 3);

                // Apply Indian grouping (every 2 digits after first 3)
                if (otherNumbers !== '') {
                    otherNumbers = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
                    lastThree = ',' + lastThree;
                }

                intPart = otherNumbers + lastThree;
            }

            return currencySymbol + ' ' + intPart + decPart;
        } else {
            // International format: $ 105,000 (thousands system)
            let options = {
                minimumFractionDigits: isWhole ? 0 : 2,
                maximumFractionDigits: isWhole ? 0 : 2,
            };
            return currencySymbol + ' ' + amount.toLocaleString('en-US', options);
        }
    }

    viewJournalEntry(moveId) {
        if (!moveId) {
            return;
        }
            const action = {
                type: "ir.actions.act_window",
                res_model: "account.move",
                res_id: moveId,
                views: [[false, "form"]],
                target: "current", // opens in same window
            };
            // SAVES which accounts are open and position of scroll  
            localStorage.setItem(
                "general_ledger_collapsed_accounts",
                JSON.stringify(this.state.collapsedAccounts)
            );
            
            localStorage.setItem(
                "general_ledger_scroll",
                document.querySelector('.o_content')?.scrollTop || 0
            );
            // come back from the entry with the same rows open (valid for 30 min)
            localStorage.setItem("general_ledger_restore_until", String(Date.now() + 30 * 60 * 1000));
            this.env.services.action.doAction(action);
    }

    getAmountClass(amount) {
        if (amount < 0) return 'text-danger';
        return '';
    }

    formatToDDMMYYYY(dateStr) {
        if (!dateStr) return "";
        if (/^\d{4}-\d{2}-\d{2}/.test(String(dateStr))) {
            // split instead of Date(): no day shift in time zones behind UTC
            const [year, month, day] = String(dateStr).slice(0, 10).split("-");
            return `${day}/${month}/${year}`;
        }
        const date = new Date(dateStr);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
    }

    formatDate(dateStr) {
        return this.formatToDDMMYYYY(dateStr);
    }

    getFilterTitle() {
        const textSearch = this.searchInput && this.searchInput.el ? this.searchInput.el.value.trim() : null;

        if (textSearch) {
            return `${textSearch}`;
        }

        return "All Records";
    }

    // Export to PDF
    async exportToPDF() {
        this.ui.block();
        try {
            const searchText = this.searchInput.el.value.trim();
            const dateFrom = this.state.dateFrom;
            const dateTo = this.state.dateTo;
            let month = null;
            let quarter = null;
            let year = null;

            if (this.state.dateType === 'Month' && this.state.selectedMonth) {
                // Convert Month name ('October') to month index (10)
                const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                month = monthNames.indexOf(this.state.selectedMonth) + 1; // 1-indexed month
                year = parseInt(String(dateFrom).slice(0, 4), 10); // Get year from the calculated date range

            } else if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
                // Pass the quarter label (Q1, Q2, etc.)
                quarter = this.state.selectedQuarter;
                year = parseInt(String(dateFrom).slice(0, 4), 10);

            } else if ((this.state.dateType === 'Year' || !this.state.dateType) && dateFrom) {
                // This covers 'Year' selection and the default Financial Year initialization
                year = parseInt(String(dateFrom).slice(0, 4), 10);
            }

            // Prepare data for PDF export
            const exportData = {
                date_from: dateFrom,
                date_to: dateTo,
                month: month,
                quarter: quarter,
                year: year,
                filter_title: this.getFilterTitle(),
                server_side: true,
                account_id: this.state.selectedAccount ? parseInt(this.state.selectedAccount) : false,
                account_ids: this.state.searchAccountIds || null,
                descending: this.state.sortDirection === 'desc',
                grouped_data: Object.fromEntries(
                    Object.entries(this.state.groupedData).map(([id, g]) => [
                        id,
                        { accountName: g.accountName, totals: g.totals, lines: [] },
                    ])
                ),
                collapsed_accounts: this.state.collapsedAccounts,
                totals: this.state.totals,
                company_info: await this.orm.call("res.company", "get_current_company_info", []),
                search_text: searchText,
            };

            // Call the PDF export method
            const result = await this.orm.call(
                "general.ledger.export",
                "export_general_ledger_pdf",
                [exportData]
            );

            if (result) {
                // Download the PDF
                await this.action.doAction(result);
            } else {
                throw new Error("PDF export failed: Server response did not contain a download URL. Result: " + JSON.stringify(result));
            }
        } catch (error) {
            console.error("Error exporting PDF:", error);
            throw error;
        } finally {
            this.ui.unblock();
        }
    }

    // Export to XLSX
    async exportToXLSX() {
        this.ui.block();
        try {
            const dateFrom = this.state.dateFrom;
            const dateTo = this.state.dateTo;
            let month = null;
            let quarter = null;
            let year = null;

            if (this.state.dateType === 'Month' && this.state.selectedMonth) {
                // Convert Month name ('October') to month index (10)
                const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                month = monthNames.indexOf(this.state.selectedMonth) + 1; // 1-indexed month
                year = parseInt(String(dateFrom).slice(0, 4), 10); // Get year from the calculated date range

            } else if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
                // Pass the quarter label (Q1, Q2, etc.)
                quarter = this.state.selectedQuarter;
                year = parseInt(String(dateFrom).slice(0, 4), 10);

            } else if ((this.state.dateType === 'Year' || !this.state.dateType) && dateFrom) {
                // This covers 'Year' selection and the default Financial Year initialization
                year = parseInt(String(dateFrom).slice(0, 4), 10);
            }

            // Prepare data for XLSX export
            const exportData = {
                date_from: dateFrom,
                date_to: dateTo,
                month: month,
                quarter: quarter,
                year: year,
                filter_title: this.getFilterTitle(),
                server_side: true,
                account_id: this.state.selectedAccount ? parseInt(this.state.selectedAccount) : false,
                account_ids: this.state.searchAccountIds || null,
                descending: this.state.sortDirection === 'desc',
                grouped_data: Object.fromEntries(
                    Object.entries(this.state.groupedData).map(([id, g]) => [
                        id,
                        { accountName: g.accountName, totals: g.totals, lines: [] },
                    ])
                ),
                collapsed_accounts: this.state.collapsedAccounts,
                totals: this.state.totals,
                company_info: await this.orm.call("res.company", "get_current_company_info", [])
            };

            // Call the XLSX export method
            const result = await this.orm.call(
                "general.ledger.export",
                "export_general_ledger_xlsx",
                [exportData]
            );

            if (result && result.url) {
                // Download the XLSX
                window.open(result.url, '_blank');
            } else {
                console.error("XLSX export failed");
            }
        } catch (error) {
            console.error("Error exporting XLSX:", error);
        } finally {
            this.ui.unblock();
        }
    }
}

GeneralLedgerReport.template = "gl_pl_reports_aretx.GeneralLedgerReport";
registry.category("actions").add("gl_pl_reports_aretx.general_ledger_owl", GeneralLedgerReport);