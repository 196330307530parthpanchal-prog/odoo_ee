from odoo import http
from odoo.http import request
import json

class SalesAPIController(http.Controller):

    @http.route('/api/sales_summary', type='http', auth='public')
    def sales_summary(self):
        orders = request.env['sale.order'].sudo().search([], limit=5)
        result = []

        for order in orders:
            result.append({
                'order_id': order.id,
                'order_name': order.name,
                'date_order': order.date_order,
                'customer': order.partner_id.name,
                'total': order.amount_total,
                'products': [line.product_id.name for line in order.order_line],
            })

        return result
