/** @odoo-module **/

import { patch } from "@web/core/utils/patch";
import { QtyAtDateWidget } from "@sale_stock/widgets/qty_at_date_widget";

patch(QtyAtDateWidget.prototype, {

    initCalcData() {
        // call original logic
        super.initCalcData();

        const data = this.props.record.data;

        console.log("my calculations ran")
        const orderedQty = data.qty_to_deliver || 0;
        // const totalQty = data.all_company_qty_available || 0;
        const totalForcastQty = data.forecast_qty_all_companies || 0;

        console.log(data.qty_to_deliver, totalForcastQty)

        this.calcData.is_over_ordered = orderedQty && orderedQty > totalForcastQty;

        if(data.state === "sale"){
            console.log("this is confirmed")
            this.calcData.is_over_ordered=0;
        }
    },

});