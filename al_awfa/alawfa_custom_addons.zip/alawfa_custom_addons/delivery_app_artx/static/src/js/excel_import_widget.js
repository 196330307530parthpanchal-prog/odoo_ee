/** @odoo-module **/

import { x2ManyCommands } from "@web/core/orm_service";
import { getId } from "@web/model/relational_model/utils";
import { registry } from "@web/core/registry";
import { useService } from "@web/core/utils/hooks";
import { Component, useRef } from "@odoo/owl";

class ImportProductLots extends Component {
    setup() {
        this.dialog = useService("dialog");
        this.excelFile = useRef("excelFile");
        this.orm = useService("orm");
    }
    async _onChangeNoOfLots() {
//        console.log("Myfunc");
        const move = this.props.record;
//        console.log(move);
        const qty = move.data.product_uom_qty;       // total qty
        const noOfLots = move.data.no_of_lots_wanted;
//        console.log(qty);
//        console.log(noOfLots);

        if (!noOfLots || noOfLots <= 0) {
            return alert("Please enter a valid number of lots.");
        }
        if (!qty || qty <= 0) {
            return alert("No quantity available to split.");
        }

        const qtyPerLot = (qty / noOfLots).toFixed(2);
//        console.log(qtyPerLot);

        const lotNames = await this.orm.call("stock.move", "action_generate_lot_names", [
            move.resId,   // current move id
            noOfLots,
        ]);

        // Build lotText with sequence names + qty
        const lotText = lotNames
            .map((lot, i) => `${lot}\t${qtyPerLot}`)
            .join("\n");

        // Call backend to generate move line vals
        const move_line_vals = await this.orm.call("stock.move", "action_generate_lot_line_vals", [
            {
                ...move.context,
                default_product_id: move.data.product_id[0],
                default_location_id: move.data.location_id[0],
                default_location_dest_id: move.data.location_dest_id[0],
                default_picking_type_id: move.data.picking_type_id?.[0],
                default_company_id: move.data.company_id?.[0],
            },
            "import",
            null,
            0,
            lotText,
        ]);

        const lines = move.data.move_line_ids;
        await lines._applyCommands(
            lines._currentIds.map((id) => [x2ManyCommands.DELETE, id])
        );

        // Create new ones
        const newlines = move_line_vals.map((values) =>
            lines._createRecordDatapoint(values, {
                mode: "readonly",
                virtualId: getId("virtual"),
                manuallyAdded: false,
            })
        );

        lines.records.push(...newlines);
        lines._commands.push(...newlines.map((rec) => [x2ManyCommands.CREATE, rec._virtualId]));
        lines._currentIds.push(...newlines.map((rec) => rec._virtualId));
        await lines._onUpdate();
    }

    async _onUploadExcel() {
        console.log("Excel button clicked ✅");
        const file = this.excelFile.el?.files[0];
        if (!file) return alert("Please select an Excel file.");

        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json(sheet, { header: 1 });
        const lotText = rows
            .slice(1)
            .filter(row => row[0])
            .map(([lot, qty]) => `${lot}\t${qty || 1}`)
            .join("\n");

        const move = this.props.record;

        const move_line_vals = await this.orm.call("stock.move", "action_generate_lot_line_vals", [
            {
                ...move.context,
                default_product_id: move.data.product_id[0],
                default_location_id: move.data.location_id[0],
                default_location_dest_id: move.data.location_dest_id[0],
                default_picking_type_id: move.data.picking_type_id?.[0],
                default_company_id: move.data.company_id?.[0],
            },
            "import",
            null,
            0,
            lotText,
        ]);

        const lines = move.data.move_line_ids;
        const newlines = move_line_vals.map((values) =>
            lines._createRecordDatapoint(values, {
                mode: "readonly",
                virtualId: getId("virtual"),
                manuallyAdded: false,
            })
        );

        await lines._applyCommands(
            lines._currentIds.map((id) => [x2ManyCommands.DELETE, id])
        );

        lines.records.push(...newlines);
        lines._commands.push(...newlines.map((rec) => [x2ManyCommands.CREATE, rec._virtualId]));
        lines._currentIds.push(...newlines.map((rec) => rec._virtualId));
        await lines._onUpdate();
    }
}

// ✅ TELL OWL WHAT TEMPLATE TO RENDER!
ImportProductLots.template = "stock.ImportLots";

// ✅ REPLACE the component used by Odoo
registry.category("view_widgets").remove("import_lots");
registry.category("view_widgets").add("import_lots", { component: ImportProductLots });
