/** @odoo-module **/

import { Component } from "@odoo/owl";
import { _t } from "@web/core/l10n/translation";
import { registry } from "@web/core/registry";
import { standardFieldProps } from "@web/views/fields/standard_field_props";

export class HoverSummaryField extends Component {
    static template = "delivery_app_artx.HoverSummaryField";
    static props = standardFieldProps;

    get summaryText() {
        return _t("details");
    }

    get tooltipText() {
        return this.props.record.data[this.props.name] || "";
    }

    get previewText() {
    const value = this.props.record.data[this.props.name];
    if (!value) return "";
    const lines = value.split("\n").filter(line => line.trim());
    const previewLines = lines.slice(0, 7);
    if (lines.length > 7) {
        previewLines.pop()
        previewLines.push("and more...");
    }
    return previewLines.join("\n");

    }

}

export const hoverSummaryField = {
    component: HoverSummaryField,
    displayName: _t("Hover Summary"),
    supportedTypes: ["char", "text"],
};

registry.category("fields").add("hover_summary", hoverSummaryField);
