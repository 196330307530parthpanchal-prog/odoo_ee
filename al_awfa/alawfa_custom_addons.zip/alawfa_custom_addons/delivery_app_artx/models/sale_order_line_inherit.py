from odoo import models, fields, api
from odoo import models, _
from odoo.exceptions import UserError
class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    box = fields.Integer(
        string="CRT",
        store=True
    )

    show_box = fields.Boolean(
        string="Show Box",
        compute="_compute_show_box",
        store=False
    )

    
    @api.depends('product_id')
    def _compute_show_box(self):
        for line in self:
            line.show_box = bool(line.product_id.box_boolean)
            if not line.product_id.box_boolean:
                line.box = 0

    @api.depends('product_id', 'product_uom', 'product_uom_qty')
    def _compute_price_unit(self):
        """
        Prevent price_unit from resetting when quantity changes,
        unless no manual price was set yet.
        """
        for line in self:
            # if price already set, keep it
            print('price_unit : ', line.price_unit, ', _origin : ',line._origin,', line._origin.price_unit: ',line._origin.price_unit)
            if line.price_unit and line._origin and line._origin.price_unit:
                print('_compute_price_unit skipped')
                continue

            # otherwise use normal Odoo logic
            super(SaleOrderLine, line)._compute_price_unit()
            print('original _compute_price_unit called')


    all_company_qty_available = fields.Float(
        string="Total Stock (All Companies) dummy",
    )
    # @api.onchange('product_id')
    # def _compute_all_company_stock(self):
    #     # get all companies
    #     companies = self.env['res.company'].search([])
    #     for line in self:
    #         product = line.product_id
    #         if not product:
    #             line.all_company_qty_available = 0
    #             continue
    #
    #         total = 0
    #         for company in companies:
    #             qty = product.with_context(
    #                 allowed_company_ids=[company.id]
    #             ).with_company(company).qty_available
    #
    #             print(f"{company.name} : {qty})")
    #             total += qty
    #
    #         line.all_company_qty_available = total

    forecast_qty_all_companies = fields.Float(
        string="Forecasted Qty (All Companies)",
        compute="_compute_forecast_qty_all_companies",
        store=False
    )

    @api.onchange('product_id')
    def _compute_forecast_qty_all_companies(self):

        companies = self.env['res.company'].search([])
        for line in self:
            product = line.product_id
            if not product:
                line.forecast_qty_all_companies = 0
                continue

            total = 0
            for company in companies:
                qty = product.with_context(
                    allowed_company_ids=[company.id]
                ).with_company(company).virtual_available

                print(f"{company.name} : {qty})")
                total += qty

            line.forecast_qty_all_companies = total
            print("forecast_qty_all_companies : ", line.forecast_qty_all_companies)

        # all_company_ids = self.env['res.company'].sudo().search([]).ids
        #
        # for line in self:
        #     product = line.product_id.product_tmpl_id
        #
        #     product_all = product.with_context(
        #         allowed_company_ids=all_company_ids
        #     )
        #
        #     line.forecast_qty_all_companies = product_all.virtual_available
        #
        #     print("forecast_qty_all_companies : ", line.forecast_qty_all_companies)

    crt_qty_all_companies = fields.Integer(
        string="CRT2 (All Companies)",
    )

    crt_qty = fields.Integer(
        string="CRT2 (All Companies)",
        related="product_template_id.crt_qty",
        store=False
    )

    # @api.onchange('product_id')
    # def _compute_crt_qty_all(self):
    #     print("_compute_crt_qty_all")
    #
    #     all_companies = self.env['res.company'].sudo().search([]).ids
    #
    #     for line in self:
    #         product = line.product_id.product_tmpl_id
    #
    #         if not product:
    #             line.crt_qty_all_companies = 0
    #             continue
    #
    #         product_all = product.with_context(
    #             allowed_company_ids=all_companies
    #         )
    #
    #         # force recompute properly
    #         product_all._compute_crt_qty()
    #
    #         line.crt_qty_all_companies = product_all.crt_qty
    #
    #         product._compute_crt_qty()
    #
    #         print(line.crt_qty_all_companies)

    forecast_crt_qty_all_companies = fields.Float(
        compute="_compute_forecast_crt_qty_all_companies",
    )

    @api.onchange('product_id')
    def _compute_forecast_crt_qty_all_companies(self):
        print("_compute_forecast_crt_qty_all_companies")

        all_companies = self.env['res.company'].sudo().search([]).ids

        for line in self:
            product = line.product_id.product_tmpl_id

            if not product:
                line.forecast_crt_qty_all_companies = 0
                continue

            product_all = product.with_context(
                allowed_company_ids=all_companies
            )

            # force recompute properly
            product_all._compute_forecast_crt_qty()

            line.forecast_crt_qty_all_companies = product_all.forecast_crt_qty

            product._compute_forecast_crt_qty()

            print(line.forecast_crt_qty_all_companies)