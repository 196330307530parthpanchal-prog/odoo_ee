from odoo import models, fields

class ResUsers(models.Model):
    _inherit = 'res.users'

    cash_journal_ids = fields.Many2many(
        'account.journal',
        'res_users_account_journal_rel',
        'user_id', 'journal_id',
        string='Cash Journals',
        domain=[('type', 'in', ['cash', 'bank'])]
    )


class ResCompany(models.Model):
    _inherit = 'res.company'

    second_logo = fields.Binary(string="Second Logo")

class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    second_logo = fields.Binary(
        string="Second Logo",
        related='company_id.second_logo',
        readonly=False
    )