from odoo import api,fields,models,_
from odoo.fields import One2many, Many2one
import base64
from odoo.exceptions import ValidationError


class DispatchDetails(models.Model):
    _name='dispatch.details'
    _inherit = ['portal.mixin', 'product.catalog.mixin', 'mail.thread', 'mail.activity.mixin', 'utm.mixin']
    _description = 'Dispatch Details Master'
    _rec_name = 'batch_no'

    batch_no = fields.Char(string="Batch Number", readonly=True, copy=False, default='New')
    schedule_date = fields.Datetime(string="Delivery Date",required=True,)
    vehicle_details = fields.Many2one('vehicle.details',string="Vehicle reference",tracking=True)
    vehicle_alter_name = fields.Char(string='Notes', default='')
    is_self_pickup = fields.Boolean(string='Is Self Pickup?', default=False, help="Derived from driver selection.")
    driver_details = fields.Many2one('hr.employee', string='Driver', domain=[('job_id.name', 'in', ('Driver','driver','DRIVER'))], required=True,tracking=True)
    schedule_date_date = fields.Date(string="Schedule Date (Date Only)", compute="_compute_schedule_date_date",
                                     store=True)

    def action_print_summary_report(self):
        self.ensure_one()
        if self.batch_type == 'outgoing':
            return self.env.ref('delivery_app_artx.dispatch_summary_report_action').report_action(self)
        elif self.batch_type == 'incoming':
            return self.env.ref('delivery_app_artx.dispatch_summary_report_action_in').report_action(self)
        return False
    
    # def get_product_summary(self):
    #     result = []
    #     for move in self.move_ids_without_package:
    #         result.append({
    #             'product_name': move.product_id.display_name,
    #             'qty': move.product_uom_qty,
    #             'uom': move.product_uom.name,
    #             'delivered_box': move.delivered_box or 0,
    #             'box_boolean': move.product_id.product_tmpl_id.box_boolean or False,
    #         })
    #     return result


    @api.depends("schedule_date")
    def _compute_schedule_date_date(self):
        for rec in self:
            if rec.schedule_date:
                print('date found s.p. : ', rec.schedule_date)
                rec.schedule_date_date = fields.Date.context_today(rec, rec.schedule_date)
                print('date extracted s.p.: ', rec.schedule_date_date)

    dispatch_orders = fields.One2many(
        'dispatch.order.details',
        'batch_details',
        string="Dispatch Orders",tracking=True
    )

    email_sent=fields.Boolean(string='Email sent or not', readonly=True,tracking=True)

    activity_ids = fields.One2many(
        'mail.activity',  # relation to mail.activity
        'res_id',  # linked by res_id
        string='Activities',
        domain=lambda self: [
            ('res_model', '=', self._name)  # only activities for this model
        ]
    )

    time_of_day = fields.Char(string="Delivery Time", readonly=True, copy=False)

    batch_type = fields.Selection(
        [('incoming', 'Incoming'), ('outgoing', 'Outgoing'), ('internal', 'Internal')],
        string="Dispatch Direction",
        compute='_compute_dispatch_direction',
        store=True
    )

    @api.depends('dispatch_orders')
    def _compute_dispatch_direction(self):
        for record in self:
            codes = set(record.dispatch_orders.mapped('order_number.picking_type_id.code'))

            if not codes:
                record.batch_type = False
            elif len(codes) > 1:
                raise ValidationError(f"Dispatch {record._name or record.id} has multiple picking types: {codes}")
            else:
                code = list(codes)[0]
                if code == 'incoming':
                    record.batch_type = 'incoming'
                elif code == 'outgoing':
                    record.batch_type = 'outgoing'
                else:
                    record.batch_type = 'internal'

                print(f"Dispatch {record.id}: Picking type = {code}, Direction = {record.batch_type}")

    @api.constrains('dispatch_orders')
    def _check_uniform_picking_type(self):
        for record in self:
            picking_types = record.dispatch_orders.mapped('order_number.picking_type_id')
            # if picking_types and len(set(picking_types)) > 1:
            #     raise ValidationError(
            #         "All orders in the batch must be of the same picking type (either all incoming or all outgoing).")
            codes = picking_types.mapped('code')

            if codes and len(set(codes)) > 1:
                raise ValidationError(
                    "All orders in the batch must be of the same picking type (all incoming, all outgoing, etc.)."
                )
    # driver_partner_id = fields.Many2one(
    #     'res.partner',
    #     string="Driver Contact",
    #     compute="_compute_driver_partner",
    #     store=True
    # )
    #
    # @api.depends('driver_details')
    # def _compute_driver_partner(self):
    #     for record in self:
    #         record.driver_partner_id = record.driver_details.address_home_id.id if record.driver_details else False

    @api.model_create_multi
    def create(self, vals_list):
        # print("manav", vals_list)
        for vals in vals_list:
            if not vals.get('batch_no') or vals['batch_no'] == 'New':
                vals['batch_no'] = self.env['ir.sequence'].next_by_code('dispatch.details')
        return super().create(vals_list)

    def create_activity_on_change(self):
        activity_type = self.env.ref('delivery_app_artx.mail_activity_type_notification', raise_if_not_found=False)
        admin_user = self.env.ref('base.user_admin', raise_if_not_found=False)

        if activity_type and admin_user:
            for record in self:
                record.activity_schedule(
                    activity_type_id=activity_type.id,
                    user_id=admin_user.id,
                    summary='Record has been Updated',
                    note='Record has been Updated',
                    date_deadline=fields.Date.today()
                )

    # def create_activity_on_change(self,vals):
    #     # List of fields that should trigger activity
    #     trigger_fields = {'driver_details', 'vehicle_details', 'schedule_date', 'dispatch_orders'}
    #
    #     if any(field in vals for field in trigger_fields):
    #         activity_type = self.env.ref('delivery_app_artx.mail_activity_type_notification',
    #                                      raise_if_not_found=False)
    #         admin_user = self.env.ref('base.user_admin', raise_if_not_found=False)
    #
    #         if activity_type and admin_user:
    #             for record in self:
    #                 record.activity_schedule(
    #                     'delivery_app_artx.mail_activity_type_notification',
    #                     user_id=admin_user.id,
    #                     summary='Record has been Updated',
    #                     note='Record has been Updated',
    #                     date_deadline=fields.Date.today()
    #                 )

    def write(self, vals):
        # Detect changes BEFORE writing
        trigger_fields = {'driver_details', 'vehicle_details', 'schedule_date', 'dispatch_orders'}
        fields_updated = any(field in vals for field in trigger_fields)

        res = super().write(vals)

        # Now that write succeeded, safely schedule activity
        if fields_updated:
            self.create_activity_on_change()

        return res



    def _get_customer_information(self):
        email_normalized_to_values = super()._get_customer_information()

        for record in self.filtered('email_from'):
            email_from_normalized = email_normalize(record.email_from)
            if not email_from_normalized:  # do not fill Falsy with random data
                continue
            values = email_normalized_to_values.setdefault(email_from_normalized, {})
            if not values.get('mobile'):
                values['mobile'] = record.mobile_number
            if not values.get('phone'):
                values['phone'] = record.phone_number
        return email_normalized_to_values



    def action_open_email_wizard(self):
        """Open Email Wizard for Editing Before Sending"""

        self.ensure_one()
        if (self.batch_type == 'outgoing'):
            template = self.env.ref('delivery_app_artx.email_template_dispatch_order')

            template_id = template.id
            report_id = self.env.ref('delivery_app_artx.dispatch_summary_report_action').id
            # report2_id = self.env.ref('delivery_app_artx.action_dispatch_batch_report').id

            if not template.report_template_ids:
                template.write({
                    'report_template_ids': [(4, report_id)]
                })

        if (self.batch_type == 'incoming'):
            template = self.env.ref('delivery_app_artx.email_template_dispatch_order_in')


            template_id = template.id
            report_id = self.env.ref('delivery_app_artx.dispatch_summary_report_action_in').id
            # report2_id = self.env.ref('delivery_app_artx.action_dispatch_batch_report').id

            if not template.report_template_ids:
                template.write({
                    'report_template_ids': [(4, report_id)]
                })

        print(template_id, report_id)

        if report_id:


            return {
                'type': 'ir.actions.act_window',
                'res_model': 'mail.compose.message',
                'view_mode': 'form',
                'view_id': False,
                'target': 'new',
                'context': {
                    'default_model': 'dispatch.details',
                    'default_res_ids': self.ids,
                    'default_use_template': bool(template_id),
                    'default_template_id': template_id,
                    'default_composition_mode': 'comment',
                    # 'default_attachment_ids': [(4, attachment.id)],
                }
            }



    # def get_product_summary(self):
    #     summary = []
    #     product_map = {}

    #     for dispatch_order in self.dispatch_orders:
    #         picking = dispatch_order.order_number
    #         for move in picking.move_ids:
    #             key = (move.product_id.id, move.product_uom.id)
    #             if key not in product_map:
    #                 if move.product_id.tracking in ['lot']:
    #                     product_map[key] = {
    #                         'product_name': move.product_id.name,
    #                         'qty': 0,
    #                         'lots':True,
    #                         'boxes': 0,
    #                         'uom': move.product_uom.name,
    #                         'delivered_box': move.delivered_box or 0,
    #                         'box_boolean': move.product_id.product_tmpl_id.box_boolean or False,
    #                     }
    #                 else:
    #                     product_map[key] = {
    #                         'product_name': move.product_id.name,
    #                         'qty': 0,
    #                         'lots': False,
    #                         'boxes': 0,
    #                         'uom': move.product_uom.name,
    #                         'delivered_box': move.delivered_box or 0,
    #                         'box_boolean': move.product_id.product_tmpl_id.box_boolean or False,
    #                     }

    #             if move.product_id.tracking in ['none']:
    #                 # Count the number of unique lots moved
    #                 lot_count = self.env['stock.move.line'].search_count([
    #                     ('move_id', '=', move.id),
    #                     ('lot_id', '!=', False)
    #                 ])
    #                 # product_map[key]['boxes'] += lot_count
    #                 product_map[key]['delivered_box'] += lot_count
    #                 product_map[key]['qty'] += move.product_uom_qty
    #             else:
    #                 # Use quantity for non-lot-tracked products
    #                 product_map[key]['qty'] += move.product_uom_qty


    #     summary = list(product_map.values())
    #     return summary

    def get_product_summary(self):
        product_map = {}

        for dispatch_order in self.dispatch_orders:
            picking = dispatch_order.order_number

            for move in picking.move_ids:
                key = (move.product_id.id, move.product_uom.id)

                if key not in product_map:
                    product_map[key] = {
                        'product_name': move.product_id.name,
                        'qty': 0,
                        'uom': move.product_uom.name,
                        'delivered_box': 0,
                        'box_boolean': bool(move.product_id.product_tmpl_id.box_boolean),
                    }

                line = product_map[key]

                if line['box_boolean']:
                    # ✅ ONLY delivered_box field
                    line['delivered_box'] += move.delivered_box or 0
                    # ❌ qty ignore
                    line['qty'] += move.product_uom_qty
                else:
                    # ✅ Normal product
                    line['qty'] += move.product_uom_qty

        return list(product_map.values())




    total_cartons = fields.Float(string="Total Cartons", compute="_compute_totals", store=True)
    total_crts = fields.Float(string="Total CRT",compute="_compute_total_crts",store=True)
    total_weight = fields.Float(string="Total Weight(in Kgs)", compute="_compute_totals", store=True)

    total_order_weight_sum = fields.Float(
        string="Total Weight",
        compute="_compute_total_order_sum",
        store=True
    )

    @api.depends('dispatch_orders.total_order_weight')
    def _compute_total_order_sum(self):
        for rec in self:
            rec.total_order_weight_sum = sum(rec.dispatch_orders.mapped('total_order_weight'))

    @api.depends('dispatch_orders.total_crt')
    def _compute_total_crts(self):
        for rec in self:
            rec.total_crts = sum(rec.dispatch_orders.mapped('total_crt'))

    @api.depends('dispatch_orders.order_number.total_product_qty', 'dispatch_orders.order_number.total_weight')

    def _compute_totals(self):
        for record in self:
            total_cartons = 0.0
            total_weight = 0.0

            for dispatch_order in record.dispatch_orders:
                picking = dispatch_order.order_number
                if picking:
                    total_cartons += picking.total_product_qty or 0.0
                    total_weight += picking.total_weight or 0.0

            record.total_cartons = total_cartons
            record.total_weight = total_weight

    

    # @api.model
    # def _get_driver_domain(self):
    #     """Filters dispatch details based on the logged-in driver"""
    #     if self.env.user.has_group('base.group_system'):  # Admins see all
    #         return []
    #     elif self.env.user.employee_id and self.env.user.employee_id.job_id.name == 'Driver':
    #         return [('driver_details', '=', self.env.user.employee_id.id)]
    #     return [('id', '=', False)]  # Show no records if the user is not a driver



