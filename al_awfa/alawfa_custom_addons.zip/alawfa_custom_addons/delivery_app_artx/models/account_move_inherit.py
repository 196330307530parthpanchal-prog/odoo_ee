from odoo import models, fields, api,_
from odoo.exceptions import UserError
from datetime import datetime, timedelta

class AccountMove(models.Model):
    _inherit = 'account.move'

    invoice_reference = fields.Char(string="Invoice Reference", help="Reference of the hand-made bill made by Drivers during Delivery")
    move_type = fields.Selection(
        selection=[
            ('entry', 'Journal Entry'),
            ('out_invoice', 'Customer Invoice'),
            ('out_refund', 'Customer Credit Note'),
            ('in_invoice', 'Vendor Bill'),
            ('in_refund', 'Vendor Debit Note'),
            ('out_receipt', 'Sales Receipt'),
            ('in_receipt', 'Purchase Receipt'),
        ],
        string='Type',
        required=True,
        readonly=True,
        tracking=True,
        change_default=True,
        index=True,
        default="entry",
    )

    def action_send_vendor_email(self):
        self.ensure_one()

        if self.move_type == 'in_invoice':
            template = self.env.ref('delivery_app_artx.email_template_vendor_bill')
        elif self.move_type == 'in_refund':
            template = self.env.ref('delivery_app_artx.email_template_vendor_refund')
        else:
            return

        return {
            'type': 'ir.actions.act_window',
            'name': 'Send Email',
            'res_model': 'mail.compose.message',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_model': 'account.move',
                'default_res_ids': [self.id],
                'default_use_template': True,
                'default_template_id': template.id,
                'default_composition_mode': 'comment',
                'force_email': True,
            }
        }

    def action_round_up(self):
        """Assign Round Off Up method"""
        company = self.company_id

        rounding_up = self.env['account.cash.rounding'].search([
            ('name', '=', 'Round Off Up'),
        ], limit=1)
        print(company)
        print(rounding_up.name,rounding_up.profit_account_id.company_id)
        if not rounding_up:
            rounding_up= self.env['account.cash.rounding'].search([
                ('name', '=', 'Round Off Up S'),
            ], limit=1)
            if not rounding_up:
                raise UserError("No 'Round Off Up' Cash Rounding Method found!")
        self.invoice_cash_rounding_id = rounding_up.id

    def action_round_down(self):
        """Assign Round Off Down method"""
        company = self.company_id
        rounding_down = self.env['account.cash.rounding'].search([('name', '=', 'Round Off Down'),], limit=1)
        print(company)
        print(rounding_down.name, rounding_down.profit_account_id.company_id)
        if not rounding_down:
            rounding_down = self.env['account.cash.rounding'].search([('name', '=', 'Round Off Down S'), ], limit=1)
            if not rounding_down:
                raise UserError("No 'Round Off Down' Cash Rounding Method found!")
        self.invoice_cash_rounding_id = rounding_down.id

    is_driver = fields.Boolean(
        string="Is Driver",
        compute="_compute_is_driver",
    )

    @api.depends_context('uid')
    def _compute_is_driver(self):
        is_driver = self.env.user.has_group('delivery_app_artx.group_driver')
        for record in self:
            record.is_driver = is_driver

    is_admin_user = fields.Boolean(
        compute='_compute_is_admin_user'
    )

    @api.depends_context('uid')
    def _compute_is_admin_user(self):
        for rec in self:
            logistics_allowed = (
                    rec.move_type == 'in_invoice'
                    and rec.journal_id.type == 'purchase'
            )
            print("logistic allowed : ", logistics_allowed)
            print("isadmin : ", self.env.user.has_group('base.group_system'))

            rec.is_admin_user = logistics_allowed or self.env.user.has_group('base.group_system')

    # def action_print_outstanding_pdf(self):
    #     if not self:
    #         return
    #
    #     # optional safety filter (only posted invoices)
    #     invoices = self.filtered(lambda m: m.move_type == 'out_invoice' and m.state == 'posted')
    #
    #     return self.env.ref(
    #         'delivery_app_artx.report_customer_outstanding_pdf'
    #     ).report_action(invoices)

    def action_print_outstanding_pdf(self):
        if not self:
            return

        # Only posted customer invoices
        invoices = self.filtered(
            lambda m: m.move_type == 'out_invoice' and m.state == 'posted'
        )

        # Oldest to latest
        invoices = invoices.sorted(
            key=lambda m: (
                m.invoice_date or m.date or fields.Date.today(),
                m.name or ''
            )
        )

        return self.env.ref(
            'delivery_app_artx.report_customer_outstanding_pdf'
        ).report_action(invoices)

