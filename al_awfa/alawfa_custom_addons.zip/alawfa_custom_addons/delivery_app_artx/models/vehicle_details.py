from odoo import api,fields,models

class VehicleDetails(models.Model):
    _name='vehicle.details'
    _description = 'Vehicle Details Master'
    _rec_name = 'vehicle_number'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    vehicle_number = fields.Char(string="Vehicle Number",required=True,tracking=True)
    vehicle_make = fields.Char(string="Vehicle Make",required=True,tracking=True)
    vehicle_model = fields.Char(string="Vehicle Model",required=True,tracking=True)
    vehicle_assigned_to= fields.Many2one('hr.employee', string='Driver', domain=[('job_id.name', 'in', ('Driver','driver','DRIVER'))], required=True)
    vehicle_note= fields.Boolean(string="Vehicle Note or not",tracking=True)


