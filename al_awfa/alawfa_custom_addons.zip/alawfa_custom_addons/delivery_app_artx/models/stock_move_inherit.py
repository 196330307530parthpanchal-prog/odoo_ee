from odoo import models, fields, api
from datetime import datetime


class StockMove(models.Model):
    _inherit = "stock.move"


    demand_box = fields.Integer(string="Demand Box")
    delivered_box = fields.Integer(string="Delivered Box")
    qty = fields.Float(related='product_uom_qty', string='Quantity', store=True)

    box_boolean = fields.Boolean(
        related="product_id.product_tmpl_id.box_boolean",
        store=False
    )

    total_weight_dispatch_line = fields.Float(
        string="Total Weight (in Kgs)",
        compute="_compute_total_weight_dispatch_line",
        store=True
    )


    dispatch_order_qty = fields.Float(
        string="Quantity",
        compute="_compute_dispatch_order_qty",
        store=True
    )

    dispatch_order_weight = fields.Float(
        string="Total Weight (in Kgs)",
        compute="_compute_dispatch_order_weight",
        store=True
    )

    @api.depends('delivered_box', 'product_uom_qty')
    def _compute_dispatch_order_qty(self):
        for move in self:
            if move.delivered_box:
                # delivered_box asel tar toch ghe
                move.dispatch_order_qty = move.delivered_box
            else:
                # delivered_box nasel tar product_uom_qty ghe
                # move.dispatch_order_qty = move.product_uom_qty or 0
                move.dispatch_order_qty = 0
    # def _is_stock_available_anywhere(self, product):
    #     quants = self.env['stock.quant'].search([
    #         ('product_id', '=', product.id),
    #         ('location_id.usage', '=', 'internal')
    #     ])
    #
    #     return any(q.quantity > 0 for q in quants)
    #
    # def _get_relevant_state_among_moves(self):
    #     state = super()._get_relevant_state_among_moves()
    #
    #     for move in self:
    #         product = move.product_id
    #
    #         is_available = self._is_stock_available_anywhere(product)
    #
    #         # ❌ Rule B: No stock anywhere
    #         if not is_available:
    #             return 'waiting'
    #         if is_available:
    #             return 'assigned'
    #
    #     return state

    def _split(self, qty, restrict_partner_id=False):
        self.ensure_one()

        new_move_vals = super()._split(qty, restrict_partner_id)

        if not new_move_vals:
            return new_move_vals

        # Only apply if boxes enabled
        if not hasattr(self, 'demand_box'):
            return new_move_vals

        total_boxes = self.demand_box or 0
        delivered_boxes = self.delivered_box or 0

        # ✅ Remaining = what user did NOT deliver
        remaining_boxes = total_boxes - delivered_boxes

        # Safety
        if remaining_boxes < 0:
            remaining_boxes = 0

        # ✅ Backorder move
        new_move_vals[0]['demand_box'] = remaining_boxes
        new_move_vals[0]['delivered_box'] = 0  # nothing delivered yet

        # ✅ Original move (done part)
        self.demand_box = delivered_boxes
        # keep delivered_box as is

        return new_move_vals

    

    # @api.depends(
    #     'delivered_box',
    #     'product_uom_qty',
    #     'product_id.product_tmpl_id.weight'
    # )
    # def _compute_total_weight_dispatch_line(self):
    #     for move in self:
    #         weight = move.product_id.product_tmpl_id.weight or 0

    #         if move.delivered_box:
    #             # delivered_box × weight
    #             move.total_weight_dispatch_line = (move.delivered_box or 0) * weight
    #         else:
    #             # qty × weight
    #             move.total_weight_dispatch_line = (move.product_uom_qty or 0) * weight

    @api.depends(
        'delivered_box',
        'product_uom_qty',
        'product_id.product_tmpl_id.weight'
    )
    def _compute_total_weight_dispatch_line(self):
        for move in self:
            # 🔴 KEY LOGIC
            if move.delivered_box and move.delivered_box > 0:
                move.total_weight_dispatch_line = move.product_uom_qty or 0.0
            else:
                weight = move.product_id.product_tmpl_id.weight or 0.0
                move.total_weight_dispatch_line = (move.product_uom_qty or 0.0) * weight

    # @api.depends(
    #     'dispatch_order_qty',
    #     'product_id.product_tmpl_id.weight'
    # )
    # def _compute_dispatch_order_weight(self):
    #     for move in self:
    #         weight = move.product_id.product_tmpl_id.weight or 0.0
    #         move.dispatch_order_weight = (move.dispatch_order_qty or 0.0) * weight

    
    @api.depends(
        'delivered_box',
        'qty',
        'product_id.product_tmpl_id.weight'
    )
    def _compute_dispatch_order_weight(self):
        for move in self:
            weight = move.product_id.product_tmpl_id.weight or 0.0

            if move.delivered_box:
                move.dispatch_order_weight = move.qty or 0.0
            else:
                move.dispatch_order_weight = (move.qty or 0.0) * weight


   

  