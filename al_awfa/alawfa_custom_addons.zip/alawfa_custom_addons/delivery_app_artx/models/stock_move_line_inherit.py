from odoo import models, fields, api, _

class StockMoveLine(models.Model):
    _inherit = "stock.move.line"

    partner_id = fields.Many2one(
        "res.partner",
        string="Partner",
        related="move_id.picking_id.partner_id",
        store=True,
    )

    boxes = fields.Integer(string="CRT",store=True)
    
    picking_type_code = fields.Selection(
        related="picking_id.picking_type_id.code",
        store=True
    )


    @api.model
    def create(self, vals):
        if not vals.get("company_id"):
            vals["company_id"] = self.env.company.id

        rec = super().create(vals)

        product = rec.move_id.product_id.product_tmpl_id
        move_type = rec.picking_id.picking_type_id.code
        boxes = rec.boxes or 0

        if move_type == "incoming":
            product.updated_box += boxes

        elif move_type == "outgoing":
            product.updated_box -= boxes

        return rec
    
    def write(self, vals):

        # If wizard changed qty → NO automatic delivered logic
        if self.env.context.get("manual_box_update"):
            return super(StockMoveLine, self).write(vals)

        for rec in self:

            move = rec.move_id
            product = move.product_id.product_tmpl_id
            move_type = rec.picking_id.picking_type_id.code

            move_lines = move.move_line_ids.sorted("id")
            delivered = move.delivered_box or 0

            # =====================================================
            # AUTO DIFF ONLY WHEN DELIVERY HAPPENS
            # =====================================================

            old_boxes = rec.boxes or 0
            new_boxes = delivered if rec.id == move_lines[0].id else 0

            diff = new_boxes - old_boxes

            if diff != 0:
                if move_type == "incoming":
                    product.updated_box += diff
                elif move_type == "outgoing":
                    product.updated_box -= diff

            vals_fixed = vals.copy()
            vals_fixed['boxes'] = new_boxes

            super(StockMoveLine, rec).write(vals_fixed)

        return True
