from odoo import models, fields, api, _

class DispatchOrderDetails(models.Model):
    _name = 'dispatch.order.details'
    _description = 'Dispatch Order Details'
    _rec_name = 'batch_details'

    batch_details = fields.Many2one('dispatch.details', string='Batch')
    schedule_date_date = fields.Date(related='batch_details.schedule_date_date', string='Schedule Date (Date only)')
    order_number = fields.Many2one('stock.picking', string='Order Number',)
    order_status = fields.Selection(
        'stock.picking',
        related='order_number.state',
        string="Status",
        store=True,
        readonly=True
    )
    order_carton_qty = fields.Float(related='order_number.total_product_qty',string="Total Cartons",store=True,readonly=True)
    total_crt = fields.Float(string="Total Cartons",compute="_compute_total_crt",store=True)

    total_order_weight = fields.Float(
        string="Total Weight",
        compute="_compute_total_order_weight",
        store=True
    )

    @api.depends(
        'order_number.move_ids.total_weight_dispatch_line'
    )
    def _compute_total_order_weight(self):
        for rec in self:
            rec.total_order_weight = sum(
                rec.order_number.move_ids.mapped('total_weight_dispatch_line')
            )

   
    
    order_weight = fields.Float(related='order_number.total_weight',string="Total Weight",store=True,readonly=True)
    sale_order_number= fields.Char(string="Sale order number",related='order_number.origin',store=True, readonly=True)
    customer_name = fields.Many2one('res.partner',related='order_number.partner_id', string="Customer", store=True, readonly=True)
    # customer_address = fields.Many2one('res.partner',related='customer_name.contact_address', string="Street", readonly=True)

    driver_details = fields.Many2one(
        'hr.employee',
        string='Driver',
        related='batch_details.driver_details',
        store=True,
        readonly=True
    )
    vehicle_details = fields.Many2one(
        'vehicle.details',
        string='Vehicle',
        related='batch_details.vehicle_details',
        store=True,
        readonly=True
    )
    order_rescheduled = fields.Boolean(string="Rescheduled", default=False)

    order_lines = fields.One2many(
        'stock.move',
        compute="_compute_order_lines",
        string="Order Lines",
        readonly=True
    )

   
    # @api.depends('order_number', 'order_number.move_ids_without_package.delivered_box')
    # def _compute_total_crt(self):
    #     for rec in self:
    #         total = 0
    #         picking = rec.order_number
    #         if picking:
    #             for move in picking.move_ids_without_package:
    #                 total += move.delivered_box or 0
    #         rec.total_crt = total

    @api.depends(
    'order_number',
    'order_number.move_ids_without_package.delivered_box',
    'order_number.move_ids_without_package.product_uom_qty'
    )
    def _compute_total_crt(self):
        for rec in self:
            total = 0
            picking = rec.order_number
            if picking:
                for move in picking.move_ids_without_package:
                    # if move.delivered_box:
                    if move.product_id.box_boolean:
                        # delivered_box asel tar toch add
                        total += move.delivered_box
                    else:
                        # delivered_box nasel tar product_uom_qty add
                        total += move.product_uom_qty or 0
            rec.total_crt = total

    # @api.depends(
    # 'order_number',
    # 'order_number.move_ids_without_package.delivered_box',
    # 'order_number.move_ids_without_package.product_uom_qty',
    # 'order_number.move_ids_without_package.product_id.product_tmpl_id.weight'
    # )
    # def _compute_total_order_weight(self):
    #     for rec in self:
    #         total = 0.0
    #         if rec.order_number:
    #             for move in rec.order_number.move_ids_without_package:
    #                 weight = move.product_id.product_tmpl_id.weight or 0

    #                 if move.delivered_box:
    #                     # delivered_box × weight
    #                     total += (move.delivered_box or 0) * weight
    #                 else:
    #                     # qty × weight
    #                     total += (move.product_uom_qty or 0) * weight

    #         rec.total_order_weight = total



    @api.depends('order_number')
    def _compute_order_lines(self):
        for record in self:
            if record.order_number:
                record.order_lines = record.order_number.move_ids
            else:
                record.order_lines = False

    def unlink(self):
        for record in self:
            picking = record.order_number
            if picking and picking.state == 'driver_assigned':
                # ✅ Change state to 'assigned' (ready)
                # picking.write({'state': 'assigned'})
                picking._compute_state()
        return super().unlink()