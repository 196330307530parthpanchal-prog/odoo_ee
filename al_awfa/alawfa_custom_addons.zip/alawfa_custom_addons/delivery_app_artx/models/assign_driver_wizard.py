from odoo import models, fields ,api
from odoo.service.db import dispatch
from datetime import datetime, timedelta
from odoo.exceptions import ValidationError


class AssignDriverWizard(models.TransientModel):
    _name = 'assign.driver.wizard'
    _description = 'Assign Driver Wizard'

    SELF_PICKUP_NAME = "SPU-Store PickUp"  # If you want, move this to ir.config_parameter
    driver_id = fields.Many2one('hr.employee', string='Driver', domain=[('job_id.name', 'in', ('Driver','driver','DRIVER'))], required=True)
    vehicle_id = fields.Many2one('vehicle.details', string='Vehicle')
    vehicle_alter_name = fields.Char(string='Notes', default='')
    is_self_pickup = fields.Boolean(string='Is Self Pickup?', default=False, help="Derived from driver selection.")
    schedule_date = fields.Datetime(string='Schedule Date', required=True, default=fields.Datetime.now)
    time_of_day = fields.Selection(
        [('morning', 'Morning'), ('evening', 'Evening')],
        string="Delivery Time",
        default='morning'
    )

    @api.depends('vehicle_id')
    def _compute_show_note(self):
        for wizard in self:
            wizard.is_self_pickup = bool(wizard.vehicle_id.vehicle_note)

    @api.onchange('driver_id')
    def _onchange_driver_id(self):
        # self.is_self_pickup = bool(self.driver_id and self.driver_id.name == self.SELF_PICKUP_NAME)
        if self.driver_id:
            # if self.driver_id.name=='SPU-Store PickUp':
            vehicle = self.env['vehicle.details'].search([('vehicle_assigned_to', '=', self.driver_id.id)], limit=1)
            self.vehicle_id = vehicle if vehicle else False
            self.is_self_pickup = bool(self.vehicle_id.vehicle_note)
            # check = self.driver_id.vehicle_note
            #
            # if check:
            #     self.vehicle_id = False
            # else:




    def action_confirm(self):
        selected_orders = self.env['stock.picking'].browse(self._context.get('active_ids', []))
        DispatchDetails = self.env['dispatch.details']
        typecheck = 'outgoing'
        for i in selected_orders:
            print('typecheck is iterating')
            typecheck = i.picking_type_id.code
            print('typecheck changed to', typecheck)

        print('final typecheck is : ', typecheck)

        for order in selected_orders:
            if order.dispatch_order_id:
                raise ValidationError(
                    f"Order {order.name} is already assigned to a dispatch."
                )

        # Search for the latest dispatch for this driver
        # last_dispatch = DispatchDetails.search([
        #     ('driver_details', '=', self.driver_id.id)
        # ], order='create_date desc', limit=1)

        target_date = self.schedule_date.date()
        start_of_day = datetime.combine(target_date, datetime.min.time())
        end_of_day = start_of_day + timedelta(days=1)
        time_of_day = self.time_of_day.capitalize()


        last_dispatch = DispatchDetails.search([
            ('driver_details', '=', self.driver_id.id),
            ('schedule_date', '>=', start_of_day),
            ('schedule_date', '<', end_of_day),
            ('batch_type', '=', typecheck),
        ], order='create_date desc', limit=1)

        print(time_of_day,'\n')

        print(last_dispatch,'\n')
        if last_dispatch:
            print(last_dispatch.schedule_date.date(), " IS EQUAL ", self.schedule_date.date())

        if last_dispatch and not last_dispatch.email_sent and last_dispatch.schedule_date.date() == self.schedule_date.date():
            # ✅ Reuse existing batch if email not sent


            for order in selected_orders:
                self.env['dispatch.order.details'].create({
                    'batch_details': last_dispatch.id,
                    'order_number': order.id

                })
                order.write({'state': 'driver_assigned'})
        else:
            # 🚀 Create new batch
            dispatch = DispatchDetails.create({
                'schedule_date': self.schedule_date,
                'driver_details': self.driver_id.id,
                'vehicle_details': self.vehicle_id.id,
                'vehicle_alter_name': self.vehicle_alter_name,
                'is_self_pickup': self.is_self_pickup,
                'time_of_day': time_of_day
            })

            for order in selected_orders:
                self.env['dispatch.order.details'].create({
                    'batch_details': dispatch.id,
                    'order_number': order.id,
                })
                order.write({'state': 'driver_assigned'})

        return {'type': 'ir.actions.act_window_close'}