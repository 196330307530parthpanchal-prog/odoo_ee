from odoo import fields, models

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    cash_journal_ids = fields.Many2many('account.journal', string="Cash Journals", domain="[('type','=','cash')]")
