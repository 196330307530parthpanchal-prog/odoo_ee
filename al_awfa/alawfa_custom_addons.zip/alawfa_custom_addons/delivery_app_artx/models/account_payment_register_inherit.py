

from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import date

class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    journal_id = fields.Many2one(
        'account.journal',
        string='Journal',
        domain="[('id', 'in', available_journal_ids)]"
    )
    available_journal_ids = fields.Many2many(
        'account.journal',
        compute='_compute_available_journals',
        string="Available Journals"
    )

    @api.depends('company_id')
    def _compute_available_journals(self):
        for wizard in self:
            company = wizard.company_id

            user_journals = self.env.user.cash_journal_ids.filtered(
                lambda j: j.company_id == company
            )

            if user_journals:
                wizard.available_journal_ids = user_journals
            else:
                wizard.available_journal_ids = self.env['account.journal'].search([
                    ('type', 'in', ['cash', 'bank']),
                    ('company_id', '=', company.id)
                ])

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)

        # company_id is already set by Odoo in this wizard
        company_id = res.get('company_id')
        company = self.env['res.company'].browse(company_id)

        user_journals = self.env.user.cash_journal_ids.filtered(
            lambda j: j.company_id == company
        )

        if user_journals:
            res['journal_id'] = user_journals[0].id
        else:
            journal = self.env['account.journal'].search([
                ('type', 'in', ['cash', 'bank']),
                ('company_id', '=', company.id)
            ], limit=1)
            if journal:
                res['journal_id'] = journal.id

        return res

    @api.depends(
        'can_edit_wizard',
        'source_amount',
        'source_amount_currency',
        'source_currency_id',
        'company_id',
        'currency_id',
        'payment_date'
    )
    def _compute_amount(self):
        for wizard in self:
            existing_amount = wizard.amount
            print(wizard.amount,wizard._origin, wizard._origin.amount)

            if wizard.amount:
                print('_compute_price_unit skipped')
                continue

            super(AccountPaymentRegister, wizard)._compute_amount()
            print('original _compute_price_unit in payment called')