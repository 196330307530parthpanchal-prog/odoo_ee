from odoo import models, fields, api
from collections import defaultdict
from odoo.exceptions import UserError
import math
import itertools

class StockMove(models.Model):
    _inherit = 'stock.move'

    product_uom_qty = fields.Float(string="Demand Qty")
    quantity = fields.Float(string="Delivered Qty")

    product_name = fields.Char(related='product_id.name', string='Product Name', store=True)
    product_category_id = fields.Many2one(
        'product.category',
        string="Product Category",
        related='product_id.categ_id',
        store=True,
    )
    delivery_number = fields.Char(related='picking_id.name', string='Delivery No', store=True)
    delivery_number_1 = fields.Many2one(related='picking_id', string='Delivery No', store=True)
    sale_order_number = fields.Char(related='sale_line_id.order_id.name', string='Sale Order No', store=True)
    status = fields.Selection(related='picking_id.state', string='Status', store=True)
    payment_term_id = fields.Many2one(related='sale_line_id.order_id.payment_term_id', string='Payment Term', store=True)
    dispatch_details_number = fields.Char(related='picking_id.batch_id', string='Dispatch No', store=True)  # assuming picking has dispatch_details_id
    driver_details= fields.Many2one(related='picking_id.dispatch_order_id.batch_details.driver_details', string='Driver', store=True)  # assuming picking has dispatch_details_id
    vehicle_details= fields.Many2one(related='picking_id.dispatch_order_id.batch_details.vehicle_details', string='Vehicle', store=True)  # assuming picking has dispatch_details_id
    dispatch_date= fields.Datetime(related='picking_id.dispatch_order_id.batch_details.create_date', string='Dispatch Date', store=True)  # assuming picking has dispatch_details_id

    schedule_date = fields.Datetime(string="Schedule Date", related='picking_id.dispatch_order_id.batch_details.schedule_date', store=True)
    schedule_date_date = fields.Date(string="Schedule Date (Date Only)", compute="_compute_schedule_date_date",
                                     store=True)

    @api.depends("schedule_date")
    def _compute_schedule_date_date(self):
        for rec in self:
            if rec.schedule_date:
                print('date found s.m.: ', rec.schedule_date)
                rec.schedule_date_date = fields.Date.context_today(rec, rec.schedule_date)
                print('date extracted s.m.: ',rec.schedule_date_date)

    unit_price = fields.Float(related='sale_line_id.price_unit', string='Unit Price', store=True)
    qty = fields.Float(related='product_uom_qty', string='Quantity', store=True)
    # dispatch_order_qty = fields.Integer(string="Quantity")
    total_price = fields.Float(compute='_compute_total_price', string='Total Price', store=True)

    customer_name = fields.Char(related='sale_line_id.order_id.partner_id.name', string='Customer Name', store=True)
    customer_street = fields.Char(related='sale_line_id.order_id.partner_id.street', string='Customer Address', store=True)
    product_weight = fields.Float(
        string="Product weight",
        related='product_tmpl_id.weight',
        store=True,
    )
    total_weight=fields.Float(string='Total Weight(in Kgs)',compute='_compute_weight',store=True)
    invoice_id = fields.Many2one(
        'account.move',
        string='Invoice',
        compute='_compute_invoice_id',
        store=True,
    )

    invoice_number = fields.Char(
        related='invoice_id.name',
        string='Invoice Number',
        store=True,
    )

    invoice_payment_status = fields.Selection(
        related='invoice_id.payment_state',
        string='Payment Status',
        store=True,
    )

    @api.depends('sale_line_id.invoice_lines.move_id')
    def _compute_invoice_id(self):
        for move in self:
            # Get the first invoice (most typical case)
            print('invoice status and number called')
            invoice = move.sale_line_id.invoice_lines.mapped('move_id')[:1]
            print(invoice)
            move.invoice_id = invoice and invoice[0] or False

    @api.depends('qty','product_weight')
    def _compute_weight(self):
        for move in self:
            print("qty=", move.qty, " and unit weight =", move.product_weight)
            if(move.product_id.tracking in ['lot']):
                move.total_weight = move.qty
            else:
                move.total_weight = move.qty * move.product_weight

    @api.depends('qty', 'unit_price')
    def _compute_total_price(self):
        for move in self:
            print("qty=",move.qty," and unit price =",move.unit_price)
            move.total_price = move.qty * move.unit_price

            if move.picking_id:
                move.picking_id._compute_reference_tooltip()

    def _get_or_create_adjustment_lot(self, product):
        """Return the Adjustment Lot for this product, create if not exists."""
        print('_get_or_create_adjustment_lot called')
        lot = self.env['stock.lot'].search([
            ('product_id', '=', product.id),
            ('name', '=', '~ADJUSTMENT-LOT')
        ], limit=1)
        if not lot:
            lot = self.env['stock.lot'].create({
                'product_id': product.id,
                'name': '~ADJUSTMENT-LOT',
                'company_id': self.env.company.id,
            })
        product.adjustment_lot_id = lot
        print('assigned adjustment lot to product')
        return lot



    @api.onchange('quantity')
    def _onchange_quantity_done_adjustment_lot(self):
        print('_onchange_quantity_done_adjustment_lot called')
        print(self.picking_type_id.code)
        if self.picking_type_id.code != 'incoming':
            for move in self:
                if move.product_id.tracking == 'lot' and move.move_line_ids:
                    total_qty_done = sum(move.move_line_ids.mapped('quantity'))
                    adj_lot = move._get_or_create_adjustment_lot(move.product_id)
                    print("demand, qty, sum : ",move.product_uom_qty,', ',move.quantity,', ',total_qty_done)
                    if total_qty_done < move.quantity:
                        delta = move.quantity - total_qty_done
                        print('delta =',delta)
                        # 1. Update the last real lot line in delivery
                        last_line = move.move_line_ids[-1]
                        last_line.quantity += delta
                        print('last_line.quantity = ',last_line.quantity)
                        # 2. Update Adjustment Lot quantity in stock
                        # adj_lot = move._get_or_create_adjustment_lot(move.product_id)
                        # adj_lot.reserved_
                        # print('adj_lot made ')
                        # quant = self.env['stock.quant'].search([
                        #     ('lot_id', '=', adj_lot.id),
                        #     ('product_id', '=', move.product_id.id),
                        #     ('location_id', '=', move.location_id.id),
                        #     ('company_id', '=', move.company_id.id),
                        # ], limit=1)
                        # print('quant check ')
                        # if quant:
                        #     quant.quantity += delta
                        # else:
                        #     self.env['stock.quant'].create({
                        #         'lot_id': adj_lot.id,
                        #         'product_id': move.product_id.id,
                        #         'location_id': move.location_id.id,
                        #         'quantity': delta,
                        #         'company_id': move.company_id.id,
                        #     })
                        print('fin')
        print('fin2')
        return

    no_of_lots_wanted = fields.Integer("No of Lots Wanted", default=0)

    def action_generate_lot_names(self, no_of_lots):
        """Generate lot names using product's ir.sequence"""
        self.ensure_one()
        product = self.product_id

        # Suppose you have a field on product to link the sequence
        if not product.lot_sequence_id:
            raise UserError("No lot sequence configured for this product.")

        seq = product.lot_sequence_id
        lot_names = [seq.next_by_id() for _ in range(no_of_lots)]
        return lot_names

    # @api.onchange('no_of_lots_wanted')
    # def _onchange_no_of_lots_wanted(self):
    #     """Auto-create/split lots when user changes no_of_lots_wanted."""
    #     # for move in self:
    #
    #     move=self
    #
    #     product = move.product_id
    #     picking = move.picking_id
    #
    #     # Only apply on incoming shipments for lot-tracked products
    #     if not (picking and picking.picking_type_id.code == 'incoming' and product.tracking == 'lot'):
    #         return
    #     print('move ',move)
    #     print('move.move_line_ids ',move.move_line_ids)
    #     # move._do_unreserve()
    #     print('move.move_line_ids ', move.move_line_ids)
    #     # move.move_line_ids.unlink()
    #     print('product ',product)
    #     print('product uom ',move.product_uom)
    #     print('qty ',move.quantity)
    #     print('picking ',picking)
    #     total_qty = move.product_uom_qty
    #     if not total_qty:
    #         return
    #     print('hurdle passed')
    #     no_of_lots = move.no_of_lots_wanted
    #     print("no of lots ",no_of_lots)
    #     if no_of_lots <= 0:
    #         return
    #
    #     qty_per_lot = round(total_qty / no_of_lots, 2)
    #     print("qty per lot",qty_per_lot)
    #
    #     # Remove old move lines only in onchange (not yet saved to DB)
    #     # move.move_line_ids = [(5, 0, 0)]
    #
    #     # Create new move lines with lots
    #     new_lines = []
    #     print('checkpoint1')
    #     for i in range(no_of_lots):
    #         if product.lot_sequence_id:
    #             lot_name = product.lot_sequence_id.next_by_id()
    #         else:
    #             lot_name = f"{product.default_code or product.name}-LOT-{i + 1}"
    #
    #         lot = self.env['stock.lot'].create({
    #             'name': lot_name,
    #             'product_id': product.id,
    #             'company_id': move.company_id.id,
    #         })
    #         print('name lot ',lot.name)
    #         new_lines.append((0, 0, {
    #             'product_id': product.id,
    #             'lot_id': lot.id,
    #             'lot_name': lot.name,
    #             'quantity': qty_per_lot,
    #             'product_uom_id': move.product_uom.id,
    #             'location_id': move.location_id.id,
    #             'location_dest_id': move.location_dest_id.id,
    #         }))
    #
    #     move.move_line_ids = new_lines

    @api.model
    def _action_assign(self):


        res = super()._action_assign()

        if self.picking_type_id.code == 'incoming':
            print('returning res')
            return res

        for move in self:

            print("Sanity checks")
            print(move.has_tracking)
            print(move.state)

            if move.has_tracking == 'lot' and move.state in ('confirmed', 'waiting', 'assigned', 'partially_available'):
                move._do_unreserve()

                required_qty = move.product_uom_qty
                location = move.location_id

                min_avg_lot_weight = 0.6*(move.product_id.avg_cartons_weight)


                # Step 1: Gather available (non-zero, unreserved) lots
                quants = self.env['stock.quant'].search([
                    ('product_id', '=', move.product_id.id),
                    ('location_id', 'child_of', location.id),
                    ('lot_id', '!=', move.product_id.adjustment_lot_id.id),
                    ('quantity', '>', min_avg_lot_weight),
                ])



                lot_qty_map = defaultdict(float)
                for q in quants:
                    print(f'Lot no: {q.lot_id}, quantity = {q.quantity},  reserved_quantity={q.reserved_quantity}')
                    available_qty = q.quantity - q.reserved_quantity
                    if available_qty > min_avg_lot_weight:
                        lot_qty_map[q.lot_id] += available_qty

                lot_list = [(lot, qty) for lot, qty in lot_qty_map.items()]
                if not lot_list:
                    continue

                # Step 2: Compute average lot weight
                total_qty = sum(qty for _, qty in lot_list)
                total_lots = len(lot_list)
                # avg_lot_weight_1 = total_qty / total_lots if total_lots > 0 else 1
                avg_lot_weight = move.product_id.avg_cartons_weight
                print('avg_lot_weight = ',avg_lot_weight)
                # Step 3: Estimate number of lots needed
                lots_required = required_qty / avg_lot_weight
                print('lots_required = ', lots_required)
                fractional_part = lots_required - int(lots_required)
                print('fractional_part = ', fractional_part)
                # print('fractional_part * avg_lot_weight = ', fractional_part * avg_lot_weight)
                extra = 1 if (fractional_part) >= 0.5 else 0
                print('extra = ', extra)
                lots_to_take = int(lots_required)+extra
                print('lots_to_take = ', lots_to_take)


                # Step 4: Sort lots and pick top N
                # sorted_lots = sorted(lot_list, key=lambda x: x[1], reverse=True)
                our_qty=0
                selected_lots = lot_list[:lots_to_take]
                for lot, qty in selected_lots:
                    our_qty+=qty

                print('our_qty = ',our_qty)
                # if(required_qty - our_qty  > 5):
                #     print('lost increase by 1')
                #     selected_lots = lot_list[:lots_to_take+1]
                #     our_qty=0
                #     for lot, qty in selected_lots:
                #         our_qty += qty
                #
                #     print('our_qty = ', our_qty)

                # Step 5: Create move lines for selected lots
                for lot, qty in selected_lots:
                    self.env['stock.move.line'].create({
                        'move_id': move.id,
                        'product_id': move.product_id.id,
                        'location_id': move.location_id.id,
                        'location_dest_id': move.location_dest_id.id,
                        'lot_id': lot.id,
                        'product_uom_id': move.product_uom.id,
                        'quantity': qty,
                    })

                move.state = 'assigned'

        return res

    # best working
    # @api.model
    # def _action_assign(self):
    #     res = super()._action_assign()
    #
    #     for move in self:
    #         if move.has_tracking == 'lot' and move.state in ('confirmed', 'waiting', 'assigned'):
    #             move._do_unreserve()
    #
    #             required_qty = move.product_uom_qty
    #             location = move.location_id
    #
    #             # Step 1: Gather available (non-zero, unreserved) lots
    #             quants = self.env['stock.quant'].search([
    #                 ('product_id', '=', move.product_id.id),
    #                 ('location_id', 'child_of', location.id),
    #                 ('lot_id', '!=', False),
    #                 ('quantity', '>', 0),
    #             ])
    #
    #             print(f"\n>>> Processing Move: {move.product_id.name} | Required Qty: {required_qty}")
    #             print(f">>> Found {len(quants)} quants (with quantity > 0 and lot_id)")
    #
    #             lot_qty_map = defaultdict(float)
    #             for q in quants:
    #                 available_qty = q.quantity - q.reserved_quantity
    #                 if available_qty > 0:
    #                     lot_qty_map[q.lot_id] += available_qty
    #
    #             lot_list = [(lot, qty) for lot, qty in lot_qty_map.items()]
    #
    #             print(">>> Candidate Lots with Available Qty:")
    #             for lot, qty in lot_list:
    #                 print(f"    Lot: {lot.name}, Available: {qty}")
    #
    #             if not lot_list:
    #                 print(">>> No valid lots found. Skipping move.")
    #                 continue
    #
    #             # Step 2: Find the best combination (closest total qty)
    #             best_combination = None
    #             best_diff = float('inf')
    #             best_total = 0
    #
    #             for i in range(1, len(lot_list) + 1):
    #                 for combo in itertools.combinations(lot_list, i):
    #                     combo_total = sum(q for _, q in combo)
    #                     diff = abs(combo_total - required_qty)
    #                     if diff < best_diff:
    #                         best_diff = diff
    #                         best_total = combo_total
    #                         best_combination = combo
    #                     if best_diff == 0:
    #                         break
    #                 if best_diff == 0:
    #                     break
    #
    #             print(f">>> Selected Lots (Total Qty: {best_total}, Diff: {best_diff}):")
    #             for lot, qty in best_combination:
    #                 print(f" Selected → Lot: {lot.name}, Qty: {qty}")
    #
    #             # Step 3: Reserve the best combination of whole lots
    #             if best_combination:
    #                 for lot, qty in best_combination:
    #                     self.env['stock.move.line'].create({
    #                         'move_id': move.id,
    #                         'product_id': move.product_id.id,
    #                         'location_id': move.location_id.id,
    #                         'location_dest_id': move.location_dest_id.id,
    #                         'lot_id': lot.id,
    #                         'product_uom_id': move.product_uom.id,
    #                         # 'qty_done': 0.0,
    #                         'quantity': qty,  # Reserve
    #                     })
    #                     print(f"    ✓ Reserved: Lot {lot.name} | Qty {qty}")
    #
    #                 move.state = 'assigned'
    #                 print(">>> Move marked as assigned.\n")
    #     return res

class DispatchOrderLineView(models.Model):
    _name = 'dispatch.order.line.view'
    _description = 'Dispatch Order Line View'
    _auto = False  # important: this is a database view, not a regular model
    _order = 'batch_id, order_id, product_id'

    batch_id = fields.Many2one('dispatch.details', string="Dispatch Number")
    order_id = fields.Many2one('sale.order', string="Sale Order")
    delivery_id = fields.Many2one('stock.picking', string="Delivery")
    partner_id = fields.Many2one('res.partner', string="Party")
    location = fields.Char(string="Location")
    product_id = fields.Many2one('product.product', string="Item")
    brand = fields.Char(string="Brand")
    qty = fields.Float(string="Qty")
    dispatch_order_qty = fields.Integer(string="Quantity")
    rate = fields.Float(string="Rate")
    total = fields.Float(string="Total")


