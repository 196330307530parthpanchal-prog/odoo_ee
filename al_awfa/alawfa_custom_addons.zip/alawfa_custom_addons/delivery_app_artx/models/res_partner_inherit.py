from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from odoo.exceptions import UserError

class ResPartner(models.Model):
    _inherit = 'res.partner'

    google_location_link = fields.Char("Google Link Location", store=True, required=True)
    street = fields.Char(required=True)
    street2 = fields.Char(required=True)

    def action_archive(self):
        if not self.env.user.has_group('base.group_system'):
            raise UserError(_("You are not allowed to archive contacts."))
        return super().action_archive()

    def action_unarchive(self):
        if not self.env.user.has_group('base.group_system'):
            raise UserError(_("You are not allowed to unarchive contacts."))
        return super().action_unarchive()


class ResCompany(models.Model):
    _inherit = 'res.company'

    street = fields.Char(required=True)
    street2 = fields.Char(required=True)


