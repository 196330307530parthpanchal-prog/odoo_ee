from odoo import models, fields, api

class RescheduleWizard(models.TransientModel):
    _name = 'reschedule.wizard'
    _description = 'Order Reschedule Wizard'

    reason = fields.Selection([
        ('customer_not_available', 'Customer Not Available'),
        ('customer_rejected', 'Customer Rejected'),
        ('logistics_issue', 'Logistics Issue'),
        ('weather_conditions', 'Weather Conditions'),
        ('other', 'Other'),
    ], string="Reason", required=True)

    note = fields.Text(string="Note")
    reschedule_date = fields.Datetime(string="Reschedule Date", required=True)



    def action_reschedule(self):
        order_id = self.env.context.get('active_id')
        order = self.env['stock.picking'].browse(order_id)

        if order.exists():

            order.write({
                'scheduled_date': self.reschedule_date,'state': 'under_reschedule'
            })

            dispatch_detail = self.env['dispatch.order.details'].search([('order_number', '=', order.id)], limit=1)
            if dispatch_detail:
                dispatch_detail.write({'order_rescheduled': True})

            order.message_post(
                body=f"Order Rescheduled: {self.reschedule_date} <br> Reason: {self.reason} <br> Note: {self.note}")

        return {'type': 'ir.actions.act_window_close'}
