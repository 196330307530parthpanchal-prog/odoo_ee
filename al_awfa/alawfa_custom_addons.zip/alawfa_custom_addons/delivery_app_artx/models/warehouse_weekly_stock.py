from odoo import models, fields, api, _
from datetime import datetime, timedelta

class WarehouseWeeklyStock(models.Model):
    _name = 'warehouse.weekly.stock'
    _description = 'Weekly Warehouse Stock Usage'
    _rec_name = 'name'

    week_start = fields.Date(string="Week Start", required=True)
    week_end = fields.Date(string="Week End", required=True)
    max_pallets = fields.Integer(string="Max Pallets", compute="_compute_max_pallets", store=True)
    bill_id = fields.Many2one('warehouse.stock.bill', string="Related Bill")
    name = fields.Char(string="Reference")
    def name_get(self):
        result = []
        for rec in self:
            name = ''
            if rec.weekly_start and rec.weekly_end:
                name = f"{rec.weekly_start.strftime('%Y-%m-%d')} to {rec.weekly_end.strftime('%Y-%m-%d')}"
            elif rec.weekly_start:
                name = f"{rec.weekly_start.strftime('%Y-%m-%d')}"
            else:
                name = "Unnamed Week"
            result.append((rec.id, name))
        return result

    @api.depends('week_start', 'week_end')
    def _compute_max_pallets(self):
        for record in self:
            if record.week_start and record.week_end:
                daily_pallets = self.env['warehouse.daily.stock'].search([
                    ('date', '>=', record.week_start),
                    ('date', '<=', record.week_end)
                ])
                record.max_pallets = max(daily_pallets.mapped('total_pallets'), default=0)

    @api.constrains('week_start', 'week_end')
    def _check_week_dates(self):
        for record in self:
            if record.week_end < record.week_start:
                raise models.ValidationError("Week End date cannot be before Week Start date.")



    def action_print_bill(self):
        return {
            'name': 'Select Date Range',
            'type': 'ir.actions.act_window',
            'res_model': 'wizard.select.weekly.stock.range',
            'view_mode': 'form',
            'target': 'new',
        }

class WeeklyStockRangeWizard(models.TransientModel):
    _name = 'wizard.select.weekly.stock.range'
    _description = 'Select Date Range for Billing'

    start_date = fields.Date(required=True)
    end_date = fields.Date(required=True)

    def action_next(self):
        domain = [
            ('week_start', '>=', self.start_date),
            ('week_end', '<=', self.end_date),
        ]
        weekly_stocks = self.env['warehouse.weekly.stock'].search(domain)

        wizard_lines = [(0, 0, {
            'weekly_stock_id': rec.id,
            'max_pallets': rec.max_pallets,
        }) for rec in weekly_stocks]

        return {
            'name': 'Enter Prices',
            'type': 'ir.actions.act_window',
            'res_model': 'wizard.add.weekly.stock.prices',
            'view_mode': 'form',
            'target': 'new',
            'context': {'default_line_ids': wizard_lines},
        }


# wizards/weekly_stock_price_wizard.py
class WeeklyStockPriceWizard(models.TransientModel):
    _name = 'wizard.add.weekly.stock.prices'
    _description = 'Add Prices to Weekly Records'

    line_ids = fields.One2many('wizard.weekly.stock.price.line', 'wizard_id')

    def action_print_invoice(self):
        bill = self.env['warehouse.stock.bill'].create({
            'line_ids': [
                (0, 0, {
                    'weekly_stock_id': line.weekly_stock_id.id,
                    'max_pallets': line.max_pallets,
                    'price': line.price,
                    'total': line.total,
                }) for line in self.line_ids
            ]
        })

        for line in bill.line_ids:
            line.weekly_stock_id.bill_id = bill

        return self.env.ref('delivery_app_artx.action_weekly_stock_invoice_report').report_action(bill)


class WeeklyStockPriceLine(models.TransientModel):
    _name = 'wizard.weekly.stock.price.line'
    _description = 'Line for Weekly Stock Pricing'

    wizard_id = fields.Many2one('wizard.add.weekly.stock.prices')
    weekly_stock_id = fields.Many2one('warehouse.weekly.stock', required=True)
    max_pallets = fields.Integer()
    price = fields.Float(required=True)

    total = fields.Float(compute="_compute_total", store=True)

    @api.depends('max_pallets', 'price')
    def _compute_total(self):
        for line in self:
            line.total = line.max_pallets * line.price


# models/warehouse_stock_bill.py
class WarehouseStockBill(models.Model):
    _name = 'warehouse.stock.bill'
    _description = 'Weekly Stock Invoice Bill'

    name = fields.Char(string="Bill Reference", default=lambda self: _('New'))
    bill_date = fields.Date(default=fields.Date.today)
    line_ids = fields.One2many('warehouse.stock.bill.line', 'bill_id')
    total_amount = fields.Float(compute="_compute_total", store=True)

    @api.depends('line_ids.total')
    def _compute_total(self):
        for rec in self:
            rec.total_amount = sum(line.total for line in rec.line_ids)

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('warehouse.stock.bill') or _('New')
        return super().create(vals)


class WarehouseStockBillLine(models.Model):
    _name = 'warehouse.stock.bill.line'
    _description = 'Weekly Stock Bill Line'

    bill_id = fields.Many2one('warehouse.stock.bill')
    weekly_stock_id = fields.Many2one('warehouse.weekly.stock')
    max_pallets = fields.Integer()
    price = fields.Float()
    total = fields.Float()
