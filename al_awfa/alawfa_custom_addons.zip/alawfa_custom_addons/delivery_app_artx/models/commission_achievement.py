from odoo import models, fields, api,_
from dateutil.relativedelta import relativedelta
from datetime import timedelta

class AccountMove(models.Model):
    _inherit = 'account.move'

    def action_post(self):
        res = super().action_post()

        return res

    # @api.model_create_multi
    # def create(self, vals_list):
    #     moves = super().create(vals_list)
    #
    #     # Check group
    #     if self.env.user.has_group('delivery_app_artx.group_driver'):
    #         # Filter only invoices (not journal entries)
    #         invoices = moves.filtered(lambda m: m.move_type in (
    #             'out_invoice', 'in_invoice', 'out_refund', 'in_refund'
    #         ) and m.state == 'draft')
    #
    #         # Auto confirm (post)
    #         print("confirming invoices")
    #         invoices.action_post()
    #
    #     return moves

    is_driver_invoice = fields.Boolean(
        string="Created by Driver",
        compute="_compute_is_driver_invoice",
        store=True
    )

    @api.depends('create_uid')
    def _compute_is_driver_invoice(self):
        driver_group = self.env.ref(
            'delivery_app_artx.group_driver',
            raise_if_not_found=False
        )

        for rec in self:
            rec.is_driver_invoice = bool(
                driver_group
                and rec.create_uid
                and rec.create_uid in driver_group.users
            )


class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    def _reconcile_plan(self, plan):
        print("reconcile_plan running")
        result = super()._reconcile_plan(plan)

        # Gather payments involved in reconciliation
        all_amls = self.browse([aml.id for group in plan for aml in group])
        payments = all_amls.mapped('payment_id').filtered(
            lambda p: p and p.payment_type == 'inbound' and p.partner_type == 'customer'
        )

        for payment in payments:
            payment._process_invoice_achievement()
            payment._check_old_invoice_payments()
            print("_process_invoice_achievement called")

        # journals = all_amls.mapped('journal_id')
        # journals.recalculate_balances()

        return result



class AccountPayment(models.Model):
    _inherit = 'account.payment'

    is_driver_payment = fields.Boolean(
        string="Created by Driver",
        compute="_compute_is_driver_payment",
        store=True
    )

    @api.depends('create_uid')
    def _compute_is_driver_payment(self):
        driver_group = self.env.ref(
            'delivery_app_artx.group_driver',
            raise_if_not_found=False
        )
    
        for rec in self:
            rec.is_driver_payment = bool(
                driver_group
                and rec.create_uid
                and rec.create_uid in driver_group.users
            )

    def _check_old_invoice_payments(self):
        today = fields.Date.context_today(self)
        one_month_ago = today - timedelta(days=30)
        print("inside 1 month act check", self)
        for payment in self:
            print("val1")
            if payment.payment_type != 'inbound' or payment.partner_type != 'customer':
                continue
            if payment.reconciled_invoice_ids:
                print("val2", payment.reconciled_invoice_ids)
                for invoice in payment.reconciled_invoice_ids:
                    print("val3")
                    print(invoice.move_type)
                    print(invoice.user_id)
                    user = invoice.invoice_user_id
                    if not user:
                        continue
                    if invoice.move_type in ('out_invoice',):
                        invoice_date = invoice.invoice_date
                        print('val4 ', invoice_date)
                        print(one_month_ago)
                        if invoice_date < one_month_ago:
                            # Create a To-Do task for the salesman
                            print("Activity created")
                            self.env['mail.activity'].create({
                                'res_model_id': self.env['ir.model']._get('account.move').id,
                                'res_id': invoice.id,
                                'activity_type_id': self.env.ref('mail.mail_activity_data_todo').id,
                                'user_id': invoice.user_id.id,
                                'summary': _('Please review this payment for an invoice older than one month.'),
                                'note': _('Invoice %s dated %s requires attention due to payment.') % (invoice.name, invoice_date),
                            })
        return True

    def _process_invoice_achievement(self):
        print("_process_invoice_achievement inside")
        for payment in self:
            if payment.payment_type != 'inbound' or payment.partner_type != 'customer':
                continue

            for invoice in payment.reconciled_invoice_ids:
                print("_process_invoice_achievement step 1")
                user = invoice.invoice_user_id
                if not user:
                    continue

                commission_rule = self.env['user.commission'].search([
                    ('user_id', '=', user.id),
                    ('active', '=', True)
                ], limit=1)

                if not commission_rule:
                    continue

                duration = commission_rule.duration
                start, end = self.env['user.commission.achievement']._get_period_dates(duration)

                achievement = self.env['user.commission.achievement'].search([
                    ('user_id', '=', user.id),
                    ('commission_rule_id', '=', commission_rule.id),
                    ('period_start', '=', start),
                    ('period_end', '=', end)
                ], limit=1)

                print("_process_invoice_achievement record searched")
                if not achievement:
                    achievement = self.env['user.commission.achievement'].create({
                        'user_id': user.id,
                        'commission_rule_id': commission_rule.id,
                        'currency_id': invoice.currency_id.id,
                        'period_start': start,
                        'period_end': end,
                        'actual_amount': 0.0,
                        'actual_units': 0.0,
                    })
                    print("_process_invoice_achievement record created")
                # achievement.compute_commission_for_user()

                # if commission_rule.commission_base == 'invoice_untaxed':
                #     achievement.actual_amount += invoice.amount_untaxed
                # else:  # 'payment_received'
                #     achievement.actual_amount += payment.amount
                #
                # for line in invoice.invoice_line_ids:
                #     # Get sale order lines linked to this invoice line
                #     sale_lines = line.sale_line_ids
                #     if not sale_lines:
                #         qty = line.quantity  # fallback if no sale lines (e.g. manually created invoice)
                #     else:
                #         # Find stock moves from sale lines
                #         stock_moves = self.env['stock.move'].search([
                #             ('sale_line_id', 'in', sale_lines.ids)
                #         ])
                #         # Count lots from stock move lines
                #         lot_count = self.env['stock.move.line'].search_count([
                #             ('move_id', 'in', stock_moves.ids),
                #             ('lot_id', '!=', False)
                #         ])
                #         qty = lot_count if line.product_id.tracking == 'lot' else sum(
                #             stock_moves.mapped('product_uom_qty'))
                #
                #     achievement.actual_amount += qty

    # def _process_invoice_achievement(self):
    #     print("_process_invoice_achievement inside")
    #     for payment in self:
    #         if payment.payment_type != 'inbound' or payment.partner_type != 'customer':
    #             continue
    #
    #         for invoice in payment.reconciled_invoice_ids:
    #             print("_process_invoice_achievement step 1")
    #             user = self.env.user
    #             if not user:
    #                 continue
    #
    #             commission_rule = self.env['user.commission'].search([
    #                 ('user_id', '=', user.id),
    #                 ('active', '=', True)
    #             ], limit=1)
    #
    #             if not commission_rule:
    #                 continue
    #
    #             duration = commission_rule.duration
    #             start, end = self.env['user.commission.achievement']._get_period_dates(duration)
    #
    #             achievement = self.env['user.commission.achievement'].search([
    #                 ('user_id', '=', user.id),
    #                 ('commission_rule_id', '=', commission_rule.id),
    #                 ('period_start', '=', start),
    #                 ('period_end', '=', end)
    #             ], limit=1)
    #
    #             print("_process_invoice_achievement record searched")
    #             if not achievement:
    #                 achievement = self.env['user.commission.achievement'].create({
    #                     'user_id': user.id,
    #                     'commission_rule_id': commission_rule.id,
    #                     'currency_id': invoice.currency_id.id,
    #                     'period_start': start,
    #                     'period_end': end,
    #                     'actual_amount': 0.0,
    #                     'actual_units': 0.0,
    #                 })
    #                 print("_process_invoice_achievement record created")
    #
    #             # Update achievement values
    #
    #             achievement.actual_amount += payment.amount
    #
    #             for line in invoice.invoice_line_ids:
    #                 qty = line.quantity
    #                 if line.product_id.tracking == 'lot':
    #                     qty = len(line.lot_ids)
    #                 achievement.actual_units += qty


class UserCommissionAchievement(models.Model):
    _name = 'user.commission.achievement'
    _description = 'User Commission Achievement'
    _rec_name = 'user_id'

    user_id = fields.Many2one('res.users', string='User', required=True)
    commission_rule_id = fields.Many2one('user.commission', string='Commission Rule', required=True)
    duration = fields.Selection(related='commission_rule_id.duration', store=True)

    period_start = fields.Date(string='Period Start', required=True)
    period_end = fields.Date(string='Period End', required=True)

    actual_amount = fields.Monetary(string='Actual Sales Amount', currency_field='currency_id')
    payment_amount = fields.Monetary(string='Payment Amount', currency_field='currency_id')
    # invoiced_amount = fields.Monetary(
    #     string="Invoiced Amount",
    #     currency_field='currency_id'
    # )
    #
    # received_amount = fields.Monetary(
    #     string="Payment Received",
    #     currency_field='currency_id'
    # )
    # actual_amount = fields.Monetary(
    #     string='Effective Amount',
    #     currency_field='currency_id',
    #     compute='_compute_actual_amount',
    #     store=True
    # )
    #
    # @api.depends('invoiced_amount', 'received_amount', 'commission_rule_id.commission_base')
    # def _compute_actual_amount(self):
    #     for rec in self:
    #         if rec.commission_rule_id.commission_base == 'invoice_untaxed':
    #             rec.actual_amount = rec.invoiced_amount
    #         else:
    #             rec.actual_amount = rec.received_amount

    actual_units = fields.Float(string='Units Sold')
    target_units = fields.Float(string='Target (Units)', related='commission_rule_id.target_units')

    target_amount = fields.Monetary(string='Target (Amount)', currency_field='currency_id',
                                    related='commission_rule_id.target_amount')
    currency_id = fields.Many2one(related="commission_rule_id.currency_id", string='Currency', required=True)
    commissioned_on = fields.Selection(related='commission_rule_id.commissioned_on', store=True)
    eligible = fields.Boolean(string='Eligible for Commission', compute='_compute_eligibility', store=True)
    commission_earned = fields.Monetary(string='Commission Earned', currency_field='currency_id', compute='_compute_commission', store=True)

    commission_log = fields.Text(string='Commission Log', tracking=True)

    @api.depends('actual_amount', 'actual_units', 'target_amount', 'target_units')
    def _compute_eligibility(self):
        for rec in self:
            if rec.commission_rule_id.commissioned_on == 'percentage':
                rec.eligible = rec.actual_amount >= rec.target_amount
            else:
                rec.eligible = rec.actual_units >= rec.target_units

    @api.depends('eligible', 'actual_amount', 'actual_units')
    def _compute_commission(self):
        for rec in self:
            if not rec.eligible:
                rec.commission_earned = 0.0
                continue

            rule = rec.commission_rule_id
            if rule.commissioned_on == 'percentage':
                rec.commission_earned = rec.actual_amount * (rule.commission_rate / 100)
            else:
                rec.commission_earned = rec.actual_units * rule.commission_per_unit

    @api.model
    def _get_period_dates(self, duration):
        """Returns the start and end date for current period based on duration"""
        if self.period_start and self.period_end:
            print('already set')
            return self.period_start, self.period_end

        today = fields.Date.today()
        if duration == 'monthly':
            start = today.replace(day=1)
            end = (start + relativedelta(months=1)) - relativedelta(days=1)
        elif duration == 'quarterly':
            start = today.replace(month=((today.month - 1) // 3) * 3 + 1, day=1)
            end = (start + relativedelta(months=3)) - relativedelta(days=1)
        elif duration == 'yearly':
            start = today.replace(month=1, day=1)
            end = today.replace(month=12, day=31)
        else:
            start = today
            end = today
        return start, end

    # @api.model
    # def compute_commission_achievements(self):
    #     """Compute commission achievements for all active rules"""
    #     Commission = self.env['user.commission']
    #     SaleOrder = self.env['sale.order']
    #     Achievement = self.env['user.commission.achievement']
    #     StockMoveLine = self.env['stock.move.line']
    #
    #     rules = Commission.search([('active', '=', True)])
    #     for rule in rules:
    #         start_date, end_date = self._get_period_dates(rule.duration)
    #
    #         # Filter confirmed orders for the rule's user in the given date range
    #         sale_orders = SaleOrder.search([
    #             ('user_id', '=', rule.user_id.id),
    #             ('date_order', '>=', start_date),
    #             ('date_order', '<=', end_date),
    #             ('state', 'in', ['sale', 'done']),
    #         ])
    #
    #         total_sales = 0.0
    #         total_units = 0.0
    #
    #         for order in sale_orders:
    #             total_sales += order.amount_total
    #             for line in order.order_line:
    #                 product = line.product_id
    #                 if product.tracking == 'lot':
    #                     lots = StockMoveLine.search_count([
    #                         ('lot_id', '!=', False),
    #                         ('move_id.sale_line_id', '=', line.id),
    #                         ('state', '=', 'done')
    #                     ])
    #                     total_units += lots
    #                 else:
    #                     total_units += line.product_uom_qty
    #
    #         vals = {
    #             'user_id': rule.user_id.id,
    #             'commission_rule_id': rule.id,
    #             'period_start': start_date,
    #             'period_end': end_date,
    #             'actual_amount': total_sales,
    #             'actual_units': total_units,
    #             'target_amount': rule.target_amount,
    #             'target_units': rule.target_units,
    #             'currency_id': rule.currency_id.id,
    #         }
    #
    #         # Check if record already exists
    #         existing = Achievement.search([
    #             ('user_id', '=', rule.user_id.id),
    #             ('period_start', '=', start_date),
    #             ('period_end', '=', end_date),
    #             ('commission_rule_id', '=', rule.id)
    #         ], limit=1)
    #
    #         if existing:
    #             existing.write(vals)
    #         else:
    #             Achievement.create(vals)

    def compute_commission_for_user(self):
        """Compute commission achievements for a specific user based on invoices they own"""
        Commission = self.env['user.commission']
        Invoice = self.env['account.move']
        Achievement = self.env['user.commission.achievement']

        rules = Commission.search([('active', '=', True), ('user_id', '=', self.user_id.id)])
        for rule in rules:
            self.commission_log=""
            start_date, end_date = self._get_period_dates(rule.duration)

            # Get all posted invoices created by the user during the period
            invoices = Invoice.search([
                ('move_type', '=', 'out_invoice'),
                ('invoice_user_id', '=', self.user_id.id),
                ('invoice_date', '>=', start_date),
                ('invoice_date', '<=', end_date),
                ('state', '=', 'posted'),
            ])
            print(invoices)

            # use_delivery_units = self.user_id.has_group('delivery_app_artx.group_driver')
            # if use_delivery_units:
            #     invoices = Invoice.search([
            #         ('move_type', '=', 'out_invoice'),
            #         ('create_uid', '=', self.user_id.id),
            #         ('invoice_date', '>=', start_date),
            #         ('invoice_date', '<=', end_date),
            #         ('state', '=', 'posted'),
            #     ])
            #     print("driver invoices",invoices)
            total_sales = 0.0
            total_payment = 0.0
            total_units = 0.0
            Payment = self.env['account.payment']
            payments = Payment.search([
                ('payment_type', '=', 'inbound'),
                ('partner_type', '=', 'customer'),
                ('create_uid', '=', self.user_id.id),
                ('date', '>=', start_date),
                ('date', '<=', end_date),
                ('state', '=', 'posted'),
            ])
            print("Payment : ", payments)

            for payment in payments:
                total_payment+=payment.amount
                self.commission_log += f"\npayment name : {payment.name}\n"
                self.commission_log += f"payment amount : {payment.amount}\n"

            self.commission_log += f"----total_payment : {total_payment}\n"


            for invoice in invoices:
                # Handle base for sales calculation
                print("invoice id: ", invoice)
                # if rule.commission_base == 'invoice_untaxed':
                print("invoice.amount_untaxed:", invoice.amount_untaxed)
                log_message = (f"\ninvoice id: {invoice.name}\n"
                               f"invoice amount(untaxed): {invoice.amount_untaxed}\n")

                self.commission_log += log_message
                total_sales += invoice.amount_untaxed
                # elif rule.commission_base == 'payment_received':
                #     # Sum all payments actually reconciled to this invoice
                #     payments = self.env['account.payment']
                #     matched_lines = invoice.line_ids.mapped('matched_debit_ids.debit_move_id.payment_id') + \
                #                     invoice.line_ids.mapped('matched_credit_ids.credit_move_id.payment_id')
                #     payments |= matched_lines.filtered(
                #         lambda p: p.payment_type == 'inbound' and p.partner_type == 'customer')
                #     payment_amount = sum(p.amount for p in payments)
                #     total_sales += payment_amount
            self.commission_log += f"----total_sales: {total_sales}\n"

            for invoice in invoices:
                # Unit commission calculation (box-aware)
                total_lots=0
                for line in invoice.invoice_line_ids:
                    sale_lines = line.sale_line_ids

                    if not sale_lines:
                        qty = line.quantity
                    else:
                        stock_moves = self.env['stock.move'].search([
                            ('sale_line_id', 'in', sale_lines.ids),
                            ('state', '=', 'done')
                        ])
                        for move in stock_moves:
                            print(move.name, move.delivered_box,)
                            self.commission_log += f"\n{move.picking_id.name}:{move.name}, qty: {move.quantity}, boxes: {move.delivered_box}, "
                            if line.product_id.box_boolean:
                                # Use alternate UoM (boxes)
                                # qty = sum(stock_moves.mapped('delivered_box'))
                                if move.picking_type_id.code == "outgoing":
                                    total_lots+=move.delivered_box
                                    self.commission_log += f"added {move.delivered_box}\n"
                                elif move.picking_type_id.code == "incoming":
                                    total_lots-=move.delivered_box
                                    self.commission_log += f"reduced {move.delivered_box}\n"
                            else:
                                # Use normal quantity
                                # qty = sum(stock_moves.mapped('quantity'))
                                if move.picking_type_id.code == "outgoing":
                                    total_lots+=move.quantity
                                    self.commission_log += f"added {move.quantity}\n"
                                elif move.picking_type_id.code == "incoming":
                                    total_lots-=move.quantity
                                    self.commission_log += f"reduced {move.quantity}\n"

                    total_units += total_lots

                # Get all relevant stock moves directly (DONE deliveries only)
                # use_delivery_units = self.user_id.has_group('delivery_app_artx.group_driver')
                # if use_delivery_units:
                #     stock_moves = self.env['stock.move'].search([
                #         ('state', '=', 'done'),
                #         ('picking_id.picking_type_code', '=', 'outgoing'),  # deliveries only
                #         ('driver_details.user_id', '=', self.user_id.id),
                #         ('date', '>=', start_date),
                #         ('date', '<=', end_date),
                #     ])
                #
                #     total_units = 0
                #     print("driver calc starts")
                #     for move in stock_moves:
                #         print(move.name, move.delivered_box, )
                #     for move in stock_moves:
                #         if move.product_id.box_boolean:
                #             total_units += move.delivered_box or 0
                #         else:
                #             total_units += move.product_uom_qty or 0

            vals = {
                'user_id': self.user_id.id,
                'commission_rule_id': rule.id,
                'period_start': start_date,
                'period_end': end_date,
                'actual_amount': total_sales,
                'payment_amount': total_payment,
                'actual_units': total_units,
                'target_amount': rule.target_amount,
                'target_units': rule.target_units,
                'currency_id': rule.currency_id.id,
            }

            existing = Achievement.search([
                ('user_id', '=', self.user_id.id),
                ('period_start', '=', start_date),
                ('period_end', '=', end_date),
                ('commission_rule_id', '=', rule.id)
            ], limit=1)

            if existing:
                existing.write(vals)
            else:
                Achievement.create(vals)


