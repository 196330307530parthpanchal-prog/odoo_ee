from odoo import models,fields
import ast


class MailComposeMessage(models.TransientModel):
    _inherit = 'mail.compose.message'

    partner_ids = fields.Many2many(
        'res.partner', 'mail_compose_message_res_partner_rel',
        'wizard_id', 'partner_id', 'Additional Contacts',
        compute='_compute_partner_ids', readonly=False, store=True, required=True)

    def action_send_mail(self):
        res = super().action_send_mail()
        print("PART 1 COMPLETE", self.res_ids)

        # If sending email from dispatch.details, update its flag
        if self.model == 'dispatch.details':
            try:
                # Safely parse res_ids string to a list
                dispatch_ids = ast.literal_eval(self.res_ids) if isinstance(self.res_ids, str) else self.res_ids
                print("Parsed dispatch_ids:", dispatch_ids)

                # Ensure it’s a list of integers
                if isinstance(dispatch_ids, list):
                    dispatches = self.env['dispatch.details'].browse(dispatch_ids)
                else:
                    dispatches = self.env['dispatch.details'].browse([dispatch_ids])

                print("PART2 COMPLETE", dispatches)
                dispatches.write({'email_sent': True})
            except Exception as e:
                print("Error parsing dispatch ID:", e)

        return res

    def action_send_mail1(self):
        res = super().action_send_mail()
        print("PART 1 COMPLETE", self.res_ids)
        dispatch_id = self.res_ids
        # If sending email from dispatch.details, update its flag
        if self.model == 'dispatch.details':
            dispatches = self.env['dispatch.details'].browse(dispatch_id)
            print("PART2 COMPLETE", dispatches)
            dispatches.write({'email_sent': True})

        return res
