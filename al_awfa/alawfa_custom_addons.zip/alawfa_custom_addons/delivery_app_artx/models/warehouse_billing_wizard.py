from odoo import models, fields, api

class WarehouseWeeklyBillWizard(models.TransientModel):
    _name = 'warehouse.weekly.bill.wizard'
    _description = 'Warehouse Weekly Bill Wizard'

    start_date = fields.Date(string="Start Date", required=True)
    end_date = fields.Date(string="End Date", required=True)
    line_ids = fields.One2many('warehouse.weekly.bill.wizard.line', 'wizard_id', string="Bill Lines")

    def action_generate_lines(self):
        records = self.env['warehouse.weekly.stock'].search([
            ('week_start', '>=', self.start_date),
            ('week_end', '<=', self.end_date),
        ])
        lines = []
        for rec in records:
            lines.append((0, 0, {
                'stock_id': rec.id,
                'price': 0.0,
            }))
        self.line_ids = lines

    def action_print_bill(self):
        data = []
        total = 0
        for line in self.line_ids:
            subtotal = line.stock_id.max_pallets * line.price
            total += subtotal
            data.append({
                'name': line.stock_id.name,
                'pallets': line.stock_id.max_pallets,
                'price': line.price,
                'subtotal': subtotal
            })

        return self.env.ref('delivery_app_artx.action_warehouse_weekly_bill_report').report_action(self, data={
            'lines': data,
            'total': total,
            'start_date': self.start_date,
            'end_date': self.end_date
        })


class WarehouseWeeklyBillWizardLine(models.TransientModel):
    _name = 'warehouse.weekly.bill.wizard.line'
    _description = 'Warehouse Weekly Bill Wizard Line'

    wizard_id = fields.Many2one('warehouse.weekly.bill.wizard', required=True, ondelete='cascade')
    stock_id = fields.Many2one('warehouse.weekly.stock', string="Stock", readonly=True)
    price = fields.Float(string="Unit Price", required=True)
