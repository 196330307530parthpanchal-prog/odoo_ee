# from odoo import models, fields ,api,_
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError


class UserCommission(models.Model):
    _name = 'user.commission'
    _description = 'User Commission Rule'

    user_id = fields.Many2one('res.users', string='User', required=True)
    commissioned_on = fields.Selection([
        ('units', 'Units Sold'),
        ('percentage', 'Percentage of Order Value'),
    ], string='Commissioned On', required=True)

    target_units = fields.Float(string='Target (Units)')
    target_amount = fields.Monetary(string='Target (Amount)', currency_field='currency_id')
    currency_id = fields.Many2one('res.currency', string='Currency', required=True,
                                  default=lambda self: self.env.company.currency_id)

    commission_rate = fields.Float(string='Commission Rate (%)', digits='Product Price')
    commission_per_unit = fields.Float(string='Commission per Unit', digits='Product Price')

    active = fields.Boolean(default=True)

    duration = fields.Selection([
        ('monthly', 'Monthly'),
        ('yearly', 'Yearly'),
        ('quarterly', 'Quarterly'),
    ], string='Duration', default='monthly', required=True)

    commission_base = fields.Selection([
        ('invoice_untaxed', 'Invoice Untaxed Amount'),
        ('payment_received', 'Payment Received Amount'),
    ], string="Commission Based On", required=True, default='invoice_untaxed')


class UserCommissionLine(models.Model):
    _name = 'user.commission.line'
    _description = 'Commission Entry'

    user_id = fields.Many2one('res.users', string='Salesperson', required=True)
    commission_id = fields.Many2one('user.commission', string='Commission Rule', required=True)

    invoice_id = fields.Many2one('account.move', string='Invoice', required=True, domain=[('move_type', '=', 'out_invoice')])
    payment_id = fields.Many2one('account.payment', string='Payment', required=True)

    commission_type = fields.Selection(related='commission_id.commissioned_on', store=True)
    commission_rate = fields.Float(related='commission_id.commission_rate', store=True)
    commission_per_unit = fields.Float(related='commission_id.commission_per_unit', store=True)
    duration = fields.Selection(related='commission_id.duration', store=True)
    monthly_target = fields.Monetary(related='commission_id.target_amount', store=True)
    currency_id = fields.Many2one('res.currency', related='invoice_id.currency_id', readonly=True)

    amount_paid = fields.Monetary(string='Paid Amount', required=True)
    units_sold = fields.Float(string='Units Sold')
    commission_earned = fields.Monetary(string='Commission Earned', compute='_compute_commission', store=True)

    date = fields.Date(string='Commission Date', default=fields.Date.context_today)

    @api.depends('commission_type', 'amount_paid', 'units_sold', 'commission_rate', 'commission_per_unit')
    def _compute_commission(self):
        for rec in self:
            if rec.commission_type == 'percentage':
                rec.commission_earned = rec.amount_paid * rec.commission_rate / 100
            elif rec.commission_type == 'units':
                rec.commission_earned = rec.units_sold * rec.commission_per_unit
            else:
                rec.commission_earned = 0.0
