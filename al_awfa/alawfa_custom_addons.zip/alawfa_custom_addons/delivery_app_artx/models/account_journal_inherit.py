from odoo import models,fields,api
from datetime import date
import logging
_logger = logging.getLogger(__name__)

class AccountMoveLine(models.Model):
    _inherit = 'account.move.line'

    # @api.model_create_multi
    # def create(self, vals_list):
    #     records = super().create(vals_list)
    #     records._update_journal_balances()
    #     return records

    # def write(self, vals):
    #     res = super().write(vals)
    #     self._update_journal_balances()
    #     return res

    # def unlink(self):
    #     journals = self.mapped('journal_id')
    #     res = super().unlink()
    #     journals.recalculate_balances()
    #     return res

    # def _update_journal_balances(self):
    #     journals = self.mapped('journal_id')
    #     journals.recalculate_balances()


class AccountJournal(models.Model):
    _inherit = 'account.journal'

    def open_transfer_funds_wizard(self):
        return {
            'type': 'ir.actions.act_window',
            'name': 'Transfer Funds',
            'res_model': 'driver.transfer.funds.wizard',  # <- updated here
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_source_journal_id': self.id,
            },
        }

    # balance = fields.Monetary(string='Balance') #all actions to be removed for this field
    currency_id = fields.Many2one('res.currency', string='Currency', compute='_compute_currency', store=True)

    # def recalculate_balances(self):
    #     for journal in self:
    #         move_lines = self.env['account.move.line'].search([('journal_id', '=', journal.id)])
    #         for i in move_lines:
    #             print("Values of debit : ",i.debit,"  credit : ",i.credit,"  residual: ",i.amount_residual_currency)
    #         journal.balance = sum(move_lines.mapped('amount_residual_currency'))   #lambda l: l.debit - l.credit

    @api.depends('currency_id')
    def _compute_currency(self):
        for rec in self:
            rec.currency_id = rec.company_id.currency_id

    @api.model
    def action_view_my_cash_journals(self):
        user_journal_ids = self.env.user.cash_journal_ids.ids
        return {
            'name': 'My Cash Journals',
            'type': 'ir.actions.act_window',
            'res_model': 'account.journal',
            'view_mode': 'tree',
            'views': [(self.env.ref('delivery_app_artx.view_driver_cash_journal_tree').id, 'tree')],
            'domain': [('id', 'in', user_journal_ids)],
            'context': {},
            'target': 'current',
        }

    def action_view_today_moves(self):
        self.ensure_one()
        return {
            'name': "Today's Transactions",
            'type': 'ir.actions.act_window',
            'res_model': 'account.move',
            'view_mode': 'tree',
            # 'views': [(self.env.ref('delivery_app_artx.view_driver_transactions_tree').id, 'tree')],
            'views': [(self.env.ref('account.view_move_tree').id, 'tree')],
            'domain': [
                ('journal_id', '=', self.id),
                # ('date', '=', date.today().strftime('%Y-%m-%d')),
                ('create_uid', '=', self.env.user.id),
            ],
            'context': dict(self.env.context),
        }

    def action_view_today_payments(self):
        self.ensure_one()
        return {
            'name': "Today's Payments",
            'type': 'ir.actions.act_window',
            'res_model': 'account.payment',
            'view_mode': 'tree',
            'views': [(self.env.ref('account.view_account_payment_tree').id, 'tree')],
            # 'views': [(self.env.ref('delivery_app_artx.view_driver_payments_tree').id, 'tree')],
            'search_view_id': self.env.ref('delivery_app_artx.view_account_payment_search_driver').id,
            'domain': [
                ('journal_id', '=', self.id),
                ('date', '=', date.today().strftime('%Y-%m-%d')),
                # ('create_uid', '=', self.env.user.id),
            ],
            'context': dict(self.env.context),
        }

    # def action_open_driver_payment_action(self):
    #     self.ensure_one()
    #     return {
    #         'name': "Today's Payments",
    #         'type': 'ir.actions.act_window',
    #         'res_model': 'account.payment',
    #         'view_mode': 'tree',
    #         'views': [(self.env.ref('account.view_account_payment_tree').id, 'tree')],
    #         # 'views': [(self.env.ref('delivery_app_artx.view_driver_payments_tree').id, 'tree')],
    #         'search_view_id': self.env.ref('delivery_app_artx.view_account_payment_search_driver').id,
    #         'domain': [
    #             ('journal_id', '=', self.id),
    #             # ('payment_date', '=', date.today().strftime('%Y-%m-%d')),
    #             # ('create_uid', '=', self.env.user.id),
    #         ],
    #         'context': {
    #             'search_default_filter_today': 1
    #         },
    #     }