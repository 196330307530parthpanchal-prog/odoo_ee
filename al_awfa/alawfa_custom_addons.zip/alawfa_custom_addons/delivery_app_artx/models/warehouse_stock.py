from odoo import models, fields, api
from datetime import datetime


class StockMove(models.Model):
    _inherit = "stock.move"

    demand_box = fields.Integer(string="Demand Box")
    delivered_box = fields.Integer(string="Delivered Box")

    box_boolean = fields.Boolean(
        related="product_id.product_tmpl_id.box_boolean",
        store=False
    )

    def action_done(self):
        res = super(StockMove, self).action_done()

        for move in self.filtered(lambda m: m.state == 'done' and m.product_id.type == 'product'):
            self.env['warehouse.stock'].create_from_stock_move(move)

        return res


class WarehouseStock(models.Model):
    _name = "warehouse.stock"
    _description = "Daily Warehouse Stock Tracking"

    date = fields.Date(string="Date", required=True, default=fields.Date.context_today)
    product_id = fields.Many2one('product.product', string="Product", required=True)
    cartons_per_pallet = fields.Integer(string="Cartons Per Pallet", related="product_id.cartons_per_pallet", store=True)

    opening_stock = fields.Integer(string="Opening Stock", compute="_compute_opening_stock", store=True)
    opening_pallets = fields.Integer(string="Opening Pallets", compute="_compute_opening_pallets", store=True)
    inbound_stock = fields.Integer(string="Inbound Stock", compute="_compute_inbound_stock", store=True, help="Negative means products sold", default=0)

    total_pallets = fields.Integer(string="Total Pallets", compute="_compute_total_pallets", store=True)
    actual_pallet = fields.Float(string="Actual Pallet", compute="_compute_actual_pallet", store=True)

    @api.depends('date', 'product_id')
    def _compute_opening_stock(self):
        for record in self:
            if record.product_id.tracking in ['lot', 'serial']:
                record.opening_stock = self.env['stock.quant'].search_count([
                    ('product_id', '=', record.product_id.id),
                    ('location_id.usage', '=', 'internal'),
                    ('quantity', '>', 0)  # Count only active lots
                ])
            else:
                stock_quant = self.env['stock.quant'].search([
                    ('product_id', '=', record.product_id.id),
                    ('location_id.usage', '=', 'internal')
                ])
                record.opening_stock = sum(stock_quant.mapped('quantity'))

    @api.depends('date', 'product_id')
    def _compute_inbound_stock(self):
        """Calculate inbound stock based on stock move and product tracking type."""
        today_date = datetime.today().date()

        for record in self:
            move = self.env['stock.move'].search([
                ('product_id', '=', record.product_id.id),
                ('state', '=', 'done'),
                ('date', '>=', today_date.strftime('%Y-%m-%d 00:00:00')),
                ('date', '<=', today_date.strftime('%Y-%m-%d 23:59:59'))
            ], order="date desc", limit=1)

            if move:
                if move.product_id.tracking in ['lot', 'serial']:
                    # Count the number of unique lots moved
                    lot_count = self.env['stock.move.line'].search_count([
                        ('move_id', '=', move.id),
                        ('lot_id', '!=', False)
                    ])
                    record.inbound_stock = lot_count
                else:
                    # Use quantity for non-lot-tracked products
                    record.inbound_stock = move.product_uom_qty

                # If move is to a customer, it's an outbound move (negative stock)
                if move.location_dest_id.usage == 'customer':
                    record.inbound_stock = -1 * record.inbound_stock
            else:
                record.inbound_stock = 0


    @api.depends('opening_stock', 'cartons_per_pallet')
    def _compute_opening_pallets(self):
        for record in self:
            cartons_per_pallet = record.cartons_per_pallet or 20
            record.opening_pallets = (record.opening_stock // cartons_per_pallet) + (
                1 if record.opening_stock % cartons_per_pallet else 0
            )

    @api.depends('opening_stock', 'inbound_stock', 'cartons_per_pallet')
    def _compute_total_pallets(self):
        for record in self:
            cartons_per_pallet = record.cartons_per_pallet or 20
            total_stock = record.opening_stock

            record.opening_stock= total_stock - record.inbound_stock

            record.total_pallets = (total_stock // cartons_per_pallet) + (
                1 if total_stock % cartons_per_pallet else 0
            )

    @api.depends('total_pallets')
    def _compute_actual_pallet(self):
        for record in self:
            cartons_per_pallet = record.cartons_per_pallet or 20
            total_stock = record.opening_stock + record.inbound_stock
            record.actual_pallet = total_stock / cartons_per_pallet

    @api.model
    def create_from_stock_move(self, move):
        """Creates a warehouse.stock entry whenever stock moves"""
        date = fields.Date.context_today(self)
        product = move.product_id
        cartons_per_pallet = product.cartons_per_pallet or 20

        self.create({
            'date': date,
            'product_id': product.id,
            'cartons_per_pallet': cartons_per_pallet,
            # 'opening_stock': opening_stock,
            # 'inbound_stock': inbound_stock
        })

    @api.model
    def create_stock_entries_no_movement(self):
        """Ensure all products in stock are included in warehouse.stock."""
        date_today = fields.Date.context_today(self)
        all_products = self.env['product.product'].search([('type', '=', 'product')])

        for product in all_products:
            stock_entry = self.search([
                ('product_id', '=', product.id),
                ('date', '=', date_today)
            ])
            if not stock_entry:
                self.create({'date': date_today, 'product_id': product.id})

        self.env['warehouse.daily.stock'].create_daily_stock_entry()



# from odoo import models, fields, api
# from datetime import datetime, timedelta
# import math
#
# from odoo import models, fields, api
#
#
# class StockMove(models.Model):
#     _inherit = "stock.move"
#
#     def action_done(self):
#         res = super(StockMove, self).action_done()
#
#         for move in self.filtered(lambda m: m.state == 'done' and m.product_id.type == 'product'):
#             self.env['warehouse.stock'].create_from_stock_move(move)
#
#         return res
#
#
# class WarehouseStock(models.Model):
#     _name = "warehouse.stock"
#     _description = "Daily Warehouse Stock Tracking"
#
#     date = fields.Date(string="Date", required=True, default=fields.Date.context_today)
#     product_id = fields.Many2one('product.product', string="Product", required=True)
#     cartons_per_pallet = fields.Integer(string="Cartons Per Pallet", related="product_id.cartons_per_pallet",
#                                         store=True)
#
#     opening_stock = fields.Integer(string="Opening Stock", compute="_compute_opening_stock",store=True)
#     opening_pallets = fields.Integer(string="Opening Pallets", compute="_compute_opening_pallets", store=True)
#
#     inbound_stock = fields.Integer(string="Inbound Stock", default=0, help="Negative means products sold")
#
#     total_pallets = fields.Integer(string="Total Pallets", compute="_compute_total_pallets", store=True)
#     actual_pallet = fields.Float(string="Actual Pallet", compute="_compute_actual_pallet", store=True)
#
#     @api.depends('date', 'product_id')
#     def _compute_opening_stock(self):
#         today = fields.Date.today()
#         for record in self:
#             if record.product_id.tracking == 'lot':
#                 record.opening_stock = self.env['stock.quant'].search_count([
#                     ('product_id', '=', record.product_id.id),
#                     ('quantity', '>', 0)  # Only count active lots
#                 ])
#             else:
#                 stock_quant = self.env['stock.quant'].search([
#                 ('product_id', '=', record.product_id.id),
#                 ('location_id.usage', '=', 'internal')
#                 ])
#                 record.opening_stock = sum(stock_quant.mapped('quantity'))
#
#     @api.depends('opening_stock', 'cartons_per_pallet')
#     def _compute_opening_pallets(self):
#         for record in self:
#             if (record.cartons_per_pallet==0):
#                 record.cartons_per_pallet=20
#             record.opening_pallets = (record.opening_stock // record.cartons_per_pallet) + (
#                 1 if record.opening_stock % record.cartons_per_pallet else 0)
#
#     @api.depends('opening_stock', 'inbound_stock', 'cartons_per_pallet')
#     def _compute_total_pallets(self):
#         for record in self:
#             if (record.cartons_per_pallet==0):
#                 record.cartons_per_pallet=20
#             total_stock = record.opening_stock + record.inbound_stock
#             record.total_pallets = (total_stock // record.cartons_per_pallet) + (
#                 1 if total_stock % record.cartons_per_pallet else 0)
#
#     @api.depends('total_pallets')
#     def _compute_actual_pallet(self):
#         for record in self:
#             if (record.cartons_per_pallet==0):
#                 record.cartons_per_pallet=20
#             total_stock = record.opening_stock + record.inbound_stock
#             record.actual_pallet = (total_stock / record.cartons_per_pallet)
#
#     @api.model
#     def create_from_stock_move(self, move):
#         """Creates a warehouse.stock entry whenever stock moves"""
#         date = fields.Date.context_today(self)
#         product = move.product_id
#         cartons_per_pallet = product.cartons_per_pallet
#
#         # Get opening stock from previous entry (if exists)
#         last_entry = self.search([('product_id', '=', product.id)], order="date desc", limit=1)
#         opening_stock = last_entry.total_pallets * cartons_per_pallet if last_entry else 0
#
#         # Determine if inbound or outbound
#         inbound_stock = move.product_uom_qty if move.location_dest_id.usage == 'internal' else -move.product_uom_qty
#
#         # Create a new stock entry
#         self.create({
#             'date': date,
#             'product_id': product.id,
#             'cartons_per_pallet': cartons_per_pallet,
#             'opening_stock': opening_stock,
#             'inbound_stock': inbound_stock
#         })
