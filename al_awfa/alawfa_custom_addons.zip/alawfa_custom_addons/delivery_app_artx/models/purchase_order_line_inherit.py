from odoo import models, fields, api, _

class PurchaseOrderLine(models.Model):
    _inherit = "purchase.order.line"

    purchase_box = fields.Integer(
        string="CRT",
        store=True
    )

    show_box = fields.Boolean(
        string="Show Box",
        compute="_compute_show_box",
        store=False
    )

    
    @api.depends('product_id')
    def _compute_show_box(self):
        for line in self:
            line.show_box = bool(line.product_id.box_boolean)

    @api.depends('product_qty', 'product_uom', 'company_id')
    def _compute_price_unit_and_date_planned_and_name(self):
        for line in self:
            # store existing price before compute
            existing_price = line.price_unit

            if line.price_unit and line._origin and line._origin.price_unit:
                print('_compute_price_unit skipped')
                continue

            super(PurchaseOrderLine, line)._compute_price_unit_and_date_planned_and_name()
            print('original _compute_price_unit in purchase called')