from odoo import models, fields, api
from odoo.exceptions import UserError

from odoo import models

# class AccountJournal(models.Model):
#     _inherit = 'account.journal'
#
#     def open_transfer_funds_wizard(self):
#         return {
#             'type': 'ir.actions.act_window',
#             'name': 'Transfer Funds',
#             'res_model': 'driver.transfer.funds.wizard',
#             'view_mode': 'form',
#             'target': 'new',
#             'context': {
#                 'default_source_journal_id': self.id,
#             },
#         }


class TransferFundsWizard(models.TransientModel):
    _name = 'driver.transfer.funds.wizard'
    _description = 'Transfer Funds from Driver Cash to Another Journal'

    source_journal_id = fields.Many2one('account.journal', string="Source Journal", required=True, readonly=True)
    destination_journal_id = fields.Many2one('account.journal', string="Destination Journal", required=True)
    amount = fields.Monetary(string="Amount", required=True)
    currency_id = fields.Many2one('res.currency', default=lambda self: self.env.company.currency_id)
    date = fields.Date(string="Date", default=fields.Date.context_today)
    note = fields.Char(string="Note in memo")


    def action_confirm_transfer(self):

        payment_obj = self.env['account.payment'].create({
            # 'name': '',
            'payment_type': 'outbound',
            'amount': self.amount,
            'currency_id': self.currency_id.id,
            'date': self.date,
            'journal_id': self.source_journal_id.id,
            'destination_journal_id': self.destination_journal_id.id,
            'payment_method_id': self.env.ref('account.account_payment_method_manual_out').id,  # or the proper method
            'partner_type': 'customer',
            'is_internal_transfer': True,
            # 'ref': f'Transfer from {self.source_journal_id.name} to {self.destination_journal_id.name}',
            'ref': self.note,
        })


        payment_obj.action_post()


