from odoo import models, fields, api, _
import math
from datetime import date
import logging
from odoo.exceptions import UserError
from odoo.tools.populate import compute
from odoo.tools.float_utils import float_compare
_logger = logging.getLogger(__name__)


from datetime import datetime

class IrRule(models.Model):
    _inherit = 'ir.rule'

    @api.model
    def _compute_domain(self, model_name,mode="read"):
        domain = super()._compute_domain(model_name)
        # today_str = datetime.today()
        # today = fields.Date.context_today(self)
        # today_dt = fields.Datetime.context_timestamp(self, datetime.now())
        # print(today , ' vs ',today_str,' vs ',today_str)



        if model_name == 'stock.picking' and self.env.user.has_group('delivery_app_artx.group_driver'):
            print("record rule mil gaya")
            if domain is None:
                domain = []

            today = fields.Date.context_today(self)
            print('domain check driver',today)

            extra_conditions = [
                ('driver_details.user_id', '=', self.env.user.id),
                ('schedule_date_dd_date', '=', today),
            ]
            for cond in extra_conditions:
                if cond not in domain:
                    domain.append(cond)

            print('Final domain is:', domain)
        # else:
        #     print('Final domain is:', domain," without entering changes")
        return domain

class HoverProductInfoWizard(models.TransientModel):
    _name = 'hover.product.info.wizard'
    _description = 'Product Info Popup'

    info = fields.Text("Details")


class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    skip_backorder_driver = fields.Boolean(
        string="Skip Backorder Confirmation for Drivers",
        config_parameter='stock.skip_backorder_driver'
    )

class StockPicking(models.Model):
    _inherit = "stock.picking"

    demand_box = fields.Integer(string="Demand CRT",readonly=True)
    delivered_box = fields.Integer(string="Delivered CRT")

    box_boolean = fields.Boolean(
        related="product_id.product_tmpl_id.box_boolean",
        store=False
    )




    @api.depends('move_ids_without_package.delivered_box')
    def _compute_delivered_box_total(self):
        for picking in self:
            total = 0
            for move in picking.move_ids_without_package:
                total += move.delivered_box or 0
            picking.delivered_box = total


    state = fields.Selection([
        ('draft', 'Draft'),
        ('waiting', 'Waiting Another Operation'),
        ('confirmed', 'Waiting'),
        ('assigned', 'Ready'),
        ('under_reschedule', 'Under Reschedule'),
        ('driver_assigned', 'Driver Assigned'),
        ('done', 'Done'),
        ('cancel', 'Cancelled'),
    ], string='Status', compute='_compute_state',
        copy=False, index=True, readonly=True, store=True, tracking=True,
        help=" * Draft: The transfer is not confirmed yet. Reservation doesn't apply.\n"
             " * Waiting another operation: This transfer is waiting for another operation before being ready.\n"
             " * Waiting: The transfer is waiting for the availability of some products.\n(a) The shipping policy is \"As soon as possible\": no product could be reserved.\n(b) The shipping policy is \"When all products are ready\": not all the products could be reserved.\n"
             " * Ready: The transfer is ready to be processed.\n(a) The shipping policy is \"As soon as possible\": at least one product has been reserved.\n(b) The shipping policy is \"When all products are ready\": all product have been reserved.\n"
             " * Under Reschedule: The transfer is undergoing a reassignment to a driver for delivery beacuse previous one failed due to some reason .\n"
             " * Assigned: The transfer is assigned to a driver for delivery .\n"
             " * Done: The transfer has been processed.\n"
             " * Cancelled: The transfer has been cancelled.")
    @api.depends('move_type', 'move_ids.state', 'move_ids.picking_id','batch_id','driver_details')
    def _compute_state(self):
        super()._compute_state()

        for picking in self:
            if picking.batch_id and picking.state not in ['done', 'cancel']:
                print("bro i saved the state")
                picking.state = 'driver_assigned'

    @api.depends('state', 'move_ids.product_uom_qty', 'picking_type_code')
    def _compute_show_check_availability(self):
        for picking in self:
            # ✅ include driver_assigned here
            if picking.state not in ('confirmed', 'waiting', 'assigned', 'driver_assigned'):
                picking.show_check_availability = False
                continue

            if all(m.picked for m in picking.move_ids):
                picking.show_check_availability = False
                continue

            picking.show_check_availability = any(
                move.state in ('waiting', 'confirmed', 'partially_available') and
                float_compare(move.product_uom_qty, 0, precision_rounding=move.product_uom.rounding)
                for move in picking.move_ids
            )

    contact_full_address = fields.Char('Full Address',related='partner_id.contact_address_inline',store=True, readonly=True)

    dispatch_order_id= fields.One2many('dispatch.order.details', 'order_number',string="Batch",store=True, readonly=True)
    batch_id=fields.Char(string="Batch Number",
        related='dispatch_order_id.batch_details.batch_no',
        store=True,
        readonly=True)
    schedule_date_dd = fields.Datetime(string="Scheduled date of dispatch",
                           related='dispatch_order_id.batch_details.schedule_date',
                           store=True,
                           readonly=True)
    schedule_date_dd_date = fields.Date(string="Scheduled Date only",
                           related='dispatch_order_id.batch_details.schedule_date_date',
                           store=True,
                           readonly=True)

    driver_details=fields.Many2one(string='Driver',related="dispatch_order_id.batch_details.driver_details",store=True,readonly=True)

    contact_street_address = fields.Char(
        string="Contact Street Address",
        compute='_compute_contact_street_address',
        store=True
    )

    google_location_link = fields.Char(
        string="Maps Location Link",
        related='partner_id.google_location_link',
        store=True,
        readonly=True
    )
    time_of_day = fields.Char(string="Delivery Time", readonly=True, copy=False)

    remarks_for_dispatch = fields.Char(string="Remarks", related='sale_id.remarks_for_dispatch')

    @api.depends('partner_id.street', 'partner_id.street2')
    def _compute_contact_street_address(self):
        for rec in self:
            street1 = rec.partner_id.street or ''
            street2 = rec.partner_id.street2 or ''
            print(street1,street2)
            address = street1
            if street2:
                address += ', ' + street2

            print(address)
            rec.contact_street_address = address


    def action_open_map(self):
        for rec in self:
            if rec.google_location_link:
                return {
                    'type': 'ir.actions.act_url',
                    'url': rec.google_location_link,
                    'target': 'new',  # Opens in a new tab
                }

    def button_reschedule(self):
        return {
            'name': 'Reschedule Order',
            'type': 'ir.actions.act_window',
            'res_model': 'reschedule.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref('delivery_app_artx.view_reschedule_wizard').id,
            'target': 'new',
            'context': {'default_order_id': self.id},
        }

    def action_assign_driver(self):

        selected_picking_ids = self.env.context.get('active_ids', [])
        if not selected_picking_ids:
            return False

        return {
            'type': 'ir.actions.act_window',
            'name': 'Assign Driver',
            'res_model': 'assign.driver.wizard',
            'view_mode': 'form',
            'view_id': self.env.ref('delivery_app_artx.view_assign_driver_wizard_form').id,
            'target': 'new',
            'context': {'default_picking_ids': selected_picking_ids},
        }

    @api.model
    def skip_backorder_popup_for_driver(self):
        Param = self.env['ir.config_parameter'].sudo()
        return Param.get_param('stock.skip_backorder_driver', 'False') == 'True'

    def button_validate(self):
        """ Override button_validate to create an entry in warehouse.stock on validation """
        # warehouse_stock_model = self.env['warehouse.stock']
        #
        # for picking in self:
        #     for move in picking.move_ids_without_package:  # ✅ Correct Odoo 17 field
        #         try:
        #             product = move.product_id
        #
        #             # ✅ Get opening stock (On-hand quantity before transfer)
        #             opening_stock = self.env['stock.quant']._get_available_quantity(product, move.location_id)
        #
        #             # ✅ Ensure `cartons_per_pallet` is not zero
        #             cartons_per_pallet = product.product_tmpl_id.cartons_per_pallet or 1
        #
        #             # ✅ Compute opening pallets (Ceiling division)
        #             opening_pallets = math.ceil(opening_stock / cartons_per_pallet)
        #
        #             # ✅ Get inbound stock from `stock.move.line.quantity` (Odoo 17 correct field)
        #             inbound_stock = sum(move_line.quantity for move_line in move.move_line_ids)
        #
        #             # ✅ Set correct sign for incoming/outgoing moves
        #             if picking.picking_type_id.code == 'outgoing':
        #                 inbound_stock = -inbound_stock
        #
        #             # ✅ Compute total pallets (Ceiling division)
        #             total_pallets = math.ceil((opening_stock + inbound_stock) / cartons_per_pallet)
        #
        #             # ✅ Create warehouse stock entry
        #             warehouse_stock_model.create({
        #                 'date': date.today(),
        #                 'product_id': product.id,
        #                 'opening_stock': opening_stock,
        #                 'cartons_per_pallet': cartons_per_pallet,
        #                 'opening_pallets': opening_pallets,
        #                 'inbound_stock': inbound_stock,
        #                 'total_pallets': total_pallets,
        #             })
        #
        #         except Exception as e:
        #             _logger.error("Error creating warehouse stock entry for product %s: %s", product.name, str(e))
        #             continue  # ✅ Prevent Odoo from crashing on one failed entry

        print('validate called')
        config = self.env['ir.config_parameter'].sudo()
        driver_group = self.env.ref('delivery_app_artx.group_driver')

        skip_backorder = config.get_param('stock.skip_backorder_driver') == 'True'
        # res = super(StockPicking, self).button_validate()
        # for picking in self:
        #     # for move in picking.move_ids_without_package:
        #     #     if move.lot_ids:  # adjust only for lot-tracked products
        #     #         total_qty_done = sum(move.move_line_ids.mapped('quantity'))
        #     #         # reserved_qty = sum(move.move_line_ids.mapped('product_uom_qty'))
        #     #         delta = total_qty_done #- reserved_qty
        #     #         if delta:
        #     #             adj_lot = move._get_or_create_adjustment_lot(move.product_id)
        #     #             print('adj_lot made ')
        #     #             quant = self.env['stock.quant'].search([
        #     #                 ('lot_id', '=', adj_lot.id),
        #     #                 ('product_id', '=', move.product_id.id),
        #     #                 ('location_id', '=', move.location_id.id),
        #     #                 ('company_id', '=', move.company_id.id),
        #     #             ], limit=1)
        #     #             print('quant check ')
        #     #             if quant:
        #     #                 quant.quantity += delta
        #     #             else:
        #     #                 self.env['stock.quant'].create({
        #     #                     'lot_id': adj_lot.id,
        #     #                     'product_id': move.product_id.id,
        #     #                     'location_id': move.location_id.id,
        #     #                     'quantity': delta,
        #     #                     'company_id': move.company_id.id,
        #     #                 })
        #     if picking.picking_type_code == 'incoming':
        #         print('📦 Incoming picking detected: %s' % picking.name)
        #         try:
        #             product_lot_data = {}
        #
        #             for move_line in picking.move_line_ids:
        #                 product = move_line.product_id
        #                 lot = move_line.lot_id
        #                 tmpl = product.product_tmpl_id
        #                 print(lot.name)
        #                 if tmpl.tracking != 'lot':
        #                     print(f'❌ Product {tmpl.name} not tracked by lot.')
        #                     continue
        #
        #                 if not lot or lot.product_qty == 0:
        #                     print(f'⚠️ Skipping empty or weightless lot for product {tmpl.name}')
        #                     # continue
        #
        #                 if tmpl not in product_lot_data:
        #                     print(f'✅ Initializing tracking for product: {tmpl.name}')
        #                     product_lot_data[tmpl] = {
        #                         'total_weight': 0.0,
        #                         'lot_ids': set(),
        #                     }
        #
        #                 product_lot_data[tmpl]['total_weight'] += lot.product_qty
        #                 product_lot_data[tmpl]['lot_ids'].add(lot.id)
        #                 print(f'➕ Added lot {lot.name} (weight={lot.product_qty}) for product {tmpl.name}')
        #
        #             for tmpl, data in product_lot_data.items():
        #                 lot_count = len(data['lot_ids'])
        #                 print(f'🔍 Product {tmpl.name} has {lot_count} lots.')
        #
        #                 if lot_count > 0:
        #                     avg_weight = data['total_weight'] / lot_count
        #                     tmpl.write({'avg_cartons_weight': round(avg_weight,2)})
        #                     print(f'✅ v avg_cartons_weight to {round(avg_weight,2)} for product {tmpl.name}')
        #
        #         except Exception as e:
        #             _logger.warning("❌ Failed to update avg_cartons_weight: %s", e)
        #             print("❌ Error occurred while updating avg_cartons_weight:", e)


        if driver_group in self.env.user.groups_id:
            for picking in self:
                for move_line in picking.move_line_ids:
                    if not move_line.quantity:
                        move_line.quantity = move_line.product_uom_qty

            if not self.skip_backorder_popup_for_driver():
                picking_ids = self.ids
                # if(len(picking_ids)==1):
                #     print("RUNNINF")
                #     return super(StockPicking, self.with_context(skip_backorder=True,picking_ids_not_to_backorder=picking_ids).sudo()).button_validate()
                print('exited early')
                return super(StockPicking, self.with_context(skip_backorder=True,picking_ids_not_to_backorder=picking_ids).sudo()).button_validate()


        return super(StockPicking, self).button_validate()

    def action_create_invoice_from_delivery(self):
        for picking in self:
            sale_order = picking.sale_id
            if not sale_order:
                raise UserError("No Sale Order linked to this Delivery.")

            # Create the advance payment wizard with sudo
            wizard = self.env['sale.advance.payment.inv'].create({
                'advance_payment_method': 'delivered',
                'sale_order_ids': [(6, 0, [sale_order.id])],
            })
            wizard.create_invoices()

            # Search for the created invoice using sudo
            invoices = self.env['account.move'].search([
                ('invoice_origin', '=', sale_order.name),
                ('move_type', '=', 'out_invoice')
            ], order='id desc', limit=1)

            if invoices:
                return {
                    'name': 'Customer Invoice',
                    'view_mode': 'form',
                    'res_model': 'account.move',
                    'type': 'ir.actions.act_window',
                    'res_id': invoices.id,
                }
            else:
                raise UserError("Invoice was not created.")


    def write(self, vals):
        print("vals : ",vals)
        if "state" in vals:
            for record in self:
                if record.state == "done" and vals["state"] != "done":
                    raise UserError("You cannot move a completed order back!")
                if record.state == "driver_assigned" and vals["state"] != "done":
                    print("its time to preserve state change")
                    vals["state"] = "driver_assigned"
        return super().write(vals)

    #NEW SMART BUTTON

    invoice_count = fields.Integer(string="Invoices", compute="_compute_invoice_count")

    def _compute_invoice_count(self):
        for picking in self:
            sale = picking.sale_id
            if sale:
                invoices = self.env['account.move'].search([
                    ('invoice_origin', '=', sale.name),
                    ('move_type', '=', 'out_invoice'),
                ])
                picking.invoice_count = len(invoices)
            else:
                picking.invoice_count = 0

    def action_view_invoices(self):
        self.ensure_one()
        sale = self.sale_id
        if not sale:
            raise UserError("No Sale Order linked to this Delivery.")
        invoices = self.env['account.move'].search([
            ('invoice_origin', '=', sale.name),
            ('move_type', '=', 'out_invoice'),
        ])
        action = self.env.ref('account.action_move_out_invoice_type').read()[0]
        if len(invoices) == 1:
            action['views'] = [(self.env.ref('account.view_move_form').id, 'form')]
            action['res_id'] = invoices.id
        else:
            action['domain'] = [('id', 'in', invoices.ids)]
        return action

    total_product_qty = fields.Float(string="Total Cartons", compute="_compute_total_product_qty", store=True)
    total_weight = fields.Float(string="Total Weight(in Kgs)", compute="_compute_total_weight", store=True)
    hover_product_info = fields.Char(string="Product Info", compute="_compute_total_product_qty", store=True)
    hover_data = fields.Char(string="Hover Info", default="details", store=True)

    def action_show_product_info(self):
        self.ensure_one()
        return {
            'type': 'ir.actions.act_window',
            'name': 'Product Info',
            'res_model': 'hover.product.info.wizard',
            'view_mode': 'form',
            'target': 'new',
            'context': {
                'default_info': self.reference_tooltip,
            }
        }

    reference_tooltip = fields.Text(
        string="Info",
        compute='_compute_reference_tooltip',
        store=True,
        readonly=True,
        help=""
    )

    @api.depends('move_ids_without_package','sale_id.amount_total','purchase_id.amount_total','total_weight','total_product_qty')
    def _compute_reference_tooltip(self):
        for record in self:
            if record.move_ids_without_package:
                count=0
                tooltip_lines = []
                for move in record.move_ids_without_package:
                    # if(count>3):
                    #     tooltip_lines.append(f"and more........")
                    #     break
                    product_name = move.product_id.name or 'Unknown Product'
                    qty = move.product_uom_qty
                    uom = move.product_uom.name or ''
                    # tooltip_lines.append(f"• {product_name}: {qty} {uom}")
                    rate = 0.0
                    currency = record.company_id.currency_id
                    if move.sale_line_id:
                        rate = move.sale_line_id.price_unit
                        currency = move.sale_line_id.currency_id
                    elif move.purchase_line_id:
                        rate = move.purchase_line_id.price_unit
                        currency=move.purchase_line_id.currency_id
                    else:
                        rate = move.product_id.list_price  # fallback

                    tooltip_lines.append(
                        f"• {product_name}: {qty} {uom} @ {rate:.2f} {currency.symbol}"
                    )
                    count+=1
                record.reference_tooltip = "Products:\n" + "\n".join(tooltip_lines)
                print('tooltip computed result = ',record.reference_tooltip)
            else:
                record.reference_tooltip = "No products in this picking"

    @api.depends('move_ids.total_weight', 'move_line_ids')
    def _compute_total_weight(self):
        for picking in self:
            total_qty = 0
            for move in picking.move_ids:
                if move.product_id.tracking in ['lot']:
                    qty = move.product_uom_qty
                else:
                    qty = move.total_weight
                total_qty += qty
            picking.total_weight= total_qty

    @api.depends('move_ids', 'move_line_ids')
    def _compute_total_product_qty(self):
        logs=""
        for picking in self:
            total_qty = 0
            for move in picking.move_ids:
                # if move.product_id.tracking in ['lot', 'serial']:
                #     # Count unique lots from move lines
                #     lot_count = self.env['stock.move.line'].search_count([
                #         ('move_id', '=', move.id),
                #         ('lot_id', '!=', False)
                #     ])
                #     qty = lot_count
                if move.product_id.box_boolean:
                    qty = move.delivered_box
                else:
                    qty = move.product_uom_qty

                # Optional: Uncomment if outbound moves should be negative
                # if move.location_dest_id.usage == 'customer':
                #     qty = -1 * qty

                total_qty += qty  # ✅ You missed this line in the original code
                logs += f"{move.product_id.display_name}: {qty} \n"


            picking.total_product_qty = total_qty
            picking.hover_product_info = logs

    

    def action_recompute_hover_info(self):
        for picking in self:
            picking._compute_total_product_qty()
            picking._compute_total_weight()
            picking._compute_reference_tooltip()


class StockReturnPickingLine(models.TransientModel):
    _inherit = "stock.return.picking.line"

    delivered_box = fields.Integer(string="Delivered Box")

    box_boolean = fields.Boolean(
        related="product_id.product_tmpl_id.box_boolean",
        store=False
    )

    
    
    


class StockReturnPicking(models.TransientModel):
    _inherit = "stock.return.picking"

    def _prepare_move_default_values(self, return_line, new_picking):
        vals = super()._prepare_move_default_values(return_line, new_picking)

        # Add the value into new move
        if return_line.delivered_box:
            vals["delivered_box"] = return_line.delivered_box

        return vals
    




    @api.model
    def _prepare_stock_return_picking_line_vals_from_move(self, stock_move):
        vals = super()._prepare_stock_return_picking_line_vals_from_move(stock_move)

        # Fetch the old delivered_box value from stock.move
        old_delivered_box = stock_move.delivered_box or 0

        vals.update({
            'delivered_box': old_delivered_box,
        })
        return vals



