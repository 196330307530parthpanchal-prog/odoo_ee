from odoo import models, fields, api, _
from odoo.exceptions import UserError

class PurchaseOrderLine(models.Model):
    _inherit = "purchase.order"


    def button_confirm(self):

        for order in self:
            invalid_lines = order.order_line.filtered(
                lambda l: l.show_box and l.purchase_box == 0
            )

            if invalid_lines:
                product_names = "\n".join(
                    invalid_lines.mapped('product_id.display_name')
                )

                raise UserError(_(
                    "Box quantity cannot be 0 for the following products:\n%s"
                ) % product_names)

        res = super().button_confirm()

        for order in self:

            # -----------------------------
            # 🔥 1) COPY BOX → DEMAND_BOX
            # -----------------------------
            for line in order.order_line:
                for move in line.move_ids:
                    move.demand_box = line.purchase_box
                    move.delivered_box = line.purchase_box

          

        return res