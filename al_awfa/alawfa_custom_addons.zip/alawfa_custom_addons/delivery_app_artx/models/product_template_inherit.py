from odoo import models, fields, api,_
from odoo.exceptions import UserError

class Productproduct(models.Model):
    _inherit = 'product.product'

    def action_archive(self):
        if not self.env.user.has_group('base.group_system'):
            raise UserError(_("You are not allowed to archive products/."))
        return super().action_archive()

    def action_unarchive(self):
        if not self.env.user.has_group('base.group_system'):
            raise UserError(_("You are not allowed to unarchive products/."))
        return super().action_unarchive()

class ProductTemplate(models.Model):
    _inherit = 'product.template'

    list_price = fields.Float(
        'Sales Price', default=1.0,
        digits='Product Price',
        help="Price at which the product is sold to customers.",
        tracking=True
    )

    box_boolean = fields.Boolean(string="Enable Alternate UOM")
    # my_uom_category_id = fields.Many2one(
    #     'uom.category',
    #     string="Alternate UOM"
    # )

    # updated_box = fields.Integer(string="CRT",store=True)

    updated_box = fields.Integer(
        string="CRT",
        company_dependent=True
    )

    def open_product_barcode(self):
        return {
            "name": "My Wizard",
            "type": "ir.actions.act_window",
            "res_model": "stock.change.product.qty",
            "view_mode": "form",
            "target": "new",
            "context": {
                'default_new_box_update': self.updated_box,
                'active_id': self.id,              # <-- MOST IMPORTANT
                'active_model': 'product.template' # <-- Tells wizard which model it comes from
            }
        }

    cartons_per_pallet = fields.Integer(string="Cartons Per Pallet", help="Number of cartons that fit in one pallet",default=20)
    avg_cartons_weight = fields.Float(string="Average weight of Carton", help="Average maintained at purchase to avoid confusion at sales",default=20)
    lot_sequence_id = fields.Many2one(
        'ir.sequence',
        string="Lot Sequence",
        help="Sequence used to generate lot numbers for this product."
    )
    adjustment_lot_id = fields.Many2one('stock.lot', string="Adjusting Lot ID", help="Id of the lot which stores the adjustments for this peoducts")

    @api.model_create_multi
    def create(self, vals_list):
        products = super().create(vals_list)
        for product in products:
            if product.tracking == 'lot' and not product.lot_sequence_id:
                seq = self.env['ir.sequence'].create({
                    'name': f"Lot Sequence for {product.name}",
                    'code': f"stock.lot.{product.id}",  # unique per product
                    'prefix': f"{product.default_code or product.id}-LOT-",
                    'padding': 4,
                    'company_id': product.company_id.id if product.company_id else False,
                })
                product.lot_sequence_id = seq.id

        self.create_sequences_for_product()
        return products

    def create_sequences_for_product(self):
        products=self.env['product.template'].search([])
        for product in products:
            if product.tracking == 'lot' and not product.lot_sequence_id:
                seq = self.env['ir.sequence'].create({
                    'name': f"Lot Sequence for {product.name}",
                    'code': f"stock.lot.{product.id}",  # unique per product
                    'prefix': f"{product.name or product.default_code}-LOT-",
                    'padding': 4,
                    'company_id': product.company_id.id if product.company_id else False,
                })
                product.lot_sequence_id = seq.id
        return products

    # crt_qty = fields.Integer(
    #     string="CRT",
    #     compute="_compute_crt_qty",
    #     store=False
    # )
    def open_product_barcode_1(self):
        return {
            "name": "My Wizard",
            "type": "ir.actions.act_window",
            "res_model": "stock.change.product.qty",
            "view_mode": "form",
            "target": "new",
            "context": {
                'active_id': self.id,  # <-- MOST IMPORTANT
                'active_model': 'product.template'  # <-- Tells wizard which model it comes from
            }
        }

    # def _compute_crt_qty(self):
    #     print("mera code chal gaya")
    #     MoveLine = self.env['stock.move.line']
    #     Location = self.env['stock.location']
    #
    #     for product in self:
    #         if not product.box_boolean:
    #             product.crt_qty = 0
    #             continue
    #
    #         print(f'companies {self.env.companies}')
    #         print(f' ids {self.env.companies.ids}')
    #         data = MoveLine.search(
    #             domain=[
    #                 ('product_id.product_tmpl_id', '=', product.id),
    #                 ('company_id', 'in', self.env.companies.ids),
    #                 ('state', '=', 'done'),
    #                 '|',
    #                 ('location_id.usage', '=', 'internal'),
    #                 ('location_dest_id.usage', '=', 'internal'),
    #             ],
    #         )
    #         print(data)
    #         incoming = 0
    #         outgoing = 0
    #
    #         for row in data:
    #             print(row)
    #             boxes = row.boxes
    #             print(f"boxes {boxes}")
    #             src = row.location_id
    #             print(f"src {src}")
    #             dest = row.location_dest_id
    #             print(f"dest {dest}")
    #
    #             if not src:
    #                 continue
    #
    #             src_usage = src.usage
    #             print(f"src_usage {src_usage}")
    #             dest_usage = dest.usage
    #             print(f"src_usage {dest_usage}")
    #
    #             if src_usage in 'supplier':
    #                 incoming += boxes
    #             elif src_usage == 'internal':
    #                 if dest_usage != 'internal':
    #                     outgoing+= boxes
    #             elif src_usage == 'inventory':
    #                 incoming+=boxes
    #             elif src_usage == 'customer':
    #                 incoming+=boxes
    #             print(f"incoming {incoming} , outgoing {outgoing}")
    #
    #         print(f"total {incoming - outgoing}")
    #         product.crt_qty = incoming - outgoing

    crt_qty = fields.Integer(
        string="CRT",
        compute="_compute_crt_qty",
        store=False,
    )

    @api.depends('product_variant_ids.stock_move_ids.move_line_ids.boxes')
    def _compute_crt_qty(self):

        products = self.filtered(lambda p: p.box_boolean)

        # Default values
        for product in self:
            product.crt_qty = 0

        if not products:
            return

        MoveLine = self.env['stock.move.line']

        domain = [
            ('product_id.product_tmpl_id', 'in', products.ids),
            ('company_id', 'in', self.env.companies.ids),
            ('state', '=', 'done'),
            '|',
            ('location_id.usage', '=', 'internal'),
            ('location_dest_id.usage', '=', 'internal'),
        ]

        move_lines = MoveLine.search(domain)

        qty_map = {}

        for line in move_lines:

            tmpl_id = line.product_id.product_tmpl_id.id

            qty_map.setdefault(tmpl_id, 0)

            src_usage = line.location_id.usage
            dest_usage = line.location_dest_id.usage

            boxes = line.boxes or 0

            # Incoming
            if src_usage in ['supplier', 'inventory', 'customer']:
                qty_map[tmpl_id] += boxes

            # Outgoing
            elif src_usage == 'internal' and dest_usage != 'internal':
                qty_map[tmpl_id] -= boxes

        for product in products:
            product.crt_qty = qty_map.get(product.id, 0)

    def _compute_crt_qty_1company(self):
        print("mera code chal gaya")
        MoveLine = self.env['stock.move.line']
        Location = self.env['stock.location']

        for product in self:
            if not product.box_boolean:
                product.crt_qty = 0
                continue

            print(f'company {self.env.company}')
            print(f' id {self.env.company.id}')
            data = MoveLine.search(
                domain=[
                    ('product_id.product_tmpl_id', '=', product.id),
                    ('company_id', '=', self.env.company.id),
                    ('state', '=', 'done'),
                    '|',
                    ('location_id.usage', '=', 'internal'),
                    ('location_dest_id.usage', '=', 'internal'),
                ],
            )
            print(data)
            incoming = 0
            outgoing = 0

            for row in data:
                print(row)
                boxes = row.boxes
                print(f"boxes {boxes}")
                src = row.location_id
                print(f"src {src}")
                dest = row.location_dest_id
                print(f"dest {dest}")

                if not src:
                    continue

                src_usage = src.usage
                print(f"src_usage {src_usage}")
                dest_usage = dest.usage
                print(f"src_usage {dest_usage}")

                if src_usage in 'supplier':
                    incoming += boxes
                elif src_usage == 'internal':
                    if dest_usage != 'internal':
                        outgoing+= boxes
                elif src_usage == 'inventory':
                    incoming+=boxes
                elif src_usage == 'customer':
                    incoming+=boxes
                print(f"incoming {incoming} , outgoing {outgoing}")

            print(f"return total {incoming - outgoing}")
            return incoming - outgoing

    def action_archive(self):
        if not self.env.user.has_group('base.group_system'):
            raise UserError(_("You are not allowed to archive products."))
        return super().action_archive()

    def action_unarchive(self):
        if not self.env.user.has_group('base.group_system'):
            raise UserError(_("You are not allowed to unarchive products."))
        return super().action_unarchive()

    forecast_crt_qty = fields.Float(
        string="Forecast Boxes",
        compute="_compute_forecast_crt_qty",
    )

    # def _compute_forecast_crt_qty(self):
    #
    #     MoveLine = self.env['stock.move.line']
    #
    #     for product in self:
    #
    #         if not product.box_boolean:
    #             product.forecast_crt_qty = 0
    #             continue
    #
    #         move_lines = MoveLine.search([
    #             ('product_id.product_tmpl_id', '=', product.id),
    #             ('company_id', 'in', self.env.companies.ids),
    #             '|',
    #             ('location_id.usage', '=', 'internal'),
    #             ('location_dest_id.usage', '=', 'internal'),
    #         ])
    #
    #         total = 0
    #
    #         for line in move_lines:
    #
    #             boxes = line.boxes or 0
    #             print("line_id : ",line.id)
    #             src_usage = line.location_id.usage
    #             dest_usage = line.location_dest_id.usage
    #             print("src_usage : ",src_usage)
    #             print("dest_usage : ",dest_usage)
    #             print("boxes : ",line.boxes)
    #
    #             # INCOMING
    #             if dest_usage == 'internal':
    #                 print("line.state : ",line.state)
    #                 # done incoming
    #                 if line.state == 'done':
    #                     total += boxes
    #
    #                 # assigned/waiting incoming forecast
    #                 elif line.state in ['assigned', 'confirmed', 'waiting']:
    #                     total += boxes
    #
    #             # OUTGOING
    #             if src_usage == 'internal' and dest_usage != 'internal':
    #                 print("line.state : ", line.state)
    #                 # done outgoing
    #                 if line.state == 'done':
    #                     total -= boxes
    #
    #                 # reserved/planned outgoing
    #                 elif line.state in ['assigned', 'confirmed', 'waiting']:
    #                     total -= boxes
    #
    #         product.forecast_crt_qty = total
    def _compute_forecast_crt_qty(self):

        Move = self.env['stock.move']

        for product in self:

            if not product.box_boolean:
                product.forecast_crt_qty = 0
                continue

            moves = Move.search([
                ('product_id.product_tmpl_id', '=', product.id),
                ('company_id', 'in', self.env.companies.ids),
                ('state', 'not in', ['done', 'cancel']),
            ])

            total = product.crt_qty

            for move in moves:

                boxes = move.delivered_box or move.demand_box or 0
                print(f"boxes : {move.delivered_box} {move.demand_box}")
                src_usage = move.location_id.usage
                dest_usage = move.location_dest_id.usage
                print(f"src_usage {src_usage}")
                print(f"dest_usage {dest_usage}")
                
                # incoming forecast
                if dest_usage == 'internal':
                    total += boxes

                # outgoing forecast
                elif src_usage == 'internal':
                    total -= boxes

            product.forecast_crt_qty = total
    

class StockChangeProductQtyInherit(models.TransientModel):
    _inherit = "stock.change.product.qty"

    # ⭐ ADD NEW FIELD
    new_box_update = fields.Integer(string="New Quantity on CRT")

    box_boolean = fields.Boolean(
        related="product_id.product_tmpl_id.box_boolean",
        store=False
    )

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)

        if 'product_id' in res:
            product = self.env['product.product'].browse(res['product_id'])
            res['new_box_update'] = product.product_tmpl_id.crt_qty or 0

        return res
    
    # def change_product_qty(self):
    #     res = super().change_product_qty()
    #
    #     for wiz in self:
    #         if wiz.new_box_update:
    #
    #             product = wiz.product_id.product_tmpl_id
    #             old_value = product.crt_qty
    #             new_value = wiz.new_box_update
    #             diff = new_value - old_value
    #             clean_value = abs(diff)
    #             print(f'old value {old_value}')
    #             print(f'new_value {new_value}')
    #             print(f'diff {diff}')
    #             print(f'clean_value {clean_value}')
    #
    #             # update main CRT field
    #             # product.updated_box = new_value
    #
    #             move_line = self.env['stock.move.line'].search(
    #                 [('product_id', '=', wiz.product_id.id)],
    #                 order="id desc",
    #                 limit=1
    #             )
    #
    #             if move_line:
    #                 picking_type_code = "incoming" if diff > 0 else "outgoing"
    #
    #                 # IMPORTANT: use context flag
    #                 move_line.with_context(manual_box_update=True).write({
    #                     "boxes": clean_value,
    #                     "picking_type_code": picking_type_code,
    #                 })
    #
    #     return res
    # def change_product_qty(self):
    #     res = super().change_product_qty()
    #
    #     StockMoveLine = self.env['stock.move.line']
    #     company = self.env.company
    #
    #     warehouse = self.env['stock.warehouse'].search(
    #         [('company_id', '=', company.id)], limit=1
    #     )
    #     if not warehouse:
    #         raise UserError(_("No warehouse for this company"))
    #
    #     for wiz in self:
    #         if not wiz.new_box_update:
    #             continue
    #
    #         product = wiz.product_id
    #         tmpl = product.product_tmpl_id
    #
    #         old_boxes = tmpl.crt_qty
    #         new_boxes = wiz.new_box_update
    #         diff = new_boxes - old_boxes
    #
    #         if diff == 0:
    #             continue
    #
    #         # 1️⃣ Trigger inventory mode WITHOUT changing kg
    #         quant = self.env['stock.quant'].with_context(
    #             inventory_mode=True
    #         ).create({
    #             'product_id': product.id,
    #             'location_id': warehouse.lot_stock_id.id,
    #             'inventory_quantity': product.qty_available,  # SAME quantity
    #         })
    #
    #         # 2️⃣ Apply inventory (Odoo creates move lines)
    #         quant._apply_inventory()
    #
    #         # 3️⃣ Attach CRT to the generated move lines
    #         move_lines = StockMoveLine.search(
    #             [
    #                 ('product_id', '=', product.id),
    #                 ('company_id', '=', company.id),
    #             ],
    #             order='id desc',
    #             limit=1
    #         )
    #
    #         for ml in move_lines:
    #             ml.boxes = abs(diff)
    #
    #     return res

    def change_product_qty(self):
        res = super().change_product_qty()

        StockMove = self.env['stock.move']
        StockMoveLine = self.env['stock.move.line']

        company = self.env.company

        # 1️⃣ Resolve company-safe locations
        inventory_adj = self.env['stock.location'].search(
            [('company_id', '=', company.id),
             ('usage', '=', "inventory"),
             ('name', '=', "Inventory adjustment")],
            limit=1
        )
        inventory_location = inventory_adj.id
        print(f'inventory_location {inventory_location}')
        if not inventory_location:
            raise UserError(_("No inventory adjustment location defined for this company"))

        warehouse = self.env['stock.warehouse'].search(
            [('company_id', '=', company.id)],
            limit=1
        )
        if not warehouse:
            raise UserError(_("No warehouse found for this company"))

        internal_location = warehouse.lot_stock_id
        print(f'internal_location {internal_location}')

        for wiz in self:
            # if not wiz.new_box_update:
            #     print('exitted due to 0')
            #     continue

            product = wiz.product_id
            tmpl = product.product_tmpl_id

            if(tmpl.box_boolean == False):
                continue

            old_value = tmpl._compute_crt_qty_1company()
            new_value = wiz.new_box_update
            diff = new_value - old_value

            if diff == 0:
                continue

            if diff > 0:
                # Inventory → Internal (gain)
                location_id = inventory_location
                location_dest_id = internal_location.id
            else:
                # Internal → Inventory (loss)
                location_id = internal_location.id
                location_dest_id = inventory_location

                # 3️⃣ Create stock move (company-safe)
            print('creating move')
            move = StockMove.create({
                'name': _('CRT Inventory Adjustment'),
                'product_id': product.id,
                'product_uom': product.uom_id.id,
                'company_id': company.id,
                'location_id': location_id,
                'location_dest_id': location_dest_id,
                'state': 'done',
            })

            # 4️⃣ Create move line (boxes only)
            print('creating move line')
            StockMoveLine.sudo().create({
                'move_id': move.id,
                'product_id': product.id,
                'company_id': company.id,
                'location_id': location_id,
                'location_dest_id': location_dest_id,
                'quantity': 0.01,
                'boxes': abs(diff),
            })
            print('its done')
            StockMoveLine.sudo().create({
                'move_id': move.id,
                'product_id': product.id,
                'company_id': company.id,
                'location_id': location_dest_id,
                'location_dest_id': location_id,
                'quantity': 0.01,
                'boxes': 0,
            })
            print('its done again')


        return res
    


    def open_product_barcode(self):
        return {
            "name": "My Wizard",
            "type": "ir.actions.act_window",
            "res_model": "stock.change.product.qty",
            "view_mode": "form",
            "target": "new",
            "context": {
                'default_new_box_update': self.updated_box,
                'active_id': self.id,              # <-- MOST IMPORTANT
                'active_model': 'product.template' # <-- Tells wizard which model it comes from
            }
        }