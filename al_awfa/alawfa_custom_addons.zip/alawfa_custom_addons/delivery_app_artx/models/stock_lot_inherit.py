from odoo import models, fields, api
from datetime import datetime,timedelta

class StockLot(models.Model):
    _inherit = "stock.lot"

    def _get_or_create_adjustment_lot(self, product):
        print('_get_or_create_adjustment_lot called in lot')
        lot = self.env['stock.lot'].search([
            ('product_id', '=', product.id),
            ('name', '=', '~ADJUSTMENT-LOT')
        ], limit=1)
        if not lot:
            lot = self.env['stock.lot'].create({
                'product_id': product.id,
                'name': '~ADJUSTMENT-LOT',
                'company_id': self.env.company.id,
            })
        product.adjustment_lot_id = lot
        return lot

    def _cron_adjust_lot_balances(self):
        print('_cron_adjust_lot_balances called')
        """Cron that processes one product per run to avoid overload."""
        last_id = int(self.env['ir.config_parameter'].sudo().get_param('cron_adjust_lot_last_id', 0))

        # Fetch the next product after last_id
        product = self.env['product.product'].search(
            [('tracking', '=', 'lot'), ('id', '>', last_id)],
            order="id asc", limit=1
        )
        print('pname: ', product.name)

        if not product:
            # Reset if reached end
            self.env['ir.config_parameter'].sudo().set_param('cron_adjust_lot_last_id', 0)
            return

        self._process_product_lots(product)
        print(f'processing the product {product.name} for adjustments of remaining lots')

        # Save the last processed product id
        self.env['ir.config_parameter'].sudo().set_param('cron_adjust_lot_last_id', product.id)

    def _process_product_lots(self, product):
        print('_process_product_lots called')
        """Process adjustment logic for a single product."""
        avg_weight = product.avg_cartons_weight or 0
        if not avg_weight:
            return

        adj_lot = self._get_or_create_adjustment_lot(product)

        # Get all quants for this product except adjustment lot
        quants = self.env['stock.quant'].search([
            ('product_id', '=', product.id),
            ('location_id.usage', '=', 'internal'),
            ('lot_id', '!=', adj_lot.id),
        ])
        print(quants)

        total_remainder = 0.0
        for quant in quants:
            q_check = quant.quantity + quant.inventory_diff_quantity
            print("quant.quantity: ", quant.quantity)
            print("quant.inventory_diff_quantity: ",quant.inventory_diff_quantity)
            print("q_check: ",q_check)
            if q_check < 0:
                total_remainder += quant.quantity
                quant.inventory_quantity = 0
                quant._apply_inventory()

        # Adjust or create quant for adjustment lot
        adj_quant = self.env['stock.quant'].search([
            ('lot_id', '=', adj_lot.id),
            ('product_id', '=', product.id),
        ], limit=1)
        print("total_remainder: ",total_remainder)
        if total_remainder:
            print(f'resetting adjustment lot {adj_quant.quantity} + {total_remainder}')
            if adj_quant:
                new_qty = adj_quant.quantity + total_remainder
                adj_quant.inventory_quantity = new_qty
                adj_quant._apply_inventory()
            else:
                self.env['stock.quant'].create({
                    'product_id': product.id,
                    'lot_id': adj_lot.id,
                    'quantity': total_remainder,
                    'location_id': self.env.ref('stock.stock_location_stock').id,
                    'company_id': product.company_id.id,
                })


# from odoo import models, fields, api
# from datetime import datetime
#
# class StockLot(models.Model):
#     _inherit = "stock.lot"
#
#
#     def _get_or_create_adjustment_lot(self, product):
#         """Return the Adjustment Lot for this product, create if not exists."""
#         print('_get_or_create_adjustment_lot called in lot')
#         lot = self.env['stock.lot'].search([
#             ('product_id', '=', product.id),
#             ('name', '=', '~ADJUSTMENT-LOT')
#         ], limit=1)
#         if not lot:
#             lot = self.env['stock.lot'].create({
#                 'product_id': product.id,
#                 'name': '~ADJUSTMENT-LOT',
#                 'company_id': self.env.company.id,
#             })
#         product.adjustment_lot_id = lot
#         return lot
#
#     def _cron_adjust_lot_balances(self):
#         # products = self.env['product.product'].search([('tracking', '=', 'lot'),('name', '=', 'Starf')])
#         products = self.env['product.product'].search([('tracking', '=', 'lot')])
#         for product in products:
#             print('pname: ', product.name)
#             avg_weight = product.avg_cartons_weight or 0
#             print('avg_weight=',avg_weight)
#             if not avg_weight:
#                 continue
#
#             # Create/get adjustment lot
#             adj_lot = self._get_or_create_adjustment_lot(product)
#
#             # Collect remainders from all lots except adjustment lot
#             lots = self.search([('product_id', '=', product.id), ('id', '!=', adj_lot.id)])
#             print('lots: ', lots)
#             total_remainder = 0.0
#
#             for lot in lots:
#                 print('Name', lot.name)
#                 qty = lot.product_qty
#                 print('qty: ', qty)
#                 # if not qty:
#                 #     continue
#
#                 # remainder = qty % avg_weight
#                 # select partially consumed lots by checking ?
#                 # if (qty != avg_weight) or 1:
#                     # Reset original lot’s quant to 0 using inventory adjustment
#                     # print('resetting the lot')
#                     # quants = self.env['stock.quant'].search([
#                     #     ('lot_id', '=', lot.id),
#                     #     ('product_id', '=', product.id),
#                     # ])
#
#                 quants = self.env['stock.quant'].search([
#                     ('lot_id', '=', lot.id),
#                     ('product_id', '=', product.id),
#                     ('location_id.usage', '=', 'internal'),
#                     # ('quantity', '>', 0)  # Count only active lots
#                 ])
#                 print(quants)
#                 for quant in quants:
#                     q_check = quant.quantity + quant.inventory_diff_quantity
#                     print("quant.quantity: ",quant.quantity)
#                     print("quant.inventory_diff_quantity: ",quant.inventory_diff_quantity)
#                     print("q_check: ",q_check)
#                     if q_check < 0:
#                         total_remainder += qty  # add full qty to adjustment
#                         quant.inventory_quantity = 0
#                         quant._apply_inventory()
#
#                     # quants.unlink()  # remove quants linked to this lot
#                     #
#                     # # Now delete the lot itself
#                     # lot.unlink()
#
#
#             # Preserve existing qty of adjustment lot
#             adj_quant = self.env['stock.quant'].search([
#                 ('lot_id', '=', adj_lot.id),
#                 ('product_id', '=', product.id),
#             ], limit=1)
#
#             if adj_quant:
#                 print('resetting adjustment lot')
#                 new_qty = adj_quant.quantity + total_remainder
#                 adj_quant.inventory_quantity = new_qty
#                 adj_quant._apply_inventory()
#             else:
#                 self.env['stock.quant'].create({
#                     'product_id': product.id,
#                     'lot_id': adj_lot.id,
#                     'quantity': total_remainder,
#                     'location_id': self.env.ref('stock.stock_location_stock').id,
#                     'company_id': product.company_id.id,
#                 })
#
