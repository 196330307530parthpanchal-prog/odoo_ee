from . import vehicle_details
from . import res_partner_inherit
from . import dispatch_details
from . import dispatch_order_details
from . import assign_driver_wizard
from . import stock_picking_inherit
from . import reschedule_wizard
from . import product_template_inherit
# from . import warehouse_stock
# from . import warehouse_weekly_stock
# from . import warehouse_daily_stock
from . import mail_compose_package_inherit
from . import account_payment_register_inherit
from . import hr_employee_inherit
from . import res_users_inherit
from . import account_journal_inherit
from . import transfer_funds_wizard
from . import commision
from . import commission_achievement
from . import sale_order
from . import dispatch_order_line
from . import account_move_inherit
from . import stock_lot_inherit
from . import sale_order_line_inherit
from . import stock_move_line_inherit
# from . import warehouse_billing_wizard
from . import stock_move_inherit
from . import purchase_order_inherit
from . import purchase_order_line_inherit







