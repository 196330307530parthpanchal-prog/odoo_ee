from odoo import models, fields, api

class WarehouseDailyStock(models.Model):
    _name = 'warehouse.daily.stock'
    _description = 'Daily Total Pallets Used'

    date = fields.Date(string="Date", required=True, default=fields.Date.today, unique=True)
    total_pallets = fields.Integer(string="Total Pallets", compute="_compute_total_pallets", store=True)

    @api.depends('date')
    def _compute_total_pallets(self):
        """Compute total pallets used by taking the max total_pallets per product."""
        for record in self:
            # Get all products in warehouse.stock for the given date
            products = self.env['warehouse.stock'].search([('date', '=', record.date)]).mapped('product_id')

            total_pallets = 0
            for product in products:
                # Get the maximum total_pallets for this product on that date
                max_pallets = self.env['warehouse.stock'].search([
                    ('date', '=', record.date),
                    ('product_id', '=', product.id)
                ], order="total_pallets desc", limit=1).total_pallets

                total_pallets += max_pallets

            record.total_pallets = total_pallets

    @api.model
    def create_daily_stock_entry(self):
        """Ensure a daily stock entry is created for today."""
        today = fields.Date.context_today(self)
        existing_record = self.search([('date', '=', today)], limit=1)

        if not existing_record:
            self.create({'date': today})