from odoo import models, fields, api, _
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from odoo.exceptions import ValidationError  # <- import this
from odoo.exceptions import UserError  # <- import this

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    is_admin_user = fields.Boolean(
        compute='_compute_is_admin_user'
    )

    @api.depends_context('uid')
    def _compute_is_admin_user(self):
        for rec in self:
            rec.is_admin_user = self.env.user.has_group('base.group_system')

    remarks_for_dispatch= fields.Char(string="Remarks", size=25, help="Visible to Dispatch Manager and Driver")

    delivery_date_option = fields.Selection(
        [('today', 'Today'), ('tomorrow', 'Tomorrow')],
        string="Delivery Date",
        default='today'
    )
    time_of_day = fields.Selection(
        [('morning', 'Morning'), ('evening', 'Evening')],
        string="Delivery Time",
        default='morning'
    )

    def action_quotations_custom(self):
        action = self.env.ref('sale.action_quotations').sudo().read()[0]

        if self.env.user.has_group('delivery_app_artx.group_driver'):
            # Filter to only the sale orders created by the logged-in user
            action['domain'] = [('user_id', '=', self.env.uid)]
        else:
            # No domain for others
            action['domain'] = []

        return action

    # def action_confirm(self):
    #     res = super().action_confirm()

    #     for order in self:
    #         for picking in order.picking_ids:
    #             print('Testtttttttttttttttttttttttt', )
    #             print('order.time_of_day', order.time_of_day)
    #             print('Testtttttttttttttttttttttttt', )
    #             picking.time_of_day = order.time_of_day.capitalize()

    #     return res
    def action_confirm(self):
        for order in self:
            invalid_lines = order.order_line.filtered(
                lambda l: l.show_box and l.box == 0
            )

            if invalid_lines:
                product_names = "\n".join(
                    invalid_lines.mapped('product_id.display_name')
                )

                raise UserError(_(
                    "Box quantity cannot be 0 for the following products:\n%s"
                ) % product_names)

        res = super().action_confirm()

        for order in self:

            # -----------------------------
            # 🔥 1) COPY BOX → DEMAND_BOX
            # -----------------------------
            for line in order.order_line:
                for move in line.move_ids:
                    move.demand_box = line.box
                    move.delivered_box = line.box

            # -----------------------------
            # 🔥 2) YOUR existing picking logic
            # -----------------------------
            for picking in order.picking_ids:
                print('Testtttttttttttttttttttttttt')
                print('order.time_of_day', order.time_of_day)
                print('Testtttttttttttttttttttttttt')
                picking.time_of_day = order.time_of_day.capitalize()

        return res

    @api.onchange('delivery_date_option')
    def _onchange_delivery_date_option(self):
        if self.delivery_date_option == 'today':
            self.commitment_date = fields.Datetime.now() + timedelta(hours=2)

        elif self.delivery_date_option == 'tomorrow':
            self.commitment_date = fields.Datetime.now() + timedelta(days=1)



    driver_ids = fields.Many2many(
        'hr.employee',
        string="Drivers",
        compute='_compute_driver_ids',
        store=True
    )

    @api.depends('picking_ids.driver_details')
    def _compute_driver_ids(self):
        for order in self:
            drivers = order.picking_ids.mapped('driver_details')
            order.driver_ids = drivers

    driver_display = fields.Char(
        string="Driver Status",
        compute="_compute_driver_display",
        store=True
    )

    @api.depends('driver_ids')
    def _compute_driver_display(self):
        for rec in self:
            rec.driver_display = ", ".join(rec.driver_ids.mapped('name')) if rec.driver_ids else "No Driver Assigned"

class ResPartner(models.Model):
    _inherit = 'res.partner'

    @api.constrains('name')
    def _check_unique_name_case_insensitive(self):
        for partner in self:
            if partner.name:
                existing = self.search([
                    ('id', '!=', partner.id),
                    ('name', '=ilike', partner.name)
                ], limit=1)
                if existing:
                    raise ValidationError("Customer name must be unique.")
