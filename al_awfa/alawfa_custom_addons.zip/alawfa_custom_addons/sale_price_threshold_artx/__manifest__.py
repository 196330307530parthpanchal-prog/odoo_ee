{
    "name": "Areterix Sale price threshold",
    "author": "Manav Fitter",
    "license": "LGPL-3",
    "verion": "17.0.1.1",
    "depends": [
        'delivery_app_artx',
        'web',
        'base_automation',
        'sale',
        'sale_management',
        'uom',
        'sale_stock',
    ],
    "data": [
        "views/pricelist_item_views.xml",
        "views/sale_order_views.xml"
    ],
    # 'assets': {
    #     'web.assets_backend': [
    #         'delivery_app_artx/static/src/**/*.js',
    #         'delivery_app_artx/static/src/**/*.xml',
    #         "delivery_app_artx/static/lib/xlsx.full.min.js",
    #         "delivery_app_artx/static/src/scss/import_excel.scss"
    #         "delivery_app_artx/static/src/view/fields/hover_summary_field.js"
    #         "delivery_app_artx/static/src/view/fields/hover_summary_field.xml"
    #     ],
    # },
    'sequence': 1,
    'installable': True,
    'application': False,
    'auto_install': False,
}