from odoo import models, fields, api, _
from odoo.exceptions import UserError

class SaleOrderLine(models.Model):
    _inherit = "sale.order.line"

    net_unit_price = fields.Float(
        string="Net Unit Price",
        compute="_compute_net_unit_price",
        store=True
    )

    threshold_price = fields.Float(
        string="Threshold Price",
        compute="_compute_threshold_price",
        store=True,
        digits="Product Price",
    )

    below_threshold_price = fields.Boolean(
        string="Below Threshold Price",
        readonly=True,
        help="True if suggested price is below product list price."
    )

    threshold_remarks = fields.Text(
        string="Threshold Remarks",
        help="Mandatory remarks when price is below threshold"
    )

    can_edit_threshold_remarks = fields.Boolean(
        compute="_compute_can_edit_threshold_remarks",
        store=False
    )

    # # @api.depends('order_id.approver_id')
    # def _compute_can_edit_threshold_remarks(self):
    #     uid = self.env.user.id
    #     for line in self:
    #         line.can_edit_threshold_remarks = (
    #                 # bool(line.order_id.approver_id)
    #                 # and line.order_id.approver_id.id == uid
    #             True if line.product_id and line.product_uom_qty > 0 else False
    #         )

    # @api.depends('order_id.approver_id')
    def _compute_can_edit_threshold_remarks(self):
        is_admin = self.env.user.has_group('base.group_system')
        for line in self:
            line.can_edit_threshold_remarks = is_admin

    # @api.constrains('price_unit', 'threshold_price')
    # def _check_threshold_price(self):
    #     for line in self:
    #         if (
    #                 line.price_unit
    #                 and line.threshold_price
    #                 and line.price_unit < line.threshold_price
    #         ):
    #             raise UserError(
    #                 _("Unit Price for %s cannot be less than Threshold Price")
    #                 % line.product_id.display_name
    #             )

    @api.depends('price_unit', 'discount')
    def _compute_net_unit_price(self):
        print("_compute_net_unit_price")
        for line in self:
            line.net_unit_price = line.price_unit * (1 - (line.discount or 0.0) / 100.0)
            print(f"net unit price {line.net_unit_price}")

        self._compute_threshold_price()
        self._compute_below_threshold_price()


    # # @api.depends('order_id.pricelist_id', 'product_template_id')
    # @api.depends('product_template_id')
    # def _compute_threshold_price_old(self):
    #     print("_compute_threshold_price")
    #     for line in self:
    #         price = 0.0
    #         # pricelist = line.order_id.pricelist_id
    #
    #         # if pricelist and line.product_id:
    #         if line.product_template_id:
    #             # rule = pricelist.item_ids.filtered(
    #             #     lambda r: (
    #             #         (r.product_tmpl_id and r.product_tmpl_id == line.product_template_id) #or
    #             #         # (r.categ_id and r.categ_id == line.product_id.categ_id) or
    #             #         # (not r.product_id and not r.categ_id)
    #             #     )
    #             # )[:1]
    #
    #             price = line.product_template_id.list_price if line.product_template_id else 0.0
    #
    #         line.threshold_price = price
    #         print(line.threshold_price)
    #         print(line.product_id.name)

    @api.depends('order_id.pricelist_id', 'product_template_id', 'product_uom_qty')
    def _compute_threshold_price(self):
        print("_compute_threshold_price")
        for line in self:
            rule = line.pricelist_item_id
            price = rule.threshold_price if rule else 0.0

            line.threshold_price = price
            print(line.threshold_price)
            print(line.product_id.name)

    @api.depends('net_unit_price', 'threshold_price')
    def _compute_below_threshold_price(self):
        print("_compute_below_threshold_price")
        for line in self:
            if line.threshold_price:
                line.below_threshold_price = line.net_unit_price < line.threshold_price
            else:
                line.below_threshold_price = False
            print(line)
            print(f"threshold {line.below_threshold_price}")

    @api.depends('product_type', 'product_uom_qty', 'qty_delivered', 'state', 'move_ids', 'product_uom')
    def _compute_qty_to_deliver(self):
        super()._compute_qty_to_deliver()
        print("_compute_qty_to_deliver")
        is_driver = self.env.user.has_group('delivery_app_artx.group_driver')

        if is_driver:
            for line in self:
                line.display_qty_widget = False

    def action_confirm_orders_from_threshold_tree(self):
        orders = self.mapped('order_id').filtered(
            lambda order: order.state in ('draft', 'sent')
        )

        if not orders:
            return True

        return orders.action_confirm()