from . import sale_order
from . import sale_order_line_inherit
from . import pricelist_item
from . import ir_actions_report