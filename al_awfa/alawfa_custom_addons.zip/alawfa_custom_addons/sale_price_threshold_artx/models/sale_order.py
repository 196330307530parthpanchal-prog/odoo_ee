from odoo import models, fields, api, _
from datetime import datetime, timedelta, date
from dateutil.relativedelta import relativedelta
from odoo.exceptions import ValidationError  # <- import this
from odoo.exceptions import UserError

class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def action_confirm(self):
        self._check_threshold_remarks()
        res = super().action_confirm()
        return res

    has_below_threshold_line = fields.Boolean(
        string="Has Below Threshold Price",
        compute="_compute_has_below_threshold_line",
        store=True
    )

    @api.depends('order_line.below_threshold_price')
    def _compute_has_below_threshold_line(self):
        for order in self:
            order.has_below_threshold_line = any(
                line.below_threshold_price for line in order.order_line
            )
    def _check_threshold_remarks(self):
        for order in self:
            for line in order.order_line:
                print(line.below_threshold_price,line.threshold_remarks)
                if line.below_threshold_price and not line.threshold_remarks:
                # if line.below_threshold_price:
                    raise UserError(_(
                        "Approval remarks are mandatory for products priced below threshold.\n\n"
                        f"Product: {line.order_id.name} {line.product_id.display_name}"
                    ))
                    # raise UserError(_(
                    #     "Products priced below threshold.\n\n"
                    #     f"Product: {line.product_id.display_name}"
                    # ))

    def action_quotation_send(self):
        self._check_threshold_remarks()
        return super().action_quotation_send()

    # doesnt work, look for ir.actions.report
    # def print_quotation(self):
    #     self._check_threshold_remarks()
    #     return super().print_quotation()

    # def action_confirm(self):
    #     self._check_threshold_remarks()
    #     return super().action_confirm()



