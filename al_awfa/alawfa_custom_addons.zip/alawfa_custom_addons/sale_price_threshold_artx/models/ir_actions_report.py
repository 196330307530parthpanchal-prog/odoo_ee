from odoo import models, fields, api, _

class IrActionsReport(models.Model):
    _inherit = 'ir.actions.report'

    def _render_qweb_pdf(self, report_ref, docids, data=None):
        # self = ir.actions.report record
        # report_ref = xml id or report name
        # docids = list of record ids
        # print("Manav")
        # print(self.model)
        # print(docids)
        # print(report_ref)
        report_sudo = self._get_report(report_ref)
        # print(report_sudo)
        if report_sudo.model == 'sale.order' and docids:
            orders = self.env['sale.order'].browse(docids)
            # print(orders)
            for order in orders:
                # print(order)
                order._check_threshold_remarks()

        return super()._render_qweb_pdf(report_ref, docids, data=data)