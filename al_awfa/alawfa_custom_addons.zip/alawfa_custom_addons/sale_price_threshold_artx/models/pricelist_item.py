from odoo import models, fields

class ProductPricelistItem(models.Model):
    _inherit = 'product.pricelist.item'

    threshold_price = fields.Float(
        string="Threshold Price",
        help="Minimum allowed selling unit price for this rule.",
        digits="Product Price"
    )
