# alawfa_custom_addons
this is Alwafa odoo17 custom addons repository
