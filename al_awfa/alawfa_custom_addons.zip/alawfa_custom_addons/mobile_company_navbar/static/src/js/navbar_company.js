///** @odoo-module **/
//
//import { patch } from "@web/core/utils/patch";
//import { Navbar } from "@web/webclient/navbar/navbar";
//import { useService } from "@web/core/utils/hooks";
//
//patch(Navbar.prototype, {
//    setup() {
//        super.setup();
//        this.companyService = useService("company");
//    },
//
//    get currentCompanyName() {
//        return this.companyService.currentCompany?.name || "";
//    },
//});

/** @odoo-module **/


//import { registry } from "@web/core/registry";
//
//const navbarPatch = {
//    start(env) {
//        setTimeout(() => {
//            try {
//                const navbar = document.querySelector(".o_main_navbar");
//                if (!navbar) return;
//
//                // avoid duplicate
//                if (navbar.querySelector(".o_mobile_company_name")) return;
//
//                const companyName = env.services.company?.currentCompany?.name || "";
//
//                const el = document.createElement("div");
//                el.className = "o_mobile_company_name d-md-none";
//                el.innerText = companyName;
//
//                navbar.appendChild(el);
//            } catch (e) {
//                console.error("Company Navbar Error:", e);
//            }
//        }, 1000); // wait for navbar render
//    },
//};
//
//registry.category("services").add("mobile_company_navbar", navbarPatch);

/** @odoo-module **/

import { registry } from "@web/core/registry";

const navbarPatch = {
    start(env) {
        setTimeout(() => {
            try {
                const systray = document.querySelector(".o_menu_systray");
                if (!systray) return;

                // prevent duplicate
                if (systray.querySelector(".o_mobile_company_name")) return;

                const companyName = env.services.company?.currentCompany?.name || "";

                const el = document.createElement("div");
                el.className = "o_mobile_company_name d-md-none";
                el.innerText = companyName;

                // ✅ append INSIDE systray (not navbar)
                systray.appendChild(el);

            } catch (e) {
                console.error("Company Navbar Error:", e);
            }
        }, 500);
    },
};

registry.category("services").add("mobile_company_navbar", navbarPatch);