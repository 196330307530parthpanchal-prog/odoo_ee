///** @odoo-module */
//
//import { patch } from "@web/core/utils/patch";
//import { _t } from "@web/core/l10n/translation";
//import { RELATIVE_DATE_RANGE_TYPES } from "@spreadsheet/helpers/constants";
//import { DateTime } from "luxon";
//
//// ✅ STEP 1: Add Custom Option in dropdown
//if (!RELATIVE_DATE_RANGE_TYPES.find(r => r.type === "custom")) {
//    RELATIVE_DATE_RANGE_TYPES.push({
//        type: "custom",
//        description: _t("Custom Range"),
//    });
//}
//
//
//// ✅ STEP 2: Patch Global Filter Component
//import { GlobalFilterComponent } from "@spreadsheet/global_filters/components/helper";
//
//patch(GlobalFilterComponent.prototype, "custom_date_range_patch", {
//
//    async onValueChange(value) {
//        // 👇 intercept custom selection
//        if (value === "custom") {
//
//            // simple prompt (replace with dialog if needed)
//            const from = prompt("Enter Start Date (YYYY-MM-DD)");
//            const to = prompt("Enter End Date (YYYY-MM-DD)");
//
//            if (!from || !to) {
//                return;
//            }

//            // ✅ STEP 3: convert to from_to filter
//            this.props.updateFilter({
//                ...this.props.filter,
//                rangeType: "from_to",
//                value: {
//                    from: from,
//                    to: to,
//                },
//            });
//
//            return;
//        }
//
//        // fallback to normal behavior
//        return this._super(value);
//    },
//});

/** @odoo-module */

import { patch } from "@web/core/utils/patch";
import { DateFilterValue } from "@spreadsheet/global_filters/components/filter_date_value/filter_date_value";

patch(DateFilterValue.prototype, "custom_date_range_patch", {

    setup() {
        this._super();
    },

    onValueChange(value) {
        // 🚀 intercept custom selection
        if (value === "custom") {

            const from = prompt("Enter Start Date (YYYY-MM-DD)");
            const to = prompt("Enter End Date (YYYY-MM-DD)");

            if (!from || !to) {
                return;
            }

            // Switch to from_to mode
            this.props.updateFilter({
                ...this.props.filter,
                rangeType: "from_to",
                value: {
                    from: null,
                    to: null,
                },
            });

            return;
        }

        return this._super(value);
    },
});