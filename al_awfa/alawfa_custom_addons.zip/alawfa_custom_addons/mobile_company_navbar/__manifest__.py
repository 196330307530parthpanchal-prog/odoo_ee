{
    "name": "Mobile Company Navbar",
    "version": "1.0",
    "summary": "Show current company name in navbar for mobile view",
    "category": "Web",
    "depends": ["web","spreadsheet"],
    "assets": {
        "web.assets_backend": [
            "mobile_company_navbar/static/src/js/navbar_company.js",
            # "mobile_company_navbar/static/src/js/custom_filter_patch.js",
            "mobile_company_navbar/static/src/css/navbar_company.css",
        ],
        # "spreadsheet.assets": [
        #     "spreadsheet_custom_range/static/src/js/custom_filter_patch.js",
        # ],
    },
    "installable": True,
    "application": False,
}