/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState, onWillStart, onMounted, useRef } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

const configModel = 'general.ledger.report.config';

export class GeneralLedgerReport extends Component {
    setup() {
        this.state = useState({
            ledgerData: [],
            groupedData: {},
            dateFrom: "",
            dateTo: "",
            selectedAccount: "",
            selectedYear: new Date().getFullYear(),
            availableYears: Array.from(
                { length: 100 },
                (_, i) => new Date().getFullYear() - i
            ),
            accounts: [],
            totals: {
                debit: 0,
                credit: 0,
                balance: 0
            },
            collapsedAccounts: {},
            visibleLinesCount: {},
            fyDates: null,
            isDebug: Boolean(odoo.debug),
            companyCurrency: { id: false, name: '', symbol: '' },
            searchAccountIds: null, // ids of the accounts matched by the search box (null = no search)
            sortDirection: 'asc', // added for date sorting     
            config: {
                show_journal: true,
                show_date: true,
                show_communication: true,
                show_partner: true,
                show_currency: true,
                show_debit: true,
                show_credit: true,
                show_balance: true,
            },
        });

        this.ui = useService("ui");
        this.orm = useService("orm");
        // P&L Account Navigation Context
        const ctx = this.props.action?.context || {};

        this.plAccountId =
            ctx.profit_loss_account_id || false;

        this.plDateFrom =
            ctx.profit_loss_date_from || false;

        this.plDateTo =
            ctx.profit_loss_date_to || false;

        this.dateFromRef = useRef("date-from");
        this.dateToRef = useRef("date-to");
        this.accountRef = useRef("account-filter");
        this.searchInput = useRef("search-input");

        onWillStart(async () => {
            await this.loadCompanyCurrency();
            await this.loadConfig();
            await this.loadAccounts();
            await this.initializeFinancialYearDates();
        
            if (this.plAccountId) {

                this.state.selectedAccount =
                    String(this.plAccountId);
            
            }
            
            if (this.plDateFrom) {
            
                this.state.dateFrom =
                    this.plDateFrom;
            
            }
            
            if (this.plDateTo) {
            
                this.state.dateTo =
                    this.plDateTo;
            
            }

            if (this.plDateFrom || this.plDateTo) {
                this.state.dateType = 'Custom';
            }
        
            await this.loadLedgerData();
        });

        onMounted(() => {
            // Set date picker values after DOM is ready
            if (this.state.fyDates) {
                if (this.dateFromRef.el) {
                    this.dateFromRef.el.value = this.state.fyDates.start;
                }
                if (this.dateToRef.el) {
                    this.dateToRef.el.value = this.state.fyDates.end;
                }
            }
            // When page loads again, restores to which accounts were open/closed
            // Rows stay open only when coming back from a drill-down (journal entry /
            // ledger); opening the report any other way always starts collapsed.
            const restoreUntil = parseInt(localStorage.getItem("general_ledger_restore_until") || "0");
            localStorage.removeItem("general_ledger_restore_until");
            const shouldRestore = restoreUntil > Date.now();

            const savedCollapsed = shouldRestore
                ? localStorage.getItem("general_ledger_collapsed_accounts")
                : null;

            if (savedCollapsed) {
                this.state.collapsedAccounts =
                    JSON.parse(savedCollapsed);
            }

            const savedScroll = shouldRestore
                ? localStorage.getItem("general_ledger_scroll")
                : null;

            if (savedScroll) {
                setTimeout(() => {
                    requestAnimationFrame(() => {

                        const content =
                            document.querySelector('.o_content');
                        if (content) {
                        
                        content.scrollTop =
                                parseInt(savedScroll);
                        }
            
                    });
            
                }, 500);
            }
                    });
                
                    this.action = useService("action");

                    
                }

    sortByDate() {

        // Toggle asc/desc
        this.state.sortDirection =
            this.state.sortDirection === 'asc'
                ? 'desc'
                : 'asc';
    
        // Sort ledger data
        this.state.ledgerData.sort((a, b) => {
    
            const dateA = new Date(a.date);
            const dateB = new Date(b.date);
    
            if (this.state.sortDirection === 'asc') {
                return dateA - dateB;
            } else {
                return dateB - dateA;
            }
        });
    
        // Re-group data after sorting
        this.groupDataByAccount();
    }

    goToHome() {
        // Like a website's home button: forget the saved open/closed rows and the
        // scroll position, then reload so filters, dates and search start fresh.
        localStorage.removeItem("general_ledger_collapsed_accounts");
        localStorage.removeItem("general_ledger_scroll");
        localStorage.removeItem("general_ledger_restore_until");
        window.location.reload();
    }

    reloadPage() {
        window.location.reload();
    }

    async loadConfig() {
        if (!this.state.isDebug) {
            return;
        }
        try {
            const configRecord = await this.orm.call(
                configModel,
                'get_active_config',
                []
            );

            // Assuming configRecord contains fields like show_journal, etc.
            if (configRecord) {
                this.state.config = {
                    show_journal: configRecord.show_journal,
                    show_date: configRecord.show_date,
                    show_communication: configRecord.show_communication,
                    show_partner: configRecord.show_partner,
                    show_currency: configRecord.show_currency,
                    show_debit: configRecord.show_debit,
                    show_credit: configRecord.show_credit,
                    show_balance: configRecord.show_balance,
                };
                await this.loadLedgerData();
            }
        } catch (error) {
            console.error("Failed to load General Ledger Configuration:", error);
            // Default config is used
        }
    }

    openDebugConfig = async function () {
        try {
            // 1. Call the Python method to get the active (and initialized) config record.
            const configRecord = await this.orm.call(
                configModel,
                'get_active_config',
                [] // No arguments for the @api.model method
            );

            // The ORM call returns the ID of the record.
            const configId = configRecord.id;

            // 2. Open the form view for the retrieved record ID.
            await this.action.doAction({
                type: "ir.actions.act_window",
                res_model: configModel,
                res_id: configId, // Pass the specific record ID
                view_mode: "form",
                target: "new",
                views: [[false, "form"]],
                name: "General Ledger Configuration",
                onClose: async () => {
                    console.log("CONFIG CLOSED");
                    await this.loadConfig();
                    window.location.reload();
                },
            });

        

        } catch (error) {
            console.error("Failed to retrieve or initialize General Ledger Configuration:", error);
            // Optionally show a user-facing notification about the error
            this.env.services.notification.add(
                "Could not load the General Ledger Configuration.",
                { type: 'danger' }
            );
        }
    }

    

    async loadAccounts() {
        this.state.accounts = await this.orm.searchRead(
            "account.account",
            [['deprecated', '=', false]],
            ["name", "code"]
        );
    }

    async initializeFinancialYearDates() {
        if (!this.state.dateFrom || !this.state.dateTo) {
            // Fetch current company's country
            const company = await this.orm.call("res.company", "get_current_company_country", []);
            const fyRange = this.getFinancialYearRange(company.country_code);

            this.state.dateFrom = fyRange.start;
            this.state.dateTo = fyRange.end;
            this.state.fyDates = fyRange; // Store for later use in onMounted
        }
    }

    async loadLedgerData() {
        let domain = [
            ['move_id.state', '=', 'posted'],
            // ['account_id.deprecated', '=', false]
        ];

        // Add date filters
        if (this.state.dateFrom) {
            domain.push(['date', '>=', this.state.dateFrom]);
        }
        if (this.state.dateTo) {
            domain.push(['date', '<=', this.state.dateTo]);
        }
        if (this.state.selectedAccount) {
            domain.push(['account_id', '=', parseInt(this.state.selectedAccount)]);
        }

        if (this.state.searchAccountIds) {
            domain.push(['account_id', 'in', this.state.searchAccountIds]);
        }

        const lines = await this.orm.searchRead(
            "account.move.line",
            domain,
            ["move_name", "move_id", "date", "name", "partner_id", "account_id","amount_currency" ,"currency_id", "debit", "credit", "balance"],
            {
                order: "date asc, move_name asc, id asc"
            }
        );

        this.state.ledgerData = await this.addCurrencySymbols(lines);
        await this.addInitialBalances();
        this.state.visibleLinesCount = {};
        this.groupDataByAccount();
        this.calculateTotals();

        // Force open account when arriving from P&L
        if (this.plAccountId) {
        
            const accountId = parseInt(this.plAccountId);
        
            this.state.collapsedAccounts[accountId] = false;
        
            localStorage.setItem(
                "general_ledger_collapsed_accounts",
                JSON.stringify(this.state.collapsedAccounts)
            );
        }
    }

    async addInitialBalances() {
        // Use dateFrom from state or from the date input field
        const dateFrom = this.state.dateFrom || this.dateFromRef.el?.value;
        if (!dateFrom) return;

        // Get account IDs based on current filter
        let accountIds;
        if (this.state.selectedAccount || this.accountRef.el?.value) {
            // If specific account is selected, only get initial balance for that account
            const selectedAccountId = parseInt(this.state.selectedAccount || this.accountRef.el?.value);
            accountIds = [selectedAccountId];
        } else {
            // Get all account IDs
            accountIds = this.state.accounts.map(a => a.id);
        }

        if (this.state.searchAccountIds) {
            accountIds = accountIds.filter(id => this.state.searchAccountIds.includes(id));
        }

        if (!accountIds.length) return;

        // Fetch sum of debit/credit/balance before dateFrom
        const initialLines = await this.orm.searchRead(
            "account.move.line",
            [
                ['move_id.state', '=', 'posted'],
                ['account_id', 'in', accountIds],
                ['date', '<', dateFrom],
                // ['account_id.active', '=', false]
            ],
            ["account_id", "debit", "credit", "balance", "currency_id"]
        );

        // Compute remaining/opening balance per account
        const openingBalances = {};

        initialLines.forEach(line => {
            const accId = line.account_id[0];
            if (!openingBalances[accId]) {
                openingBalances[accId] = { debit: 0, credit: 0, balance: 0, currency_id: line.currency_id };
            }
            openingBalances[accId].debit += line.debit;
            openingBalances[accId].credit += line.credit;
            openingBalances[accId].balance += line.balance;
        });
        console.log("Opening Accounts:", Object.keys(openingBalances));

        // Add "Initial Balance" line to ledgerData
        this.state.ledgerData = [
            ...Object.keys(openingBalances).map(accId => {
                const ob = openingBalances[accId];
                return {
                    move_name: "Initial Balance",
                    move_id: [null, "Initial Balance"],
                    date: dateFrom,
                    name: "",
                    partner_id: null,
                    account_id: [parseInt(accId), this.state.accounts.find(a => a.id === parseInt(accId)).name],
                    currency_id: openingBalances[accId].currency_id,
                    debit: ob.debit,
                    credit: ob.credit,
                    balance: ob.balance,
                    currency_symbol: this.state.companyCurrency.symbol // Will be overridden in addCurrencySymbols
                };
            }),
            ...this.state.ledgerData
        ];

        // Re-add symbols
        this.state.ledgerData = await this.addCurrencySymbols(this.state.ledgerData);
    }

    getFinancialYearRange(countryCode, startYear = null) {
        // First month of the financial year:
        // April for IN / JP / CAD, July for AU / NZD / PKR, otherwise January.
        let startMonth = 0;
        switch (countryCode) {
            case 'IN':
            case 'JP':
            case 'CAD':
                startMonth = 3;
                break;
            case 'AU':
            case 'NZD':
            case 'PKR':
                startMonth = 6;
                break;
        }

        const today = new Date();
        if (startYear === null) {
            // current financial year
            startYear = today.getMonth() >= startMonth
                ? today.getFullYear()
                : today.getFullYear() - 1;
        }

        const start = new Date(startYear, startMonth, 1);
        const end = new Date(startYear + 1, startMonth, 0); // day before the next year starts

        // Build YYYY-MM-DD from the local date parts. toISOString() converts to UTC
        // and moves the date back one day in time zones ahead of UTC (Qatar, India).
        const pad = (n) => String(n).padStart(2, "0");
        const formatDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
        return { start: formatDate(start), end: formatDate(end) };
    }

    toggleAccount(accountId) {

        this.state.collapsedAccounts[accountId] =
            !this.state.collapsedAccounts[accountId];
    }

    groupDataByAccount() {
        this.state.groupedData = {};
        // this.state.collapsedAccounts = {};

        this.state.ledgerData.forEach(line => {
            if (line.debit === 0 && line.credit === 0 && line.balance === 0) {
                return; // skip
            }
            const accountKey = line.account_id[0];
            const accountName = line.account_id[1];

            if (!this.state.groupedData[accountKey]) {
                this.state.groupedData[accountKey] = {
                    accountName: accountName,
                    lines: [],
                    totals: { debit: 0, credit: 0, balance: 0, runningBalance: 0 }
                };
                // this.state.collapsedAccounts[accountKey] = true;
                if (!(accountKey in this.state.collapsedAccounts)) {
                    this.state.collapsedAccounts[accountKey] = true;
                }
                if (!(accountKey in this.state.visibleLinesCount)) {
                    this.state.visibleLinesCount[accountKey] = 100;
                }
            }

            
            this.state.groupedData[accountKey].totals.debit += line.debit;  // debit total  
            this.state.groupedData[accountKey].totals.credit += line.credit;  // credit total
            this.state.groupedData[accountKey].totals.runningBalance += (line.debit - line.credit);  
            line.balance = this.state.groupedData[accountKey].totals.runningBalance;
            this.state.groupedData[accountKey].lines.push(line);
            this.state.groupedData[accountKey].totals.balance = 
                this.state.groupedData[accountKey].totals.debit - this.state.groupedData[accountKey].totals.credit;
        });
    }

    // Load more method 
    loadMore(accountId) {
        this.state.visibleLinesCount[accountId] =
            this.state.visibleLinesCount[accountId] + 100;
    }


    calculateTotals() {
        this.state.totals = { debit: 0, credit: 0, balance: 0 };

        this.state.ledgerData.forEach(line => {
            this.state.totals.debit += line.debit;
            this.state.totals.credit += line.credit;
        });
        this.state.totals.balance = this.state.totals.debit - this.state.totals.credit;   // Final balance 
    }

    async addCurrencySymbols(lines) {
        // Fetch all unique currency IDs from the lines
        const currencyIds = [...new Set(lines.map(line => line.currency_id ? line.currency_id[0] : false).filter(Boolean))];
        if (!currencyIds.length) return lines;

        const currencies = await this.orm.searchRead(
            "res.currency",
            [['id', 'in', currencyIds]],
            ["name", "symbol"]
        );

        const currencyMap = {};
        currencies.forEach(c => {
            currencyMap[c.id] = c.symbol;
        });

        // Add symbol to each line
        lines.forEach(line => {
            if (line.currency_id && line.currency_id[0]) {
                line.currency_symbol = currencyMap[line.currency_id[0]] || line.currency_id[1];
            } else {
                line.currency_symbol = this.state.companyCurrency.symbol; // default
            }
        });

        return lines;
    }

    onSearchKeydown(ev) {
        if (ev.key === "Enter") {
            this.searchJournal();
        }
    }

    async searchJournal() {
        // The search looks only at the account rows (code + name), never at the
        // lines inside them. Every word typed must appear in the code or the name.
        const text = this.searchInput.el.value.trim();

        if (!text) {
            this.state.searchAccountIds = null;
        } else {
            const domain = [];
            for (const word of text.split(/\s+/)) {
                domain.push('|', ['name', 'ilike', word], ['code', 'ilike', word]);
            }
            const accounts = await this.orm.searchRead("account.account", domain, ["id"]);
            this.state.searchAccountIds = accounts.map(account => account.id);
        }

        await this.loadLedgerData();
    }

    selectDateType(type) {
        this.state.dateType = type;
        // Reset previous selections
        this.state.selectedMonth = null;
        this.state.selectedQuarter = null;
        this.state.selectedYear = null;
        if (type === 'Custom') {
            this.state.dateFrom = this.dateFromRef.el?.value || '';
            this.state.dateTo = this.dateToRef.el?.value || '';
        }

        if (type === 'Year') {
            // open on the current financial year straight away (e.g. 2026)
            const current = this.getFinancialYearRange(this.state.companyCurrency.country_code);
            this.selectFinancialYear(parseInt(current.start.slice(0, 4), 10));
        }
    }

    selectMonth(month) {
        this.state.selectedMonth = month;
        if (!this.state.selectedYear) {
            this.state.selectedYear = new Date().getFullYear();
        }
        // set dateFrom/dateTo accordingly
        const monthIndex = ['January','February','March','April','May','June','July','August','September','October','November','December'].indexOf(month);
        const year = this.state.selectedYear;
        this.state.dateFrom = `${year}-${String(monthIndex+1)   .padStart(2,'0')}-01`;
        this.state.dateTo = `${year}-${String(monthIndex+1).padStart(2,'0')}-${new Date(year, monthIndex+1, 0).getDate()}`;
        this.loadLedgerData();
    }

    onYearSelect(year) {
        this.state.selectedYear = year;
    
        if (this.state.dateType === 'Month' && this.state.selectedMonth) {
            this.selectMonth(this.state.selectedMonth);
        }
    
        if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
            this.selectQuarter(this.state.selectedQuarter);
        }
    
        if (this.state.dateType === 'Year') {
            this.onYearChange({
                target: { value: year }
            });
        }
    }

    selectQuarter(quarter) {
        this.state.selectedQuarter = quarter;
        if (!this.state.selectedYear) {
            this.state.selectedYear = new Date().getFullYear();
        }
        const year = this.state.selectedYear || new Date().getFullYear();
        switch(quarter) {
            case 'Q1': this.state.dateFrom=`${year}-01-01`; this.state.dateTo=`${year}-03-31`; break;
            case 'Q2': this.state.dateFrom=`${year}-04-01`; this.state.dateTo=`${year}-06-30`; break;
            case 'Q3': this.state.dateFrom=`${year}-07-01`; this.state.dateTo=`${year}-09-30`; break;
            case 'Q4': this.state.dateFrom=`${year}-10-01`; this.state.dateTo=`${year}-12-31`; break;
        }
        this.loadLedgerData();
    }

    onYearChange(ev) {
        const year = parseInt(ev.target.value);
        if (!isNaN(year)) {
            const range = this.getFinancialYearRange(
                this.state.companyCurrency.country_code,
                year
            );
            this.state.dateFrom = range.start;
            this.state.dateTo = range.end;
            this.loadLedgerData();
        }
    }

    selectFinancialYear(year) {
        this.state.selectedYear = year;
        this.onYearChange({
            target: { value: year }
        });
    }

    onCustomDateFromChange(ev) {
        const fromDate = ev.target.value;
        this.state.dateFrom = fromDate;

        // Restrict 'To' date
        if (this.dateToRef.el) {
            this.dateToRef.el.min = fromDate;

            // Optional: if current 'To' date is before 'From', reset it
            if (this.dateToRef.el.value && this.dateToRef.el.value < fromDate) {
                this.dateToRef.el.value = fromDate;
                this.state.dateTo = fromDate;
            }
        }
    }

    async applyFilters() {
        const domain = [
            ['move_id.state', '=', 'posted'],
            // ['account_id.active', '=', false]
        ];

        // Only add filters if values are provided
        const dateFrom = this.dateFromRef.el?.value;
        const dateTo = this.dateToRef.el?.value;
        const selectedAccount = this.accountRef.el?.value;

        if (dateFrom) {
            domain.push(['date', '>=', dateFrom]);
        }
        if (dateTo) {
            domain.push(['date', '<=', dateTo]);
        }
        if (selectedAccount) {
            domain.push(['account_id', '=', parseInt(selectedAccount)]);
        }
        if (this.state.searchAccountIds) {
            domain.push(['account_id', 'in', this.state.searchAccountIds]);
        }

        const lines = await this.orm.searchRead(
            "account.move.line",
            domain,
            ["move_name", "move_id", "date", "name", "partner_id", "account_id","amount_currency" ,"currency_id", "debit", "credit", "balance"],
            {
                order: "date asc, move_name asc, id asc"
            }
        
        );

        this.state.ledgerData = await this.addCurrencySymbols(lines);

        // Update state with current filter values for initial balance calculation
        this.state.dateFrom = dateFrom;
        this.state.dateTo = dateTo;
        this.state.selectedAccount = selectedAccount;

        // Add initial balances based on the filtered date range
        await this.addInitialBalances();
        this.groupDataByAccount();
        this.calculateTotals();
    }

    getActiveDateRangeLabel() {
        // Month
        if (this.state.dateType === "Month" && this.state.selectedMonth) {
            return `Month: ${this.state.selectedMonth}`;
        }

        // Quarter with month range
        if (this.state.dateType === "Quarter" && this.state.selectedQuarter) {
            const quarterMap = {
                Q1: "Jan-Mar",
                Q2: "Apr-Jun",
                Q3: "Jul-Sep",
                Q4: "Oct-Dec",
            };
            return `Quarter: ${this.state.selectedQuarter} (${quarterMap[this.state.selectedQuarter] || ""})`;
        }

        // Year
        if (this.state.dateType === "Year" && this.state.dateFrom && this.state.dateTo) {
            const year = String(this.state.dateFrom).slice(0, 4);
            return `Year: ${year}`;
        }

        // Custom date range
        if (this.state.dateType === "Custom" && this.state.dateFrom && this.state.dateTo) {
            // "YYYY-MM-DD" is split, not parsed with Date(), which moves the day
            // back by one in browsers whose time zone is behind UTC.
            const formatDate = (d) => {
                const [year, month, day] = String(d).slice(0, 10).split("-");
                return `${day}-${month}-${year}`;
            };
            return `Custom: ${formatDate(this.state.dateFrom)} → ${formatDate(this.state.dateTo)}`;
        }

        // Financial year
        if (this.state.fyDates) {
            // "YYYY-MM-DD" is split, not parsed with Date(), which moves the day
            // back by one in browsers whose time zone is behind UTC.
            const formatDate = (d) => {
                const [year, month, day] = String(d).slice(0, 10).split("-");
                return `${day}-${month}-${year}`;
            };
            return `Financial Year: ${formatDate(this.state.fyDates.start)} → ${formatDate(this.state.fyDates.end)}`;
        }

        return "All Records";
    }

    async loadCompanyCurrency() {
        // Currency of the active company, so no symbol is hardcoded
        try {
            this.state.companyCurrency = await this.orm.call(
                "res.company",
                "get_company_currency",
                []
            );
        } catch (error) {
            console.error("Failed to load company currency:", error);
        }
    }

    formatCurrency(amount, currencySymbol = this.state.companyCurrency.symbol, currencyName = null) {
        // Determine if it's INR based on symbol or currency name
        const isINR = currencySymbol === '₹' ||
                      (currencyName && currencyName.toUpperCase().includes('INR')) ||
                      (currencyName && currencyName.toUpperCase().includes('RUPEE'));

        const isWhole = Number.isInteger(amount);

        if (isINR) {
            // Indian format: ₹ 1,05,000 (lakhs and crores system)
            let x = amount.toFixed(isWhole ? 0 : 2).split('.');
            let intPart = x[0];
            let decPart = x.length > 1 && x[1] !== '00' ? '.' + x[1] : '';

            // Handle Indian numbering system
            if (intPart.length > 3) {
                // Take last 3 digits
                let lastThree = intPart.substring(intPart.length - 3);
                let otherNumbers = intPart.substring(0, intPart.length - 3);

                // Apply Indian grouping (every 2 digits after first 3)
                if (otherNumbers !== '') {
                    otherNumbers = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
                    lastThree = ',' + lastThree;
                }

                intPart = otherNumbers + lastThree;
            }

            return currencySymbol + ' ' + intPart + decPart;
        } else {
            // International format: $ 105,000 (thousands system)
            let options = {
                minimumFractionDigits: isWhole ? 0 : 2,
                maximumFractionDigits: isWhole ? 0 : 2,
            };
            return currencySymbol + ' ' + amount.toLocaleString('en-US', options);
        }
    }

    viewJournalEntry(moveId) {
        if (!moveId) {
            return;
        }
            const action = {
                type: "ir.actions.act_window",
                res_model: "account.move",
                res_id: moveId,
                views: [[false, "form"]],
                target: "current", // opens in same window
            };
            // SAVES which accounts are open and position of scroll  
            localStorage.setItem(
                "general_ledger_collapsed_accounts",
                JSON.stringify(this.state.collapsedAccounts)
            );
            
            localStorage.setItem(
                "general_ledger_scroll",
                document.querySelector('.o_content')?.scrollTop || 0
            );
            // come back from the entry with the same rows open (valid for 30 min)
            localStorage.setItem("general_ledger_restore_until", String(Date.now() + 30 * 60 * 1000));
            this.env.services.action.doAction(action);
    }

    getAmountClass(amount) {
        if (amount < 0) return 'text-danger';
        return '';
    }

    formatToDDMMYYYY(dateStr) {
        if (!dateStr) return "";
        if (/^\d{4}-\d{2}-\d{2}/.test(String(dateStr))) {
            // split instead of Date(): no day shift in time zones behind UTC
            const [year, month, day] = String(dateStr).slice(0, 10).split("-");
            return `${day}/${month}/${year}`;
        }
        const date = new Date(dateStr);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
    }

    formatDate(dateStr) {
        return this.formatToDDMMYYYY(dateStr);
    }

    getFilterTitle() {
        const textSearch = this.searchInput && this.searchInput.el ? this.searchInput.el.value.trim() : null;

        if (textSearch) {
            return `${textSearch}`;
        }

        return "All Records";
    }

    // Export to PDF
    async exportToPDF() {
        this.ui.block();
        try {
            const searchText = this.searchInput.el.value.trim();
            const dateFrom = this.state.dateFrom;
            const dateTo = this.state.dateTo;
            let month = null;
            let quarter = null;
            let year = null;

            if (this.state.dateType === 'Month' && this.state.selectedMonth) {
                // Convert Month name ('October') to month index (10)
                const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                month = monthNames.indexOf(this.state.selectedMonth) + 1; // 1-indexed month
                year = parseInt(String(dateFrom).slice(0, 4), 10); // Get year from the calculated date range

            } else if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
                // Pass the quarter label (Q1, Q2, etc.)
                quarter = this.state.selectedQuarter;
                year = parseInt(String(dateFrom).slice(0, 4), 10);

            } else if ((this.state.dateType === 'Year' || !this.state.dateType) && dateFrom) {
                // This covers 'Year' selection and the default Financial Year initialization
                year = parseInt(String(dateFrom).slice(0, 4), 10);
            }

            // Prepare data for PDF export
            const exportData = {
                date_from: dateFrom,
                date_to: dateTo,
                month: month,
                quarter: quarter,
                year: year,
                filter_title: this.getFilterTitle(),
                ledger_data: this.state.ledgerData,
                grouped_data: this.state.groupedData,
                collapsed_accounts: this.state.collapsedAccounts,
                totals: this.state.totals,
                company_info: await this.orm.call("res.company", "get_current_company_info", []),
                search_text: searchText,
            };

            // Call the PDF export method
            const result = await this.orm.call(
                "general.ledger.export",
                "export_general_ledger_pdf",
                [exportData]
            );

            if (result) {
                // Download the PDF
                await this.action.doAction(result);
            } else {
                throw new Error("PDF export failed: Server response did not contain a download URL. Result: " + JSON.stringify(result));
            }
        } catch (error) {
            console.error("Error exporting PDF:", error);
            throw error;
        } finally {
            this.ui.unblock();
        }
    }

    // Export to XLSX
    async exportToXLSX() {
        this.ui.block();
        try {
            const dateFrom = this.state.dateFrom;
            const dateTo = this.state.dateTo;
            let month = null;
            let quarter = null;
            let year = null;

            if (this.state.dateType === 'Month' && this.state.selectedMonth) {
                // Convert Month name ('October') to month index (10)
                const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                month = monthNames.indexOf(this.state.selectedMonth) + 1; // 1-indexed month
                year = parseInt(String(dateFrom).slice(0, 4), 10); // Get year from the calculated date range

            } else if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
                // Pass the quarter label (Q1, Q2, etc.)
                quarter = this.state.selectedQuarter;
                year = parseInt(String(dateFrom).slice(0, 4), 10);

            } else if ((this.state.dateType === 'Year' || !this.state.dateType) && dateFrom) {
                // This covers 'Year' selection and the default Financial Year initialization
                year = parseInt(String(dateFrom).slice(0, 4), 10);
            }

            // Prepare data for XLSX export
            const exportData = {
                date_from: dateFrom,
                date_to: dateTo,
                month: month,
                quarter: quarter,
                year: year,
                filter_title: this.getFilterTitle(),
                ledger_data: this.state.ledgerData,
                grouped_data: this.state.groupedData,
                collapsed_accounts: this.state.collapsedAccounts,
                totals: this.state.totals,
                company_info: await this.orm.call("res.company", "get_current_company_info", [])
            };

            // Call the XLSX export method
            const result = await this.orm.call(
                "general.ledger.export",
                "export_general_ledger_xlsx",
                [exportData]
            );

            if (result && result.url) {
                // Download the XLSX
                window.open(result.url, '_blank');
            } else {
                console.error("XLSX export failed");
            }
        } catch (error) {
            console.error("Error exporting XLSX:", error);
        } finally {
            this.ui.unblock();
        }
    }
}

GeneralLedgerReport.template = "gl_pl_reports_aretx.GeneralLedgerReport";
registry.category("actions").add("gl_pl_reports_aretx.general_ledger_owl", GeneralLedgerReport);