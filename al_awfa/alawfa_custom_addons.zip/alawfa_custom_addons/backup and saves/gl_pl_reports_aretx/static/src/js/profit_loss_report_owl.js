/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState, onWillStart, onMounted, useRef } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

export class ProfitLossReport extends Component {
    setup() {
        this.state = useState({
            financialData: [],
            sections: {},
            periodColumns: [],
            comparisonType: "none",
            comparisonPeriods: 1,
            comparisonDateFrom: "",
            comparisonDateTo: "",
            dateFrom: "",
            dateTo: "",
            selectedAccount: null,
            selectedYear: new Date().getFullYear(),
            availableYears: Array.from(
                { length: 100 },
                (_, i) => new Date().getFullYear() - i
            ),
            accounts: [],
            totals: {},
            lines: [],
            collapsedSections: {
                operating_income: true,
                cost_of_revenue: true,
                other_income: true,
                expenses: true,
                depreciation: true,
            },
            visibleLinesCount: {},
            fyDates: null,
            isDebug: Boolean(odoo.debug),
            companyCurrency: { id: false, name: '', symbol: '' },
            sortDirection: 'asc', // added for date sorting     
        });


        this.ui = useService("ui");
        this.orm = useService("orm");
        this.action = useService("action");
        const ctx = this.props.action?.context || {};
        this.deepLinkDateFrom = ctx.bs_date_from || false;
        this.deepLinkDateTo = ctx.bs_date_to || false;
        this.dateFromRef = useRef("date-from");
        this.dateToRef = useRef("date-to");
        this.accountRef = useRef("account-filter");
        this.searchInput = useRef("search-input");
        
        onWillStart(async () => {
            await this.loadCompanyCurrency();
            await this.loadAccounts();

            if (this.deepLinkDateFrom && this.deepLinkDateTo) {
                this.state.dateFrom = this.deepLinkDateFrom;
                this.state.dateTo = this.deepLinkDateTo;
                this.state.dateType = "Custom";
            } else {
                await this.initializeFinancialYearDates();
            }

            await this.loadProfitLossData();
        });

        onMounted(() => {
            // Set date picker values after DOM is ready
            if (this.state.fyDates) {
                if (this.dateFromRef.el) {
                    this.dateFromRef.el.value = this.state.fyDates.start;
                }
                if (this.dateToRef.el) {
                    this.dateToRef.el.value = this.state.fyDates.end;
                }
            } else if (this.deepLinkDateFrom && this.deepLinkDateTo) {
                if (this.dateFromRef.el) {
                    this.dateFromRef.el.value = this.deepLinkDateFrom;
                }
                if (this.dateToRef.el) {
                    this.dateToRef.el.value = this.deepLinkDateTo;
                }
            }
            // When page loads again, restores to which accounts were open/closed
            // Rows stay open only when coming back from a drill-down (journal entry /
            // ledger); opening the report any other way always starts collapsed.
            const restoreUntil = parseInt(localStorage.getItem("profit_loss_restore_until") || "0");
            localStorage.removeItem("profit_loss_restore_until");
            const shouldRestore = restoreUntil > Date.now();

            const savedCollapsed = shouldRestore
                ? localStorage.getItem("profit_loss_collapsed_sections")
                : null;

            if (savedCollapsed) {
                this.state.collapsedSections =
                    JSON.parse(savedCollapsed);
            }

            const savedScroll = shouldRestore
                ? localStorage.getItem("profit_loss_scroll")
                : null;

            if (savedScroll) {
                setTimeout(() => {
                    requestAnimationFrame(() => {

                        const content =
                            document.querySelector('.o_content');
                        if (content) {
                        
                        content.scrollTop =
                                parseInt(savedScroll);
                        }
            
                    });
            
                }, 500);
            }
                    });
                
                    this.action = useService("action");
                }

    sortByDate() {

        // Toggle asc/desc
        this.state.sortDirection =
            this.state.sortDirection === 'asc'
                ? 'desc'
                : 'asc';
    
        // Sort ledger data
        this.state.financialData.sort((a, b) => {
    
            const dateA = new Date(a.date);
            const dateB = new Date(b.date);
    
            if (this.state.sortDirection === 'asc') {
                return dateA - dateB;
            } else {
                return dateB - dateA;
            }
        });
    
        // Re-group data after sorting
        // this.groupFinancialSections();
    }

    goToHome() {
        // Like a website's home button: forget the saved open/closed rows and the
        // scroll position, then reload so filters, dates and search start fresh.
        localStorage.removeItem("profit_loss_collapsed_sections");
        localStorage.removeItem("profit_loss_scroll");
        localStorage.removeItem("profit_loss_restore_until");
        window.location.reload();
    }

    reloadPage() {
        window.location.reload();
    }





    

    async loadAccounts() {

        this.state.accounts = await this.orm.searchRead(
            "account.account",
            [
                [
                    "account_type",
                    "in",
                    [
                        "income",
                        "income_other",
                        "expense",
                        "expense_direct_cost",
                    ],
                ],
            ],
            [
                "id",
                "code",
                "name",
                "account_type",
            ]
        );
    
    }


    // Open General Ledger for selected account
    openGeneralLedger(accountId) {

        // come back from the ledger with the same groups open (valid for 30 min)
        localStorage.setItem(
            "profit_loss_collapsed_sections",
            JSON.stringify(this.state.collapsedSections)
        );
        localStorage.setItem("profit_loss_restore_until", String(Date.now() + 30 * 60 * 1000));

        this.action.doAction(
            "gl_pl_reports_aretx.general_ledger_owl",
            {
                additionalContext: {
                    profit_loss_account_id: accountId,
                    profit_loss_date_from: this.state.dateFrom,
                    profit_loss_date_to: this.state.dateTo,
                },
            }
        );

    }

    async initializeFinancialYearDates() {
        if (!this.state.dateFrom || !this.state.dateTo) {
            // Fetch current company's country
            const company = await this.orm.call("res.company", "get_current_company_country", []);
            const fyRange = this.getFinancialYearRange(company.country_code);

            this.state.dateFrom = fyRange.start;
            this.state.dateTo = fyRange.end;
            this.state.fyDates = fyRange; // Store for later use in onMounted
        }
    }

    // Generate comparison columns
    generatePeriodColumns() {

        const columns = [];

        const currentDate = new Date(this.state.dateTo);

        // No Comparison
        if (this.state.comparisonType === "none") {

            columns.push({
                key: "current",
                label: this.state.selectedYear.toString(),
                date_from: this.state.dateFrom,
                date_to: this.state.dateTo,
            });

        }

        // Previous Period (Months)
        else if (this.state.comparisonType === "previous_period") {

            const periods =
                parseInt(this.state.comparisonPeriods || 0);

            for (let i = 0; i <= periods; i++) {

                const date = new Date(
                    currentDate.getFullYear(),
                    currentDate.getMonth() - i,
                    1
                );

                columns.push({

                    key: `month_${i}`,

                    label: date.toLocaleString(
                        "default",
                        {
                            month: "short",
                            year: "2-digit",
                        }
                    ),

                    month: date.getMonth() + 1,

                    year: date.getFullYear(),

                });

            }

        }

        else if (
            this.state.comparisonType === "previous_year"
        ) {
        
            const periods =
                parseInt(this.state.comparisonPeriods || 0);
        
            const month =
                currentDate.getMonth();
        
            for (let i = 0; i <= periods; i++) {
        
                const year =
                    currentDate.getFullYear() - i;
        
                columns.push({
                    key: `year_${i}`,
                    label: `${currentDate.toLocaleString(
                        "default",
                        { month: "short" }
                    )} ${String(year).slice(-2)}`,
                    month: month + 1,
                    year: year,
                });
            }
        }

        console.log("Generated Columns:", columns);

        return columns;
    }

    onComparisonDateFromChange(ev) {

        this.state.comparisonDateFrom =
            ev.target.value;
    
    }
    
    async onComparisonDateToChange(ev) {

        this.state.comparisonDateTo =
            ev.target.value;
    
        if (
            this.state.comparisonDateFrom
            &&
            this.state.comparisonDateTo
        ) {
    
            await this.loadProfitLossData();
    
        }
    
    }

    onComparisonPeriodChange(ev) {

        this.state.comparisonPeriods =
            parseInt(ev.target.value || 1);
    
        this.loadProfitLossData();
    }

    // Comparison Period Changed
    onComparisonChange(type, periods = 0) {

        this.state.comparisonType = type;

        this.state.comparisonPeriods = periods;

        this.loadProfitLossData();
    }

    async loadProfitLossData() {

        console.log(
            "###LOAD P&L",
            this.state.comparisonType,
            this.state.comparisonPeriods
        );
    
        try {
    
            const result = await this.orm.call(
                "profit.loss.report",
                "get_profit_loss_data",
                [
                    this.state.dateFrom,
                    this.state.dateTo,
                    this.state.comparisonType,
                    this.state.comparisonPeriods,
                    this.state.dateType,
                    this.state.comparisonDateFrom,
                    this.state.comparisonDateTo
                ]
            );

            console.log("P&L RESULT", result);
            console.log("SECTIONS", result.sections);
            console.log(
                "BACKEND PERIODS",
                JSON.stringify(result.period_columns, null, 2)
            );
    
            console.log("##########P&L DATA:", result);
    
            this.state.sections = result.sections || {};
            this.state.totals = result.totals || {};
            this.state.lines = result.lines || [];

            console.log(
                "FIRST REVENUE CHILD",
                this.state.sections?.income?.children?.[0]
            );
            
            console.log(
                "Backend Columns:",
                result.period_columns
            );

            console.log(
                "FIRST INCOME CHILD",
                result.sections?.income?.children?.[0]
            );

            console.log(
                "FIRST EXPENSE CHILD",
                result.sections?.expenses?.children?.[0]
            );
            
            console.log(
                "EXPENSE CHILDREN",
                result.sections?.expenses?.children
            );
            
            console.log(
                "PERIOD COLUMNS",
                result.period_columns
            );

            this.state.periodColumns =
                result.period_columns || [];
                

            console.log(
                "FINAL COLUMNS USED IN UI",
                JSON.stringify(this.state.periodColumns, null, 2)
            );

            console.log("Period Columns:", this.state.periodColumns);
            console.log("Column Count:", this.state.periodColumns.length);
    
            // Expand container when comparison columns increase

            
            const columnCount = this.state.periodColumns.length;
    
            const container =
                document.querySelector(".profit-loss-container");
    
            if (container) {
    
                if (columnCount > 5) {
    
                    container.classList.add("pl-pl-container-expanded");
    
                } else {
    
                    container.classList.remove("pl-pl-container-expanded");
    
                }
    
            }
    
        } catch (error) {
    
            console.error("Failed to load Profit & Loss:", error);
    
        }
    
    }

    getFinancialYearRange(countryCode, startYear = null) {
        // First month of the financial year:
        // April for IN / JP / CAD, July for AU / NZD / PKR, otherwise January.
        let startMonth = 0;
        switch (countryCode) {
            case 'IN':
            case 'JP':
            case 'CAD':
                startMonth = 3;
                break;
            case 'AU':
            case 'NZD':
            case 'PKR':
                startMonth = 6;
                break;
        }

        const today = new Date();
        if (startYear === null) {
            // current financial year
            startYear = today.getMonth() >= startMonth
                ? today.getFullYear()
                : today.getFullYear() - 1;
        }

        const start = new Date(startYear, startMonth, 1);
        const end = new Date(startYear + 1, startMonth, 0); // day before the next year starts

        // Build YYYY-MM-DD from the local date parts. toISOString() converts to UTC
        // and moves the date back one day in time zones ahead of UTC (Qatar, India).
        const pad = (n) => String(n).padStart(2, "0");
        const formatDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
        return { start: formatDate(start), end: formatDate(end) };
    }

    toggleSection(sectionId) {

        this.state.collapsedSections[sectionId] =
            !this.state.collapsedSections[sectionId];
    }

    // Load more method 
    loadMore(accountId) {
        this.state.visibleLinesCount[accountId] =
            this.state.visibleLinesCount[accountId] + 100;
    }

    async addCurrencySymbols(lines) {
        // Fetch all unique currency IDs from the lines
        const currencyIds = [...new Set(lines.map(line => line.currency_id ? line.currency_id[0] : false).filter(Boolean))];
        if (!currencyIds.length) return lines;

        const currencies = await this.orm.searchRead(
            "res.currency",
            [['id', 'in', currencyIds]],
            ["name", "symbol"]
        );

        const currencyMap = {};
        currencies.forEach(c => {
            currencyMap[c.id] = c.symbol;
        });

        // Add symbol to each line
        lines.forEach(line => {
            if (line.currency_id && line.currency_id[0]) {
                line.currency_symbol = currencyMap[line.currency_id[0]] || line.currency_id[1];
            } else {
                line.currency_symbol = this.state.companyCurrency.symbol; // default
            }
        });

        return lines;
    }

    onSearchKeydown(ev) {
        if (ev.key === "Enter") {
            this.searchJournal();
        }
    }

    async searchJournal() {
        const text = this.searchInput.el.value.trim();

        // Base domain for posted, non-active lines
        const domain = [
            ['move_id.state', '=', 'posted'],
            ['account_id.deprecated', '=', false]
        ];

        let dateFrom, dateTo;
        let foundAccountId = null;

        switch (this.state.dateType) {
            case "Month":
                if (this.state.selectedMonth) {
                    const monthIndex = new Date(`${this.state.selectedMonth} 1, 2000`).getMonth();
                    const year = new Date().getFullYear(); // Or state.selectedYear if you have it
                    dateFrom = new Date(year, monthIndex, 1);
                    dateTo = new Date(year, monthIndex + 1, 0); // Last day of month
                }
                break;
            case "Quarter":
                if (this.state.selectedQuarter) {
                    const year = new Date().getFullYear();
                    switch (this.state.selectedQuarter) {
                        case "Q1": dateFrom = new Date(year, 0, 1); dateTo = new Date(year, 2, 31); break;
                        case "Q2": dateFrom = new Date(year, 3, 1); dateTo = new Date(year, 5, 30); break;
                        case "Q3": dateFrom = new Date(year, 6, 1); dateTo = new Date(year, 8, 30); break;
                        case "Q4": dateFrom = new Date(year, 9, 1); dateTo = new Date(year, 11, 31); break;
                    }
                }
                break;
            case "Year":
                if (this.state.dateFrom && this.state.dateTo) {
                    dateFrom = new Date(this.state.dateFrom);
                    dateTo = new Date(this.state.dateTo);
                }
                break;
            case "Custom":
                if (this.state.dateFrom && this.state.dateTo) {
                    dateFrom = new Date(this.state.dateFrom);
                    dateTo = new Date(this.state.dateTo);
                }
                break;
            default:
                if (this.state.fyDates) {
                    dateFrom = new Date(this.state.fyDates.start);
                    dateTo = new Date(this.state.fyDates.end);
                }
        }

//        console.log(dateFrom);
//        console.log(dateTo);

        if (dateFrom && dateTo) {
            domain.push(['date', '>=', dateFrom.toISOString().slice(0, 10)]);
            domain.push(['date', '<=', dateTo.toISOString().slice(0, 10)]);
        }


        // If text exists, search by name, move_name, or partner
        if (text) {
            const accountSearchDomain = [['name', 'ilike', text]];
            const accounts = await this.orm.searchRead(
                "account.account",
                accountSearchDomain,
                ["id"]
            );

            if (accounts.length > 0) {
                foundAccountId = accounts[0].id;
            }

            domain.push('|');
            domain.push('|');
            domain.push('|');
            domain.push('|');
            domain.push('|');
            domain.push('|');
            domain.push('|');
                    
            domain.push(['name', 'ilike', text]);
            domain.push(['move_name', 'ilike', text]);
            domain.push(['account_id.name', 'ilike', text]);
            domain.push(['partner_id.name', 'ilike', text]);
            domain.push(['debit', 'ilike', text]);
            domain.push(['credit', 'ilike', text]);
            domain.push(['balance', 'ilike', text]);
            domain.push(['amount_currency', 'ilike', text]);
        }

        const originalSelectedAccount = this.state.selectedAccount;
        if (foundAccountId) {
            this.state.selectedAccount = foundAccountId.toString();
        } else {
            this.state.selectedAccount = null;
        }

        try {
            const lines = await this.orm.searchRead(
                "account.move.line",
                domain,
                ["move_name", "move_id", "date", "name", "partner_id", "account_id","amount_currency" ,"currency_id", "debit", "credit", "balance"],
                {
                    order: "date asc, move_name asc, id asc"
                }
            );

            this.state.financialData = await this.addCurrencySymbols(lines);

            // Re-group & recalc totals
            // this.groupFinancialSections();
            // this.calculateProfitLossTotals();
        } catch (e) {
            console.error("Search error:", e);
        } finally {
            this.state.selectedAccount = originalSelectedAccount;
        }
    }

    selectDateType(type) {
        this.state.dateType = type;
        // Reset previous selections
        this.state.selectedMonth = null;
        this.state.selectedQuarter = null;
        this.state.selectedYear = null;
        if (type === 'Custom') {
            this.state.dateFrom = this.dateFromRef.el?.value || '';
            this.state.dateTo = this.dateToRef.el?.value || '';
        }

        if (type === 'Year') {
            // open on the current financial year straight away (e.g. 2026)
            const current = this.getFinancialYearRange(this.state.companyCurrency.country_code);
            this.selectFinancialYear(parseInt(current.start.slice(0, 4), 10));
        }
    }

    selectMonth(month) {
        this.state.selectedMonth = month;
        if (!this.state.selectedYear) {
            this.state.selectedYear = new Date().getFullYear();
        }
        // set dateFrom/dateTo accordingly
        const monthIndex = ['January','February','March','April','May','June','July','August','September','October','November','December'].indexOf(month);
        const year = this.state.selectedYear;
        this.state.dateFrom = `${year}-${String(monthIndex+1)   .padStart(2,'0')}-01`;
        this.state.dateTo = `${year}-${String(monthIndex+1).padStart(2,'0')}-${new Date(year, monthIndex+1, 0).getDate()}`;
        this.loadProfitLossData();
    }

    onYearSelect(year) {
        this.state.selectedYear = year;
    
        if (this.state.dateType === 'Month' && this.state.selectedMonth) {
            this.selectMonth(this.state.selectedMonth);
        }
    
        if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
            this.selectQuarter(this.state.selectedQuarter);
        }
    
        if (this.state.dateType === 'Year') {
            this.onYearChange({
                target: { value: year }
            });
        }
    }

    selectQuarter(quarter) {
        this.state.selectedQuarter = quarter;
        if (!this.state.selectedYear) {
            this.state.selectedYear = new Date().getFullYear();
        }
        const year = this.state.selectedYear || new Date().getFullYear();
        switch(quarter) {
            case 'Q1': this.state.dateFrom=`${year}-01-01`; this.state.dateTo=`${year}-03-31`; break;
            case 'Q2': this.state.dateFrom=`${year}-04-01`; this.state.dateTo=`${year}-06-30`; break;
            case 'Q3': this.state.dateFrom=`${year}-07-01`; this.state.dateTo=`${year}-09-30`; break;
            case 'Q4': this.state.dateFrom=`${year}-10-01`; this.state.dateTo=`${year}-12-31`; break;
        }
        this.loadProfitLossData();
    }

    onYearChange(ev) {
        const year = parseInt(ev.target.value);
        if (!isNaN(year)) {
            const range = this.getFinancialYearRange(
                this.state.companyCurrency.country_code,
                year
            );
            this.state.dateFrom = range.start;
            this.state.dateTo = range.end;
            this.loadProfitLossData();
        }
    }

    selectFinancialYear(year) {
        this.state.selectedYear = year;
        this.onYearChange({
            target: { value: year }
        });
    }

    onCustomDateFromChange(ev) {
        const fromDate = ev.target.value;
        this.state.dateFrom = fromDate;

        // Restrict 'To' date
        if (this.dateToRef.el) {
            this.dateToRef.el.min = fromDate;

            // Optional: if current 'To' date is before 'From', reset it
            if (this.dateToRef.el.value && this.dateToRef.el.value < fromDate) {
                this.dateToRef.el.value = fromDate;
                this.state.dateTo = fromDate;
            }
        }
    }

    async applyFilters() {

        this.state.dateFrom = this.dateFromRef.el?.value || "";
        this.state.dateTo = this.dateToRef.el?.value || "";
    
        await this.loadProfitLossData();
    
    }

    getActiveDateRangeLabel() {
        // Month
        if (this.state.dateType === "Month" && this.state.selectedMonth) {
            return `Month: ${this.state.selectedMonth}`;
        }

        // Quarter with month range
        if (this.state.dateType === "Quarter" && this.state.selectedQuarter) {
            const quarterMap = {
                Q1: "Jan-Mar",
                Q2: "Apr-Jun",
                Q3: "Jul-Sep",
                Q4: "Oct-Dec",
            };
            return `Quarter: ${this.state.selectedQuarter} (${quarterMap[this.state.selectedQuarter] || ""})`;
        }

        // Year
        if (this.state.dateType === "Year" && this.state.dateFrom && this.state.dateTo) {
            const year = String(this.state.dateFrom).slice(0, 4);
            return `Year: ${year}`;
        }

        // Custom date range
        if (this.state.dateType === "Custom" && this.state.dateFrom && this.state.dateTo) {
            // "YYYY-MM-DD" is split, not parsed with Date(), which moves the day
            // back by one in browsers whose time zone is behind UTC.
            const formatDate = (d) => {
                const [year, month, day] = String(d).slice(0, 10).split("-");
                return `${day}-${month}-${year}`;
            };
            return `Custom: ${formatDate(this.state.dateFrom)} → ${formatDate(this.state.dateTo)}`;
        }

        // Financial year
        if (this.state.fyDates) {
            // "YYYY-MM-DD" is split, not parsed with Date(), which moves the day
            // back by one in browsers whose time zone is behind UTC.
            const formatDate = (d) => {
                const [year, month, day] = String(d).slice(0, 10).split("-");
                return `${day}-${month}-${year}`;
            };
            return `Financial Year: ${formatDate(this.state.fyDates.start)} → ${formatDate(this.state.fyDates.end)}`;
        }

        return "All Records";
    }

    // Comparison Filter 
    async selectComparisonType(type) {

        this.state.comparisonType = type;
    
        if (
            type === "previous_period" ||
            type === "previous_year"
        ) {
    
            if (!this.state.comparisonPeriods) {
                this.state.comparisonPeriods = 1;
            }
        }
    
        if (type === "none") {
    
            this.state.comparisonPeriods = 1;
    
            this.state.comparisonDateFrom = null;
            this.state.comparisonDateTo = null;
        }
    
        await this.loadProfitLossData();
    }


    // ---------- Odoo 17 style P&L rows (built by the backend) ----------
    getVisibleRows() {
        return (this.state.lines || []).filter((row) => {
            if (row.kind === "account" || row.kind === "subtotal") {
                return !this.state.collapsedSections[row.group];
            }
            return true;
        });
    }

    onRowClick(row) {
        if (row.kind === "group" && row.has_children) {
            this.toggleSection(row.group);
        }
    }

    showRowAmount(row) {
        if (row.kind === "section" || row.kind === "label") {
            return false;
        }
        if (row.kind === "group") {
            // a group with accounts shows its total only while collapsed
            return !row.has_children || Boolean(this.state.collapsedSections[row.group]);
        }
        return true;
    }

    isBoldRow(row) {
        return (
            ["total", "subtotal", "section", "label"].includes(row.kind) ||
            (row.kind === "group" && row.has_children)
        );
    }

    getRowClass(row) {
        const classes = ["pl17-row"];
        if (row.kind === "section" || row.id === "net_profit") {
            classes.push("pl-enterprise-total-row");
        } else {
            if (this.isBoldRow(row)) {
                classes.push("pl17-bold");
            }
            if (row.kind === "total" || row.kind === "subtotal") {
                classes.push("pl17-total");
            }
        }
        if (row.kind === "group" && row.has_children) {
            classes.push("pl17-group");
        }
        return classes.join(" ");
    }

    getRowLabelStyle(row) {
        return `padding-left: ${12 + (row.level || 0) * 18}px;`;
    }

    getRowAmountClass(row, periodKey) {
        const amount = (row.values && row.values[periodKey]) || 0;
        const classes = ["text-end"];
        if (amount < 0) {
            classes.push("text-danger");
        } else if (amount === 0 && row.kind !== "total") {
            classes.push("pl17-zero");
        }
        return classes.join(" ");
    }

    async loadCompanyCurrency() {
        // Currency of the active company, so no symbol is hardcoded
        try {
            this.state.companyCurrency = await this.orm.call(
                "res.company",
                "get_company_currency",
                []
            );
        } catch (error) {
            console.error("Failed to load company currency:", error);
        }
    }

    formatCurrency(amount, currencySymbol = this.state.companyCurrency.symbol, currencyName = null) {
        // Determine if it's INR based on symbol or currency name
        const isINR = currencySymbol === '₹' ||
                      (currencyName && currencyName.toUpperCase().includes('INR')) ||
                      (currencyName && currencyName.toUpperCase().includes('RUPEE'));

        const isWhole = Number.isInteger(amount);

        if (isINR) {
            // Indian format: ₹ 1,05,000 (lakhs and crores system)
            let x = amount.toFixed(isWhole ? 0 : 2).split('.');
            let intPart = x[0];
            let decPart = x.length > 1 && x[1] !== '00' ? '.' + x[1] : '';

            // Handle Indian numbering system
            if (intPart.length > 3) {
                // Take last 3 digits
                let lastThree = intPart.substring(intPart.length - 3);
                let otherNumbers = intPart.substring(0, intPart.length - 3);

                // Apply Indian grouping (every 2 digits after first 3)
                if (otherNumbers !== '') {
                    otherNumbers = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
                    lastThree = ',' + lastThree;
                }

                intPart = otherNumbers + lastThree;
            }

            return currencySymbol + ' ' + intPart + decPart;
        } else {
            // International format: $ 105,000 (thousands system)
            let options = {
                minimumFractionDigits: isWhole ? 0 : 2,
                maximumFractionDigits: isWhole ? 0 : 2,
            };
            return currencySymbol + ' ' + amount.toLocaleString('en-US', options);
        }
    }

    openProfitLoss(section) {
        console.log(section);
    }

    getAmountClass(amount) {
        if (amount < 0) return 'text-danger';
        return '';
    }

    formatToDDMMYYYY(dateStr) {
        if (!dateStr) return "";
        if (/^\d{4}-\d{2}-\d{2}/.test(String(dateStr))) {
            // split instead of Date(): no day shift in time zones behind UTC
            const [year, month, day] = String(dateStr).slice(0, 10).split("-");
            return `${day}/${month}/${year}`;
        }
        const date = new Date(dateStr);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
    }

    formatDate(dateStr) {
        return this.formatToDDMMYYYY(dateStr);
    }

    getFilterTitle() {
        const textSearch = this.searchInput && this.searchInput.el ? this.searchInput.el.value.trim() : null;

        if (textSearch) {
            return `${textSearch}`;
        }

        return "All Records";
    }

    // Export to PDF
    async exportToPDF() {
        this.ui.block();
        try {
            const searchText =
                this.searchInput?.el?.value?.trim() || "";
            const dateFrom = this.state.dateFrom;
            const dateTo = this.state.dateTo;

            const columnCount =
                this.state.periodColumns?.length || 0;

            if (columnCount > 5) {
            
                const confirmed = window.confirm(
                    "Only the latest 5 period columns will be printed in PDF.\n\n" +
                    "If you need older periods, please select an earlier date range and export again.\n\n" +
                    "Do you want to continue?"
                );
            
                if (!confirmed) {
                
                    this.ui.unblock();
                
                    return;
                }
            }

            let month = null;
            let quarter = null;
            let year = null;

            if (this.state.dateType === 'Month' && this.state.selectedMonth) {
                // Convert Month name ('October') to month index (10)
                const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                month = monthNames.indexOf(this.state.selectedMonth) + 1; // 1-indexed month
                year = parseInt(String(dateFrom).slice(0, 4), 10); // Get year from the calculated date range

            } else if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
                // Pass the quarter label (Q1, Q2, etc.)
                quarter = this.state.selectedQuarter;
                year = parseInt(String(dateFrom).slice(0, 4), 10);

            } else if ((this.state.dateType === 'Year' || !this.state.dateType) && dateFrom) {
                // This covers 'Year' selection and the default Financial Year initialization
                year = parseInt(String(dateFrom).slice(0, 4), 10);
            }

            // Prepare data for PDF export
            const exportData = {
                date_from: dateFrom,
                date_to: dateTo,
                month: month,
                quarter: quarter,
                year: year,
                filter_title: this.getFilterTitle(),
                grouped_data: this.state.sections,
                totals: this.state.totals,
                lines: this.state.lines,
                company_info: await this.orm.call("res.company", "get_current_company_info", []),
                period_columns: this.state.periodColumns,
            };

            // Call the PDF export method
            const result = await this.orm.call(
                "profit.loss.export",
                "export_profit_loss_pdf",
                [exportData]
            );

            if (result) {
                // Download the PDF
                await this.action.doAction(result);
            } else {
                throw new Error("PDF export failed: Server response did not contain a download URL. Result: " + JSON.stringify(result));
            }
        } catch (error) {
            console.error("Error exporting PDF:", error);
            throw error;
        } finally {

            this.ui.unblock();
        
        }
    }

    // Export to XLSX
    async exportToXLSX() {
        this.ui.block();
        try {
            const dateFrom = this.state.dateFrom;
            const dateTo = this.state.dateTo;
            let month = null;
            let quarter = null;
            let year = null;

            if (this.state.dateType === 'Month' && this.state.selectedMonth) {
                // Convert Month name ('October') to month index (10)
                const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                month = monthNames.indexOf(this.state.selectedMonth) + 1; // 1-indexed month
                year = parseInt(String(dateFrom).slice(0, 4), 10); // Get year from the calculated date range

            } else if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
                // Pass the quarter label (Q1, Q2, etc.)
                quarter = this.state.selectedQuarter;
                year = parseInt(String(dateFrom).slice(0, 4), 10);

            } else if ((this.state.dateType === 'Year' || !this.state.dateType) && dateFrom) {
                // This covers 'Year' selection and the default Financial Year initialization
                year = parseInt(String(dateFrom).slice(0, 4), 10);
            }

            // Prepare data for XLSX export
            const exportData = {
                date_from: dateFrom,
                date_to: dateTo,
                month: month,
                quarter: quarter,
                year: year,
                filter_title: this.getFilterTitle(),
                financial_data: this.state.financialData,
                sections: this.state.sections,
                collapsed_accounts: this.state.collapsedSections,
                totals: this.state.totals,
                lines: this.state.lines,
                company_info: await this.orm.call("res.company", "get_current_company_info", []),
                period_columns: this.state.periodColumns,
            };

            // Call the XLSX export method
            const result = await this.orm.call(
                "profit.loss.export",
                "export_profit_loss_xlsx",
                [exportData]
            );

            if (result && result.url) {
                // Download the XLSX
                window.open(result.url, '_blank');
            } else {
                console.error("XLSX export failed");
            }
        } catch (error) {
            console.error("Error exporting XLSX:", error);
        } finally {
            this.ui.unblock();
        }
    }
}

ProfitLossReport.template = "profit_loss_report.ProfitLossReport";
registry.category("actions").add("profit_loss_report.profit_loss_owl", ProfitLossReport);