/** @odoo-module **/

import { registry } from "@web/core/registry";
import { Component, useState, onWillStart, onMounted, useRef } from "@odoo/owl";
import { useService } from "@web/core/utils/hooks";

const configModel = 'partner.ledger.report.config';

export class PartnerLedgerReport extends Component {
    setup() {
        this.state = useState({
            visibleLinesCount: {},
            ledgerData: [],
            groupedData: [],
            dateFrom: "",
            dateTo: "",
            selectedYear: new Date().getFullYear(),

            availableYears: Array.from(
                { length: 100 },
                (_, i) => new Date().getFullYear() - i
            ),
            totals: {
                debit: 0,
                credit: 0,
                balance: 0
            },
            collapsedPartners: {},
            fyDates: null,
            isDebug: Boolean(odoo.debug),
            companyCurrency: { id: false, name: '', symbol: '' },
            searchText: '', // text applied from the search box (matches partner rows only)
            sortDirection: 'asc', // added for date sorting   
            selectedAccountType: 'all',   
            config: {
                show_journal: true,
                show_date: true,
                show_due_date: true,
                show_communication: true,
                show_partner: true,
                show_currency: true,
                show_debit: true,
                show_credit: true,
                show_balance: true,
            },
        });

        this.ui = useService("ui");
        this.orm = useService("orm");
        this.dateFromRef = useRef("date-from");
        this.dateToRef = useRef("date-to");
        this.searchInput = useRef("search-input");

        onWillStart(async () => {
            await this.loadCompanyCurrency();
            await this.loadConfig();
            await this.initializeFinancialYearDates();
            await this.loadLedgerData();
        });

        onMounted(() => {
            // Set date picker values after DOM is ready
            if (this.state.fyDates) {
                if (this.dateFromRef.el) {
                    this.dateFromRef.el.value = this.state.fyDates.start;
                }
                if (this.dateToRef.el) {
                    this.dateToRef.el.value = this.state.fyDates.end;
                }
            }
            // When page loads again, restores to which accounts were open/closed
            // Rows stay open only when coming back from a drill-down (journal entry /
            // ledger); opening the report any other way always starts collapsed.
            const restoreUntil = parseInt(localStorage.getItem("partner_ledger_restore_until") || "0");
            localStorage.removeItem("partner_ledger_restore_until");
            const shouldRestore = restoreUntil > Date.now();

            const savedCollapsed = shouldRestore
                ? localStorage.getItem("partner_ledger_collapsed_accounts")
                : null;

            if (savedCollapsed) {
                this.state.collapsedPartners =
                    JSON.parse(savedCollapsed);
            }

            const savedScroll = shouldRestore
                ? localStorage.getItem("partner_ledger_scroll")
                : null;

            if (savedScroll) {
                setTimeout(() => {
                    requestAnimationFrame(() => {

                        const content =
                            document.querySelector('.o_content');
                        if (content) {
                        
                        content.scrollTop =
                                parseInt(savedScroll);
                        }
            
                    });
            
                }, 500);
            }
                    });
                
                    this.action = useService("action");
                }

    sortByDate() {

        // Toggle asc/desc
        this.state.sortDirection =
            this.state.sortDirection === 'asc'
                ? 'desc'
                : 'asc';
    
        // Sort ledger data
        // Sort only lines INSIDE each partner

        this.state.groupedData.forEach(partner => {
        
            partner.lines.sort((a, b) => {
            
                const dateA = new Date(a.date);
                const dateB = new Date(b.date);
            
                if (this.state.sortDirection === 'asc') {
                    return dateA - dateB;
                } else {
                    return dateB - dateA;
                }
            });
        
        });
    }

    async selectAccountType(type) {

        this.state.selectedAccountType = type;
    
        await this.loadLedgerData();
    }

    goToHome() {
        // Like a website's home button: forget the saved open/closed rows and the
        // scroll position, then reload so filters, dates and search start fresh.
        localStorage.removeItem("partner_ledger_collapsed_accounts");
        localStorage.removeItem("partner_ledger_scroll");
        localStorage.removeItem("partner_ledger_restore_until");
        window.location.reload();
    }

    reloadPage() {
        window.location.reload();
    }

    async loadConfig() {
        if (!this.state.isDebug) {
            return;
        }
        try {
            const configRecord = await this.orm.call(
                configModel,
                'get_active_config',
                []
            );

            // Assuming configRecord contains fields like show_journal, etc.
            if (configRecord) {
                this.state.config = {
                    show_journal: configRecord.show_journal,
                    show_date: configRecord.show_date,
                    show_due_date: configRecord.show_due_date,
                    show_communication: configRecord.show_communication,
                    show_partner: configRecord.show_partner,
                    show_currency: configRecord.show_currency,
                    show_debit: configRecord.show_debit,
                    show_credit: configRecord.show_credit,
                    show_balance: configRecord.show_balance,
                };
            }
        } catch (error) {
            console.error("Failed to load partner Ledger Configuration:", error);
            // Default config is used
        }
    }

    openDebugConfig = async function () {
        try {
            // 1. Call the Python method to get the active (and initialized) config record.
            const configRecord = await this.orm.call(
                configModel,
                'get_active_config',
                [] // No arguments for the @api.model method
            );

            // The ORM call returns the ID of the record.
            const configId = configRecord.id;

            // 2. Open the form view for the retrieved record ID.
            this.action.doAction({
                type: "ir.actions.act_window",
                res_model: configModel,
                res_id: configId, // Pass the specific record ID
                view_mode: "form",
                target: "new",
                views: [[false, "form"]],
                name: "partner Ledger Configuration",
            });
        } catch (error) {
            console.error("Failed to retrieve or initialize partner Ledger Configuration:", error);
            // Optionally show a user-facing notification about the error
            this.env.services.notification.add(
                "Could not load the partner Ledger Configuration.",
                { type: 'danger' }
            );
        }
    }

    

    async initializeFinancialYearDates() {
        if (!this.state.dateFrom || !this.state.dateTo) {
            // Fetch current company's country
            const company = await this.orm.call("res.company", "get_current_company_country", []);
            const fyRange = this.getFinancialYearRange(company.country_code);

            this.state.dateFrom = fyRange.start;
            this.state.dateTo = fyRange.end;
            this.state.fyDates = fyRange; // Store for later use in onMounted
        }
    }

    async loadLedgerData() {
        let domain = [
            ['move_id.state', '=', 'posted'],
            ['partner_id', '!=', false]
            // ['account_id.deprecated', '=', false]
        ];

        // Add date filters
        if (this.state.dateFrom) {
            domain.push(['date', '>=', this.state.dateFrom]);
        }
        if (this.state.dateTo) {
            domain.push(['date', '<=', this.state.dateTo]);
        }
        if (this.state.selectedAccount) {
            domain.push(['account_id', '=', parseInt(this.state.selectedAccount)]);
        }

        const lines = await this.orm.searchRead(
            "account.move.line",
            domain,
            ["move_name", "move_id", "date", "date_maturity", "name", "partner_id", "account_id","amount_currency" ,"currency_id", "debit", "credit", "balance", "account_type"],
            {
                order: "date asc, move_name asc, id asc"
            }
        );
        // Keep only payable/receivable lines
        let filteredLines = lines;
            
        if (this.state.selectedAccountType === 'receivable') {
        
            filteredLines = lines.filter(line =>
                line.account_type === 'asset_receivable'
            );
        
        }
        else if (this.state.selectedAccountType === 'payable') {
        
            filteredLines = lines.filter(line =>
                line.account_type === 'liability_payable'
            );
        
        }
        else {
        
            filteredLines = lines.filter(line =>
                line.account_type === 'asset_receivable' ||
                line.account_type === 'liability_payable'
            );
        }

        this.state.ledgerData = await this.addCurrencySymbols(filteredLines);
        await this.addInitialBalances();
        this.applyPartnerSearch();
        this.state.visibleLinesCount = {};
        this.groupDataByPartner();
        this.calculateTotals();
    }

    async addInitialBalances() {

        const dateFrom = this.state.dateFrom;
    
        if (!dateFrom) {
            return;
        }
    
        const initialLines = await this.orm.searchRead(
            "account.move.line",
            [
                ['move_id.state', '=', 'posted'],
                ['partner_id', '!=', false],
                ['date', '<', dateFrom]
            ],
            [
                "partner_id",
                "currency_id",
                "debit",
                "credit",
                "balance",
                "account_type"
            ]
        );
    
        const openingBalances = {};
    
        initialLines.forEach(line => {

            if (this.state.selectedAccountType === 'receivable') {
        
                if (line.account_type !== 'asset_receivable') {
                    return;
                }
        
            } else if (this.state.selectedAccountType === 'payable') {
        
                if (line.account_type !== 'liability_payable') {
                    return;
                }
        
            } else {
        
                if (
                    line.account_type !== 'asset_receivable' &&
                    line.account_type !== 'liability_payable'
                ) {
                    return;
                }
            }
    
            const partnerId = line.partner_id[0];
            const partnerName = line.partner_id[1];
    
            if (!openingBalances[partnerId]) {
    
                openingBalances[partnerId] = {
                    partner_id: line.partner_id,
                    debit: 0,
                    credit: 0,
                    balance: 0,
                    currency_id: line.currency_id,
                };
            }
    
            openingBalances[partnerId].debit += line.debit;
            openingBalances[partnerId].credit += line.credit;
            openingBalances[partnerId].balance += line.balance;
        });
    
        const initialBalanceLines = Object.values(openingBalances).map(ob => {
    
            return {
                move_name: "Initial Balance",
                move_id: [null, "Initial Balance"],
                date: dateFrom,
                date_maturity: dateFrom,
                name: "",
                partner_id: ob.partner_id,
                currency_id: ob.currency_id,
                debit: 0,
                credit: 0,
                balance: ob.balance,
                initial_balance: true,
            };
        });
    
        this.state.ledgerData = [
            ...initialBalanceLines,
            ...this.state.ledgerData
        ];
    
        this.state.ledgerData =
            await this.addCurrencySymbols(this.state.ledgerData);
    }
    

    getFinancialYearRange(countryCode, startYear = null) {
        // First month of the financial year:
        // April for IN / JP / CAD, July for AU / NZD / PKR, otherwise January.
        let startMonth = 0;
        switch (countryCode) {
            case 'IN':
            case 'JP':
            case 'CAD':
                startMonth = 3;
                break;
            case 'AU':
            case 'NZD':
            case 'PKR':
                startMonth = 6;
                break;
        }

        const today = new Date();
        if (startYear === null) {
            // current financial year
            startYear = today.getMonth() >= startMonth
                ? today.getFullYear()
                : today.getFullYear() - 1;
        }

        const start = new Date(startYear, startMonth, 1);
        const end = new Date(startYear + 1, startMonth, 0); // day before the next year starts

        // Build YYYY-MM-DD from the local date parts. toISOString() converts to UTC
        // and moves the date back one day in time zones ahead of UTC (Qatar, India).
        const pad = (n) => String(n).padStart(2, "0");
        const formatDate = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
        return { start: formatDate(start), end: formatDate(end) };
    }

    togglePartner(partnerName) {
        this.state.collapsedPartners[partnerName] = !this.state.collapsedPartners[partnerName];
    }

    applyPartnerSearch() {
        // Keep only the partners whose name matches every word typed in the search
        // box. Lines inside a partner (journal, amount, ...) are never searched.
        const words = (this.state.searchText || "").toLowerCase().split(/\s+/).filter(Boolean);
        if (!words.length) {
            return;
        }
        const matching = new Set();
        for (const line of this.state.ledgerData) {
            const name = line.partner_id ? String(line.partner_id[1]).toLowerCase() : "";
            if (line.partner_id && words.every(word => name.includes(word))) {
                matching.add(line.partner_id[0]);
            }
        }
        this.state.ledgerData = this.state.ledgerData.filter(
            line => line.partner_id && matching.has(line.partner_id[0])
        );
    }

    groupDataByPartner() {

        const grouped = {};

        const sortedLines = [...this.state.ledgerData].sort((a, b) => {

            // Sort by accounting date first
            const dateA = new Date(a.date);
            const dateB = new Date(b.date);
    
            if (dateA - dateB !== 0) {
                return dateA - dateB;
            }
    
            // Same date → preserve real creation sequence
            return (a.id || 0) - (b.id || 0);
        });

        
    
        sortedLines.forEach(line => {
    
            if (
                line.debit === 0 &&
                line.credit === 0 &&
                line.balance === 0
            ) {
                return;
            }
    
            const partnerName =
                line.partner_id
                    ? line.partner_id[1]
                    : "Initial Balance";
    
            if (!grouped[partnerName]) {
    
                grouped[partnerName] = {
                    
                    partner_name: partnerName,
                    debit: 0,
                    credit: 0,
                    balance: 0,
                    lines: [],
                    runningBalance: 0,

                };
    
                if (!(partnerName in this.state.collapsedPartners)) {
                    this.state.collapsedPartners[partnerName] = true;
                }
                // grouped[partnerName].runningBalance = 0;
            }

            if (!(partnerName in this.state.visibleLinesCount)) {
                this.state.visibleLinesCount[partnerName] = 100;
            }
    
            grouped[partnerName].debit += line.debit;
            grouped[partnerName].credit += line.credit;
            grouped[partnerName].balance += line.balance;
            if (line.initial_balance) {

                grouped[partnerName].runningBalance =
                    line.balance;
            
                grouped[partnerName].lines.push({
                    ...line,
                    balance: line.balance,
                });
            
                return;
            }
            grouped[partnerName].runningBalance += line.debit - line.credit;
    
            grouped[partnerName].lines.push({...line,
                balance: grouped[partnerName].runningBalance,
            });
        });
    
        this.state.groupedData = Object.values(grouped);
    }

    loadMore(partnerName) {
        this.state.visibleLinesCount[partnerName] = 
        this.state.visibleLinesCount[partnerName] + 100;
    }

    calculateTotals() {
        this.state.totals = { debit: 0, credit: 0, balance: 0 };

        this.state.ledgerData.forEach(line => {
            this.state.totals.debit += line.debit;
            this.state.totals.credit += line.credit;
        });
        this.state.totals.balance = 0;

        this.state.ledgerData.forEach(line => {
            this.state.totals.balance += line.balance;
        });
    }

    async addCurrencySymbols(lines) {
        // Fetch all unique currency IDs from the lines
        const currencyIds = [...new Set(lines.map(line => line.currency_id ? line.currency_id[0] : false).filter(Boolean))];
        if (!currencyIds.length) return lines;

        const currencies = await this.orm.searchRead(
            "res.currency",
            [['id', 'in', currencyIds]],
            ["name", "symbol"]
        );

        const currencyMap = {};
        currencies.forEach(c => {
            currencyMap[c.id] = c.symbol;
        });

        // Add symbol to each line
        lines.forEach(line => {
            if (line.currency_id && line.currency_id[0]) {
                line.currency_symbol = currencyMap[line.currency_id[0]] || line.currency_id[1];
            } else {
                line.currency_symbol = this.state.companyCurrency.symbol; // default
            }
        });

        return lines;
    }

    onSearchKeydown(ev) {
        if (ev.key === "Enter") {
            this.searchJournal();
        }
    }

    async searchJournal() {
        this.state.searchText = this.searchInput.el.value.trim();
        await this.loadLedgerData();
    }

    selectDateType(type) {

        this.state.dateType = type;
    
        this.state.selectedMonth = null;
        this.state.selectedQuarter = null;
        this.state.selectedYear = this.state.selectedYear || new Date().getFullYear();
    
        if (type === 'Custom') {
    
            this.state.dateFrom =
                this.dateFromRef.el?.value || '';
    
            this.state.dateTo =
                this.dateToRef.el?.value || '';
        }

        if (type === 'Year') {
            // open on the current financial year straight away (e.g. 2026)
            const current = this.getFinancialYearRange(this.state.companyCurrency.country_code);
            this.selectFinancialYear(parseInt(current.start.slice(0, 4), 10));
        }
    }

    selectMonth(month) {
        this.state.selectedMonth = month;

        if (!this.state.selectedYear) {
            this.state.selectedYear = new Date().getFullYear();
        }

        const monthIndex = [
            'January','February','March','April','May','June',
            'July','August','September','October','November','December'
        ].indexOf(month);

        const year = this.state.selectedYear;

        this.state.dateFrom =
            `${year}-${String(monthIndex + 1).padStart(2,'0')}-01`;

        this.state.dateTo =
            `${year}-${String(monthIndex + 1).padStart(2,'0')}-${new Date(year, monthIndex + 1, 0).getDate()}`;

        this.loadLedgerData();
    }

    onYearSelect(year) {

        this.state.selectedYear = year;
    
        if (
            this.state.dateType === 'Month' &&
            this.state.selectedMonth
        ) {
            this.selectMonth(this.state.selectedMonth);
        }
    
        if (
            this.state.dateType === 'Quarter' &&
            this.state.selectedQuarter
        ) {
            this.selectQuarter(this.state.selectedQuarter);
        }
    
        if (this.state.dateType === 'Year') {
    
            this.onYearChange({
                target: { value: year }
            });
        }
    }



    selectQuarter(quarter) {

        this.state.selectedQuarter = quarter;
    
        if (!this.state.selectedYear) {
            this.state.selectedYear = new Date().getFullYear();
        }
    
        const year =
            this.state.selectedYear ||
            new Date().getFullYear();
    
        switch(quarter) {
    
            case 'Q1':
                this.state.dateFrom = `${year}-01-01`;
                this.state.dateTo   = `${year}-03-31`;
                break;
    
            case 'Q2':
                this.state.dateFrom = `${year}-04-01`;
                this.state.dateTo   = `${year}-06-30`;
                break;
    
            case 'Q3':
                this.state.dateFrom = `${year}-07-01`;
                this.state.dateTo   = `${year}-09-30`;
                break;
    
            case 'Q4':
                this.state.dateFrom = `${year}-10-01`;
                this.state.dateTo   = `${year}-12-31`;
                break;
        }
    
        this.loadLedgerData();
    }

    onYearChange(ev) {

        const year =
            parseInt(ev.target.value);
    
        if (!isNaN(year)) {
    
            const range = this.getFinancialYearRange(
                this.state.companyCurrency.country_code,
                year
            );
            this.state.dateFrom = range.start;
            this.state.dateTo = range.end;
    
            this.loadLedgerData();
        }
    }

    selectFinancialYear(year) {
        this.state.selectedYear = year;
        this.onYearChange({
            target: { value: year }
        });
    }

    onCustomDateFromChange(ev) {
        const fromDate = ev.target.value;
        this.state.dateFrom = fromDate;

        // Restrict 'To' date
        if (this.dateToRef.el) {
            this.dateToRef.el.min = fromDate;

            // Optional: if current 'To' date is before 'From', reset it
            if (this.dateToRef.el.value && this.dateToRef.el.value < fromDate) {
                this.dateToRef.el.value = fromDate;
                this.state.dateTo = fromDate;
            }
        }
    }

    async applyFilters() {
        const domain = [
            ['move_id.state', '=', 'posted'],
        ];

        // Only add filters if values are provided
        const dateFrom = this.dateFromRef.el?.value;
        const dateTo = this.dateToRef.el?.value;
        const selectedAccount = this.state.selectedAccount || null;

        if (dateFrom) {
            domain.push(['date', '>=', dateFrom]);
        }
        if (dateTo) {
            domain.push(['date', '<=', dateTo]);
        }
        if (selectedAccount) {
            domain.push(['account_id', '=', parseInt(selectedAccount)]);
        }

        const lines = await this.orm.searchRead(
            "account.move.line",
            domain,
            ["move_name", "move_id", "date", "date_maturity", "name", "partner_id", "account_id","amount_currency" ,"currency_id", "debit", "credit", "balance","account_type"],
            {
                order: "date asc, move_name asc, id asc"
            }
        
        );

        this.state.ledgerData = await this.addCurrencySymbols(lines);

        // Update state with current filter values for initial balance calculation
        this.state.dateFrom = dateFrom;
        this.state.dateTo = dateTo;
        this.state.selectedAccount = selectedAccount;

        // Add initial balances based on the filtered date range
        await this.addInitialBalances();
        this.applyPartnerSearch();
        this.groupDataByPartner();
        this.calculateTotals();
    }

    getActiveDateRangeLabel() {
        // Month
        if (this.state.dateType === "Month" && this.state.selectedMonth) {
            return `Month: ${this.state.selectedMonth}`;
        }

        // Quarter with month range
        if (this.state.dateType === "Quarter" && this.state.selectedQuarter) {
            const quarterMap = {
                Q1: "Jan-Mar",
                Q2: "Apr-Jun",
                Q3: "Jul-Sep",
                Q4: "Oct-Dec",
            };
            return `Quarter: ${this.state.selectedQuarter} (${quarterMap[this.state.selectedQuarter] || ""})`;
        }

        // Year
        if (this.state.dateType === "Year" && this.state.dateFrom && this.state.dateTo) {
            const year = String(this.state.dateFrom).slice(0, 4);
            return `Year: ${year}`;
        }

        // Custom date range
        if (this.state.dateType === "Custom" && this.state.dateFrom && this.state.dateTo) {
            // "YYYY-MM-DD" is split, not parsed with Date(), which moves the day
            // back by one in browsers whose time zone is behind UTC.
            const formatDate = (d) => {
                const [year, month, day] = String(d).slice(0, 10).split("-");
                return `${day}-${month}-${year}`;
            };
            return `Custom: ${formatDate(this.state.dateFrom)} → ${formatDate(this.state.dateTo)}`;
        }

        // Financial year
        if (this.state.fyDates) {
            // "YYYY-MM-DD" is split, not parsed with Date(), which moves the day
            // back by one in browsers whose time zone is behind UTC.
            const formatDate = (d) => {
                const [year, month, day] = String(d).slice(0, 10).split("-");
                return `${day}-${month}-${year}`;
            };
            return `Financial Year: ${formatDate(this.state.fyDates.start)} → ${formatDate(this.state.fyDates.end)}`;
        }

        return "All Records";
    }

    async loadCompanyCurrency() {
        // Currency of the active company, so no symbol is hardcoded
        try {
            this.state.companyCurrency = await this.orm.call(
                "res.company",
                "get_company_currency",
                []
            );
        } catch (error) {
            console.error("Failed to load company currency:", error);
        }
    }

    formatCurrency(amount, currencySymbol = this.state.companyCurrency.symbol, currencyName = null) {
        // Determine if it's INR based on symbol or currency name
        const isINR = currencySymbol === '₹' ||
                      (currencyName && currencyName.toUpperCase().includes('INR')) ||
                      (currencyName && currencyName.toUpperCase().includes('RUPEE'));

        const isWhole = Number.isInteger(amount);

        if (isINR) {
            // Indian format: ₹ 1,05,000 (lakhs and crores system)
            let x = amount.toFixed(isWhole ? 0 : 2).split('.');
            let intPart = x[0];
            let decPart = x.length > 1 && x[1] !== '00' ? '.' + x[1] : '';

            // Handle Indian numbering system
            if (intPart.length > 3) {
                // Take last 3 digits
                let lastThree = intPart.substring(intPart.length - 3);
                let otherNumbers = intPart.substring(0, intPart.length - 3);

                // Apply Indian grouping (every 2 digits after first 3)
                if (otherNumbers !== '') {
                    otherNumbers = otherNumbers.replace(/\B(?=(\d{2})+(?!\d))/g, ',');
                    lastThree = ',' + lastThree;
                }

                intPart = otherNumbers + lastThree;
            }

            return currencySymbol + ' ' + intPart + decPart;
        } else {
            // International format: $ 105,000 (thousands system)
            let options = {
                minimumFractionDigits: isWhole ? 0 : 2,
                maximumFractionDigits: isWhole ? 0 : 2,
            };
            return currencySymbol + ' ' + amount.toLocaleString('en-US', options);
        }
    }

    viewJournalEntry(moveId) {
        if (!moveId) {
            return;
        }
            const action = {
                type: "ir.actions.act_window",
                res_model: "account.move",
                res_id: moveId,
                views: [[false, "form"]],
                target: "current", // opens in same window
            };
            // SAVES which accounts are open and position of scroll  
            localStorage.setItem(
                "partner_ledger_collapsed_accounts",
                JSON.stringify(this.state.collapsedPartners)
            );
            
            localStorage.setItem(
                "partner_ledger_scroll",
                document.querySelector('.o_content')?.scrollTop || 0
            );
            // come back from the entry with the same rows open (valid for 30 min)
            localStorage.setItem("partner_ledger_restore_until", String(Date.now() + 30 * 60 * 1000));
            this.env.services.action.doAction(action);
    }

    getAmountClass(amount) {
        if (amount < 0) return 'text-danger';
        return '';
    }

    formatToDDMMYYYY(dateStr) {
        if (!dateStr) return "";
        if (/^\d{4}-\d{2}-\d{2}/.test(String(dateStr))) {
            // split instead of Date(): no day shift in time zones behind UTC
            const [year, month, day] = String(dateStr).slice(0, 10).split("-");
            return `${day}/${month}/${year}`;
        }
        const date = new Date(dateStr);
        const day = String(date.getDate()).padStart(2, "0");
        const month = String(date.getMonth() + 1).padStart(2, "0");
        const year = date.getFullYear();
        return `${day}/${month}/${year}`;
    }

    formatDate(dateStr) {
        return this.formatToDDMMYYYY(dateStr);
    }

    getFilterTitle() {
        const textSearch = this.searchInput && this.searchInput.el ? this.searchInput.el.value.trim() : null;

        if (textSearch) {
            return `${textSearch}`;
        }

        return "All Records";
    }

    // Export to PDF
    async exportToPDF() {
        this.ui.block();
        try {
            const searchText = this.searchInput.el.value.trim();
            const dateFrom = this.state.dateFrom;
            const dateTo = this.state.dateTo;
            let month = null;
            let quarter = null;
            let year = null;

            if (this.state.dateType === 'Month' && this.state.selectedMonth) {
                // Convert Month name ('October') to month index (10)
                const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                month = monthNames.indexOf(this.state.selectedMonth) + 1; // 1-indexed month
                year = parseInt(String(dateFrom).slice(0, 4), 10); // Get year from the calculated date range

            } else if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
                // Pass the quarter label (Q1, Q2, etc.)
                quarter = this.state.selectedQuarter;
                year = parseInt(String(dateFrom).slice(0, 4), 10);

            } else if ((this.state.dateType === 'Year' || !this.state.dateType) && dateFrom) {
                // This covers 'Year' selection and the default Financial Year initialization
                year = parseInt(String(dateFrom).slice(0, 4), 10);
            }

            // Prepare data for PDF export
            const exportData = {
                date_from: dateFrom,
                date_to: dateTo,
                month: month,
                quarter: quarter,
                year: year,
                filter_title: this.getFilterTitle(),
                ledger_data: this.state.ledgerData,
                grouped_data: this.state.groupedData,
                collapsed_partners: this.state.collapsedPartners,
                totals: this.state.totals,
                company_info: await this.orm.call("res.company", "get_current_company_info", []),
                search_text: searchText,
            };

            // Call the PDF export method
            const result = await this.orm.call(
                "partner.ledger.export",
                "export_partner_ledger_pdf",
                [exportData]
            );

            if (result) {
                // Download the PDF
                await this.action.doAction(result);
            } else {
                throw new Error("PDF export failed: Server response did not contain a download URL. Result: " + JSON.stringify(result));
            }
        } catch (error) {
            console.error("Error exporting PDF:", error);
            throw error;
        } finally {
            this.ui.unblock();
        }
    }

    // Export to XLSX
    async exportToXLSX() {
        this.ui.block();
        try {
            const dateFrom = this.state.dateFrom;
            const dateTo = this.state.dateTo;
            let month = null;
            let quarter = null;
            let year = null;

            if (this.state.dateType === 'Month' && this.state.selectedMonth) {
                // Convert Month name ('October') to month index (10)
                const monthNames = ['January','February','March','April','May','June','July','August','September','October','November','December'];
                month = monthNames.indexOf(this.state.selectedMonth) + 1; // 1-indexed month
                year = parseInt(String(dateFrom).slice(0, 4), 10); // Get year from the calculated date range

            } else if (this.state.dateType === 'Quarter' && this.state.selectedQuarter) {
                // Pass the quarter label (Q1, Q2, etc.)
                quarter = this.state.selectedQuarter;
                year = parseInt(String(dateFrom).slice(0, 4), 10);

            } else if ((this.state.dateType === 'Year' || !this.state.dateType) && dateFrom) {
                // This covers 'Year' selection and the default Financial Year initialization
                year = parseInt(String(dateFrom).slice(0, 4), 10);
            }

            // Prepare data for XLSX export
            const exportData = {
                date_from: dateFrom,
                date_to: dateTo,
                month: month,
                quarter: quarter,
                year: year,
                filter_title: this.getFilterTitle(),
                ledger_data: this.state.ledgerData,
                grouped_data: this.state.groupedData,
                collapsed_partners: this.state.collapsedPartners,
                totals: this.state.totals,
                company_info: await this.orm.call("res.company", "get_current_company_info", [])
            };

            // Call the XLSX export method
            const result = await this.orm.call(
                "partner.ledger.export",
                "export_partner_ledger_xlsx",
                [exportData]
            );

            if (result && result.url) {
                // Download the XLSX
                window.open(result.url, '_blank');
            } else {
                console.error("XLSX export failed");
            }
        } catch (error) {
            console.error("Error exporting XLSX:", error);
        } finally {
            this.ui.unblock();
        }
    }
}

PartnerLedgerReport.template = "partner_ledger_report.partnerLedgerReport";
registry.category("actions").add("partner_ledger_report.partner_ledger_owl", PartnerLedgerReport);