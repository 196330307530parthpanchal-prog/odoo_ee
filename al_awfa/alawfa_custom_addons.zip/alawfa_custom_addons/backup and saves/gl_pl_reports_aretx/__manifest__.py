{
    'name': 'GL, Partner Ledger & P&L Reports',
    'version': '17.0',
    'license': 'LGPL-3',
    'summary': 'Custom Accounting Reports: General Ledger, Partner Ledger, Profit & Loss',
    'category': 'Accounting',
    'author': 'Areterix Technologies1',
    'website': 'https://www.areterix.com/',
    'depends': ['account', 'web'],
    'data': [
        'security/ir.model.access.csv',

        'data/pdf_paper_format_general_ledger.xml',
        'data/pdf_paper_format_partner_ledger.xml',
        'data/pdf_paper_format_profit_loss.xml',

        # General Ledger first: declares menu_ledgers_parent, menu_partner_reports_parent,
        # menu_statement_reports_parent, which every other report's menu below depends on.
        'views/general_ledger_owl_action.xml',
        'views/general_ledger_pdf_template.xml',
        'views/general_ledger_report_config_views.xml',

        'views/partner_ledger_owl_action.xml',
        'views/partner_ledger_pdf_template.xml',
        'views/partner_ledger_report_config_views.xml',

        'views/profit_loss_owl_action.xml',
        'views/profit_loss_pdf_template.xml',




    ],
    "assets": {
        "web.assets_backend": [
            "gl_pl_reports_aretx/static/src/js/general_ledger_report_owl.js",
            "gl_pl_reports_aretx/static/src/xml/general_ledger_report.xml",
            "gl_pl_reports_aretx/static/src/css/general_ledger_report.css",

            "gl_pl_reports_aretx/static/src/js/partner_ledger_report_owl.js",
            "gl_pl_reports_aretx/static/src/xml/partner_ledger_report.xml",
            "gl_pl_reports_aretx/static/src/css/partner_ledger_report.css",

            "gl_pl_reports_aretx/static/src/js/profit_loss_report_owl.js",
            "gl_pl_reports_aretx/static/src/xml/profit_loss_report.xml",
            "gl_pl_reports_aretx/static/src/css/profit_loss_report.css",




        ],
    },
    'installable': True,
    'application': False,
    'auto_install': False,
}
