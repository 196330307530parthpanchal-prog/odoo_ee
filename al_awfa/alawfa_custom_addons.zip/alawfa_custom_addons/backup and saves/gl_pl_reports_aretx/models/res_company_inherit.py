# models/res_company_inherit.py
from datetime import datetime

import pytz

from odoo import models, api
import logging

_logger = logging.getLogger(__name__)

class ResCompany(models.Model):
    _inherit = "res.company"

    @api.model
    def get_current_company_country(self):
        # Use sudo() to avoid access issues
        company = self.env.company.sudo()
        return {
            "id": company.id,
            "name": company.name,
            # "country_code": company.account_fiscal_country_id.code or False,
            "country_code": company.country_id.code or False,
        }

    @api.model
    def get_current_company_info(self):
        company = self.env.company.sudo()

        return {
            "id": company.id,
            "name": company.name,
            "currency_id": company.currency_id.id,
            "email": company.email or False,
            "phone": company.phone or False,
            "font": company.font,
            "report_header": company.report_header,
            "report_footer": company.report_footer,
            "company_details": company.company_details,
            "logo_web": company.logo_web,
            "currency_name": company.currency_id.name,
            "country_code": company.account_fiscal_country_id.code or False,
            "vat": company.partner_id.vat,
        }
    @api.model
    def get_company_currency(self):
        """Currency of the active company, used by the report screens/PDFs so
        no currency symbol has to be hardcoded."""
        company = self.env.company.sudo()
        currency = company.currency_id
        return {
            "id": currency.id,
            "name": currency.name or "",
            "symbol": currency.symbol or currency.name or "",
            # used by the reports to work out the company's financial year
            "country_code": company.country_id.code or False,
        }

    def _get_report_tz_name(self):
        """Timezone name for report timestamps, derived from the company's
        country (fiscal country first, then company country).

        - one timezone in the country -> that one
        - several timezones -> the company partner's tz if it belongs to that
          country, otherwise the country's first timezone
        - no country set -> company partner tz, then user tz, then UTC
        """
        self.ensure_one()
        country = self.account_fiscal_country_id or self.country_id
        code = (country.code or "").upper() if country else ""
        tz_names = pytz.country_timezones[code] if code in pytz.country_timezones else []
        if len(tz_names) == 1:
            return tz_names[0]
        if tz_names:
            partner_tz = self.partner_id.tz
            return partner_tz if partner_tz in tz_names else tz_names[0]
        return self.partner_id.tz or self.env.user.tz or "UTC"

    @api.model
    def get_report_generated_on(self):
        """Current date/time in the active company's country timezone, as
        'YYYY-MM-DD HH:MM:SS', for the 'Generated on' line of the PDFs."""
        company = self.env.company.sudo()
        try:
            tz = pytz.timezone(company._get_report_tz_name())
        except Exception:
            tz = pytz.utc
        now = datetime.now(pytz.utc).astimezone(tz)
        return now.strftime("%Y-%m-%d %H:%M:%S")