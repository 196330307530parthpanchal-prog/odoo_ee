from odoo import api, models
from datetime import datetime
from dateutil.relativedelta import relativedelta


import logging
_logger = logging.getLogger(__name__)


class ProfitLossReport(models.AbstractModel):
    _name = "profit.loss.report"
    _description = "Profit & Loss Report"


    # ------------------------------------------------------------------
    # Odoo 17 Profit & Loss structure
    #
    #   Net Profit
    #   Income
    #     Gross Profit
    #       Operating Income      (account type: income)
    #       Cost of Revenue       (account type: expense_direct_cost)
    #     Total Gross Profit      = Operating Income - Cost of Revenue
    #     Other Income            (account type: income_other)
    #   Total Income              = Total Gross Profit + Other Income
    #   Expenses
    #     Expenses                (account type: expense)
    #     Depreciation            (account type: expense_depreciation)
    #   Total Expenses            = Expenses + Depreciation
    #
    #   Net Profit = Total Income - Total Expenses
    #
    # Income accounts are credit-normal, so they are shown as -balance;
    # expense accounts are debit-normal, so they are shown as +balance.
    # Every figure keeps its real sign (no abs()), e.g. a refund larger than
    # the sales reduces income instead of adding to it.
    # ------------------------------------------------------------------
    _PL_SECTIONS = [
        # key, label, account_type, sign applied to the (debit - credit) balance
        ("operating_income", "Operating Income", "income", -1),
        ("cost_of_revenue", "Cost of Revenue", "expense_direct_cost", 1),
        ("other_income", "Other Income", "income_other", -1),
        ("expenses", "Expenses", "expense", 1),
        ("depreciation", "Depreciation", "expense_depreciation", 1),
    ]

    @api.model
    def get_profit_loss_data(
        self,
        date_from=False,
        date_to=False,
        comparison_type="none",
        comparison_periods=1,
        date_type="year",
        comparison_date_from=False,
        comparison_date_to=False):

        period_columns = self._build_period_columns(
            date_from,
            date_to,
            comparison_type,
            comparison_periods,
            date_type,
            comparison_date_from,
            comparison_date_to,
        )
        period_keys = [period["key"] for period in period_columns]
        currency = self.env.company.currency_id

        section_by_type = {
            account_type: (key, sign)
            for key, _label, account_type, sign in self._PL_SECTIONS
        }

        accounts = self.env["account.account"].search(
            [("account_type", "in", list(section_by_type))],
            order="code,name",
        )

        # --- Posted balance (debit - credit) per account, one query per period ---
        move_line = self.env["account.move.line"]
        balances_by_period = {}
        for period in period_columns:
            domain = [
                ("parent_state", "=", "posted"),
                ("account_id", "in", accounts.ids),
            ]
            if period.get("date_from"):
                domain.append(("date", ">=", period["date_from"]))
            if period.get("date_to"):
                domain.append(("date", "<=", period["date_to"]))

            groups = move_line.read_group(
                domain, ["balance:sum"], ["account_id"], lazy=False
            )
            balances_by_period[period["key"]] = {
                group["account_id"][0]: group["balance"]
                for group in groups
                if group.get("account_id")
            }

        # --- Accounts per section, with a correctly signed balance per period ---
        sections = {
            key: {
                "name": label,
                "children": [],
                "totals": dict.fromkeys(period_keys, 0.0),
            }
            for key, label, _account_type, _sign in self._PL_SECTIONS
        }

        for account in accounts:
            key, sign = section_by_type[account.account_type]

            balances = {
                period_key: currency.round(
                    sign * balances_by_period[period_key].get(account.id, 0.0)
                ) or 0.0
                for period_key in period_keys
            }

            if not any(balances.values()):
                continue

            sections[key]["children"].append({
                "id": account.id,
                "code": account.code or "",
                "name": f"{account.code or ''} {account.name}".strip(),
                "balances": balances,
            })

            for period_key in period_keys:
                sections[key]["totals"][period_key] += balances[period_key]

        for section in sections.values():
            section["totals"] = {
                period_key: currency.round(value) or 0.0
                for period_key, value in section["totals"].items()
            }

        # --- Totals per period (single source of truth for screen, PDF and XLSX) ---
        totals = {}
        for period_key in period_keys:
            operating_income = sections["operating_income"]["totals"][period_key]
            cost_of_revenue = sections["cost_of_revenue"]["totals"][period_key]
            other_income = sections["other_income"]["totals"][period_key]
            expenses = sections["expenses"]["totals"][period_key]
            depreciation = sections["depreciation"]["totals"][period_key]

            gross_profit = operating_income - cost_of_revenue
            total_income = gross_profit + other_income
            total_expenses = expenses + depreciation
            net_profit = total_income - total_expenses

            totals[period_key] = {
                name: currency.round(value) or 0.0
                for name, value in {
                    "operating_income": operating_income,
                    "cost_of_revenue": cost_of_revenue,
                    "gross_profit": gross_profit,
                    "other_income": other_income,
                    "total_income": total_income,
                    "expenses": expenses,
                    "depreciation": depreciation,
                    "total_expenses": total_expenses,
                    "net_profit": net_profit,
                }.items()
            }

        return {
            "period_columns": period_columns,
            "sections": sections,
            "totals": totals,
            "lines": self._build_profit_loss_lines(sections, totals, period_keys),
        }

    @api.model
    def _build_profit_loss_lines(self, sections, totals, period_keys):
        """Flat, ordered list of report rows in the Odoo 17 layout.

        kind: total | section | label | group | account | subtotal
        group / account / subtotal rows carry the section key in 'group', so the
        screen can collapse them; PDF and XLSX simply print every row.
        """
        lines = []

        def add(line_id, kind, label, level, values=None,
                group=False, account_id=False, has_children=False):
            lines.append({
                "id": line_id,
                "kind": kind,
                "label": label,
                "level": level,
                "values": values or {},
                "group": group,
                "account_id": account_id,
                "has_children": has_children,
            })

        def total_line(line_id, label, level, total_key):
            add(line_id, "total", label, level, {
                period_key: totals[period_key][total_key]
                for period_key in period_keys
            })

        def group_lines(key, label, level):
            section = sections[key]
            children = section["children"]
            add(f"group_{key}", "group", label, level,
                dict(section["totals"]), group=key,
                has_children=bool(children))
            for child in children:
                add(f"account_{key}_{child['id']}", "account", child["name"],
                    level + 1, dict(child["balances"]), group=key,
                    account_id=child["id"])
            if children:
                add(f"subtotal_{key}", "subtotal", f"Total {label}", level,
                    dict(section["totals"]), group=key)

        total_line("net_profit", "Net Profit", 0, "net_profit")

        add("section_income", "section", "Income", 0)
        add("label_gross_profit", "label", "Gross Profit", 1)
        group_lines("operating_income", "Operating Income", 2)
        group_lines("cost_of_revenue", "Cost of Revenue", 2)
        total_line("gross_profit", "Total Gross Profit", 1, "gross_profit")
        group_lines("other_income", "Other Income", 1)
        total_line("total_income", "Total Income", 0, "total_income")

        add("section_expenses", "section", "Expenses", 0)
        group_lines("expenses", "Expenses", 1)
        group_lines("depreciation", "Depreciation", 1)
        total_line("total_expenses", "Total Expenses", 0, "total_expenses")

        return lines

    def _build_period_columns(
        self,
        date_from,
        date_to,
        comparison_type,
        comparison_periods,
        date_type,
        comparison_date_from=False,
        comparison_date_to=False,
    ):
        

        columns = []

        start_date = datetime.strptime(
            date_from,
            "%Y-%m-%d"
        )

        end_date = datetime.strptime(
            date_to,
            "%Y-%m-%d"
        )
        
        date_type = (date_type or "").lower()

        _logger.warning(
            "BUILD COLUMN => comparison=%s, date_type=%s",
            comparison_type,
            date_type
        )
        
        if date_type == "month":

            current_label = start_date.strftime("%b %Y")
        
        elif date_type == "quarter":
        
            current_label = (
                f"{start_date.strftime('%b')} - "
                f"{end_date.strftime('%b %Y')}"
            )
        
        elif date_type == "custom":
        
            current_label = (
                f"{start_date.strftime('%d-%m-%Y')} - "
                f"{end_date.strftime('%d-%m-%Y')}"
            )
        
        else:
        
            current_label = str(start_date.year)

        _logger.warning(
            "CURRENT LABEL = %s",
            current_label
        )

        columns.append({
            "key": "current",
            "label": current_label,
            "date_from": date_from,
            "date_to": date_to,
        })


        periods = int(comparison_periods or 0)

        if comparison_type == "previous_period":

            for i in range(1, periods + 1):
            
                if date_type == "month":
                
                    prev_start = (
                        start_date
                        - relativedelta(months=i)
                    )
        
                    prev_end = (
                        end_date
                        - relativedelta(months=i)
                    )
        
                    period_label = prev_start.strftime(
                        "%b %Y"
                    )
        
                elif date_type == "quarter":
                
                    prev_start = (
                        start_date
                        - relativedelta(months=i * 3)
                    )
        
                    prev_end = (
                        end_date
                        - relativedelta(months=i * 3)
                    )
        
                    period_label = (
                        f"{prev_start.strftime('%b')} - "
                        f"{prev_end.strftime('%b %Y')}"
                    )
    
                
                elif date_type == "custom":

                    prev_start = (
                        start_date
                        - relativedelta(months=i)
                    )

                    prev_end = (
                        end_date
                        - relativedelta(months=i)
                    )

                    period_label = prev_start.strftime("%b %y")

                else:
                
                    prev_start = (
                        start_date
                        - relativedelta(years=i)
                    )

                    prev_end = (
                        end_date
                        - relativedelta(years=i)
                    )

                    period_label = str(prev_start.year)
        
                columns.append({
                    "key": f"period_{i}",
                    "label": period_label,
                    "date_from": prev_start.strftime("%Y-%m-%d"),
                    "date_to": prev_end.strftime("%Y-%m-%d"),
                })

        elif comparison_type == "previous_year":

            for i in range(1, periods + 1):

                prev_start = (
                    start_date
                    - relativedelta(years=i)
                )

                prev_end = (
                    end_date
                    - relativedelta(years=i)
                )

                if date_type == "quarter":

                    year_label = (
                        f"{prev_start.strftime('%b')} - "
                        f"{prev_end.strftime('%b %Y')}"
                    )
                
                elif date_type == "month":
                
                    year_label = prev_start.strftime("%b %Y")

                elif date_type == "custom":

                    year_label = (
                        f"{prev_start.strftime('%d-%m-%Y')} - "
                        f"{prev_end.strftime('%d-%m-%Y')}"
                    )
                
                else:
                
                    year_label = (
                        f"{prev_start.year}"
                    )
                
                columns.append({
                    "key": f"year_{i}",
                    "label": year_label,
                    "date_from": prev_start.strftime("%Y-%m-%d"),
                    "date_to": prev_end.strftime("%Y-%m-%d"),
                })

        elif comparison_type == "custom":

            columns.append({
                "key": "custom_compare",
                "label": (
                    f"{datetime.strptime(comparison_date_from, '%Y-%m-%d').strftime('%d-%m-%Y')}"
                    f" - "
                    f"{datetime.strptime(comparison_date_to, '%Y-%m-%d').strftime('%d-%m-%Y')}"
                ),
                "date_from": comparison_date_from,
                "date_to": comparison_date_to,
            })

        _logger.warning(
            "COLUMN => %s",
            columns
        )


        return columns