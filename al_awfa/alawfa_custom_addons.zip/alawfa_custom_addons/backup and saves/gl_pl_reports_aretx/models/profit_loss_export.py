import base64
from urllib.parse import quote
import io
import xlsxwriter
import re
from datetime import datetime
from odoo import models, api

import logging
_logger = logging.getLogger(__name__)


class ProfitLossExport(models.TransientModel):
    _name = 'profit.loss.export'
    _description = 'Profit Loss Export'

    def format_currency_helper(self, amount, currency_symbol=None, precision=2):
        if currency_symbol is None:
            currency_symbol = self.env.company.currency_id.symbol
        if currency_symbol and currency_symbol != 'False':
            return f"{currency_symbol} {amount:,.{precision}f}"
        return f"{amount:,.{precision}f}"

    def _generate_pl_filename(self, data, file_ext="pdf"):
        _logger.info(f"Called filename function for {file_ext}")
        start_date = data.get('date_from')
        end_date = data.get('date_to')
        month = data.get('month')
        quarter = data.get('quarter')
        year = data.get('year')

        search_text = data.get('search_text', '').strip()
        search_prefix = ""
        if search_text:
            sanitized_text = search_text.replace(' ', '_').replace('/', '_').replace('\\', '_')
            search_prefix = f"{sanitized_text}_"

        _logger.info(start_date)
        _logger.info(end_date)
        _logger.info(quarter)
        _logger.info(month)
        _logger.info(year)

        filename_core = ""

        # Month + Year
        if month and year:
            date_obj = datetime(int(year), int(month), 1)
            filename_core = date_obj.strftime('%b_%Y')

        # Quarter + Year
        elif quarter and year:
            quarter_map = {
                "q1": "Jan_Mar",
                "q2": "Apr_Jun",
                "q3": "Jul_Sep",
                "q4": "Oct_Dec"
            }
            quarter_range = quarter_map.get(quarter.lower(), quarter.lower())
            filename_core = f"{quarter_range}_{year}"

        # Only Year
        elif year and not month and not quarter:
            filename_core = f"{year}"

        # Date range
        elif start_date and end_date:
            start_str = datetime.strptime(start_date, "%Y-%m-%d").strftime("%d%m%Y")
            end_str = datetime.strptime(end_date, "%Y-%m-%d").strftime("%d%m%Y")
            filename_core = f"{start_str}_{end_str}"

        # Default (timestamp)
        else:
            filename_core = datetime.now().strftime('%Y%m%d_%H%M%S')

        filename = f"profit_loss_{search_prefix}{filename_core}.{file_ext}"

        filename = filename.replace('__', '_')

        _logger.info(filename)
        return filename


    def get_period_text(self, data):
        date_from = data.get("date_from")
        date_to = data.get("date_to")

        if date_from and date_to:
            try:
                from_str = datetime.strptime(date_from, "%Y-%m-%d").strftime("%d %b %Y")
                to_str = datetime.strptime(date_to, "%Y-%m-%d").strftime("%d %b %Y")
                _logger.info(f"Period: From {from_str} To {to_str}")
                return f"Period: From {from_str} To {to_str}"
            except Exception as e:
                _logger.error(f"Error generating Period Text: {str(e)}")

        # Fallback if dates are missing or parsing fails
        return f"Period: {data.get('filter_title', 'All Records')}"

    @api.model
    def export_profit_loss_pdf(self, data):
        """Export Profit Loss to PDF using Odoo QWeb template"""


        # PDF supports maximum 5 period columns
        if data.get("period_columns"):
        
            data["period_columns"] = (
                data["period_columns"][:5]
            )

        data['currency_symbol'] = self.env.company.currency_id.symbol
        data['generated_on'] = self.env['res.company'].get_report_generated_on()

        filename = self._generate_pl_filename(data,file_ext="pdf")

        report_ref = 'gl_pl_reports_aretx.profit_loss_pdf_export'

        try:
            # Odoo 17 signature: _render_qweb_pdf(report_ref, res_ids=None, data=None)
            pdf_content, _ = self.env['ir.actions.report']._render_qweb_pdf(
                report_ref, res_ids=None, data={'data': data}
            )

            attachment = self.env['ir.attachment'].create({
                'name': filename,
                'type': 'binary',
                'datas': base64.b64encode(pdf_content),
                'mimetype': 'application/pdf',
            })
            # "filename" makes the browser save the file under the right name
            return {
                'type': 'ir.actions.act_url',
                'url': f'/web/content/{attachment.id}?download=true&filename={quote(filename)}',
                'target': 'self',
            }
        except Exception:
            # Keep the real reason in the server log instead of hiding it
            _logger.exception("PDF export failed, using the report action instead")
            return {
                'type': 'ir.actions.report',
                # must be the report_name of the ir.actions.report record
                'report_name': 'gl_pl_reports_aretx.profit_loss_pdf_export_template',
                'data': {'data': data},
                'report_type': 'qweb-pdf',
            }

    @api.model
    def export_profit_loss_xlsx(self, data):
        data['format_currency'] = self.format_currency_helper
        collapsed_accounts = data.get('collapsed_accounts', {})

        for account_id, account in data.get('sections', {}).items():
        
            if collapsed_accounts.get(str(account_id), False):
                account['lines'] = []

        try:
            output = io.BytesIO()
            workbook = xlsxwriter.Workbook(output, {'in_memory': True})
            worksheet = workbook.add_worksheet('Profit Loss')

            # Enhanced formatting
            header_format = workbook.add_format({
                'bold': True,
                'bg_color': '#D3D3D3',
                'border': 1,
                'align': 'center',
                'valign': 'vcenter',
                'font_size': 11
            })
            number_format = workbook.add_format({
                'num_format': '#,##0.00',
                'border': 1,
                'align': 'right',
                'valign': 'vcenter'
            })
            text_format = workbook.add_format({
                'border': 1,
                'align': 'left',
                'valign': 'vcenter',
                'text_wrap': True
            })
            journal_format = workbook.add_format({
                'border': 1,
                'align': 'left',
                'valign': 'vcenter',
                'text_wrap': False
            })
            title_format = workbook.add_format({
                'bold': True,
                'align': 'center',
                'font_size': 16,
                'bg_color': '#4F81BD',
                'font_color': 'white'
            })
            account_format = workbook.add_format({
                'bold': True,
                'bg_color': '#F0F8FF',
                'border': 1,
                'align': 'left',
                'valign': 'vcenter'
            })

            gross_label_format = workbook.add_format({
                'bold': True,
                'bg_color': '#D9D9D9',
                'border': 1,
                'align': 'left',
            })

            operating_label_format = workbook.add_format({
                'bold': True,
                'bg_color': '#D9D9D9',
                'border': 1,
                'align': 'left',
            })

            net_profit_label_format = workbook.add_format({
                'bold': True,
                'bg_color': '#C0C0C0',
                'border': 1,
                'font_size': 12,
                'align': 'left',
            })

            final_profit_label_format = workbook.add_format({
                'bold': True,
                'bg_color': '#C0C0C0',
                'border': 1,
                'font_size': 12,
                'align': 'left',
            })

            gross_amount_format = workbook.add_format({
                'bold': True,
                'bg_color': '#D9D9D9',
                'border': 1,
                'num_format': '#,##0.00',
                'align': 'right',
            })

            operating_amount_format = workbook.add_format({
                'bold': True,
                'bg_color': '#D9D9D9',
                'border': 1,
                'num_format': '#,##0.00',
                'align': 'right',
            })

            net_profit_amount_format = workbook.add_format({
                'bold': True,
                'bg_color': '#C0C0C0',
                'border': 1,
                'font_size': 12,
                'num_format': '#,##0.00',
                'align': 'right',
            })

            final_profit_amount_format = workbook.add_format({
                'bold': True,
                'bg_color': '#C0C0C0',
                'border': 1,
                'font_size': 12,
                'num_format': '#,##0.00',
                'align': 'right',
            })

            # Set column widths
            worksheet.set_column('A:A', 55)

            for col in range(1, 6):
                worksheet.set_column(col, col, 18)

            period_text = self.get_period_text(data)

            # Title & filter info
            worksheet.merge_range('A1:G1', 'Profit Loss Report', title_format)
            worksheet.merge_range(
                'A2:G2',
                period_text,
                workbook.add_format({'align': 'center','valign' : 'vcenter','font_size': 12, 'italic': True})
                
            )
            worksheet.set_row(0, 25)
            # Add some spacing
            worksheet.set_row(2, 5)  

            row = 4

            period_columns = data.get("period_columns", [])[:5]

            worksheet.write(row, 0, "Particulars", header_format)

            for col, period in enumerate(period_columns, start=1):
            
                worksheet.write(
                    row,
                    col,
                    period.get("label", ""),
                    header_format
                )

            row += 1

            # Rows come from the same list the screen and the PDF use
            # (profit.loss.report -> 'lines'), so all three always agree.
            cell_formats = {}

            def cell_format(bold=False, bar=False, indent=0, amount=False):
                key = (bold, bar, indent, amount)
                if key not in cell_formats:
                    props = {'border': 1, 'valign': 'vcenter'}
                    if bold or bar:
                        props['bold'] = True
                    if bar:
                        props['bg_color'] = '#D9D9D9'
                    if amount:
                        props.update({'num_format': '#,##0.00', 'align': 'right'})
                    else:
                        props.update({'align': 'left', 'indent': indent})
                    cell_formats[key] = workbook.add_format(props)
                return cell_formats[key]

            for line in data.get('lines', []):
                kind = line.get('kind')
                has_children = bool(line.get('has_children'))
                is_bar = kind == 'section' or line.get('id') == 'net_profit'
                is_bold = (
                    kind in ('total', 'subtotal', 'section', 'label')
                    or (kind == 'group' and has_children)
                )
                show_amount = not (
                    kind in ('section', 'label')
                    or (kind == 'group' and has_children)
                )

                worksheet.write(
                    row,
                    0,
                    line.get('label', ''),
                    cell_format(is_bold, is_bar, line.get('level', 0)),
                )

                for col, period in enumerate(period_columns, start=1):
                    if show_amount:
                        worksheet.write_number(
                            row,
                            col,
                            (line.get('values') or {}).get(period['key'], 0) or 0,
                            cell_format(is_bold, is_bar, 0, True),
                        )
                    else:
                        worksheet.write_blank(
                            row, col, '', cell_format(is_bold, is_bar, 0, True)
                        )

                row += 1

                if line.get('id') == 'total_income':
                    row += 1  # blank spacer row, like the screen

            workbook.close()
            content = output.getvalue()

            # filename = f"General_Ledger_{data.get('filter_title', 'Report')}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
            filename = self._generate_pl_filename(data, file_ext="xlsx")

            attachment = self.env['ir.attachment'].create({
                'name': filename,
                'type': 'binary',
                'datas': base64.b64encode(content),
                'store_fname': filename,
                'mimetype': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
            })
            return {
                'type': 'ir.actions.act_url',
                'url': f'/web/content/{attachment.id}?download=true',
                'target': 'self'
            }

        except Exception as e:
            # Log the error and return user-friendly message

            _logger.error(f"Error exporting Profit Loss to XLSX: {str(e)}")

            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'message': f'Error exporting to Excel: {str(e)}',
                    'type': 'danger',
                    'sticky': False,
                }
            }