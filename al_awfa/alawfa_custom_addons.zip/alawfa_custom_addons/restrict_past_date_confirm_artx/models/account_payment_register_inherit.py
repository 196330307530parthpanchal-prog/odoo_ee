

from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import date

class AccountPaymentRegister(models.TransientModel):
    _inherit = 'account.payment.register'

    def _check_backdate_restriction(self):
        if self.env.user.has_group('base.group_system'):
            return

        today = date.today()

        for rec in self:
            if rec.payment_date and rec.payment_date < today:
                raise UserError(
                    "Backdated payments are not allowed.\n"
                    "Only today's date is permitted."
                )

    def action_create_payments(self):
        # Validate BEFORE payment creation
        self._check_backdate_restriction()

        return super().action_create_payments()