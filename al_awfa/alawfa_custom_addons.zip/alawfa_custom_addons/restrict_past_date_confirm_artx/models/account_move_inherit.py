from odoo import models, fields, api,_
from odoo.exceptions import UserError
from datetime import datetime, timedelta

class AccountMove(models.Model):
    _inherit = 'account.move'

    def action_post(self):
        for invoice in self:
            if not invoice.invoice_reference:
                raise UserError(_("The document cannot be confirmed without invoice reference."))
            if not invoice.invoice_date:
                # if invoice.is_sale_document(include_receipts=True):
                #     invoice.invoice_date = fields.Date.context_today(self)
                if invoice.move_type == 'in_invoice':
                    print("purchase document")
                    invoice.invoice_date = fields.Date.context_today(self)
                    # raise UserError(_("The Bill/Refund date is required to validate this document."))
        res = super().action_post()
        for invoice in self:
            if invoice.move_type == 'in_invoice':
                if not invoice.payment_reference:
                    invoice.payment_reference = invoice.name
        print("CREATI")
        self._check_invoice_date()

        return res

    def _check_invoice_date(self):
        print("checking invoice date")
        invoices = self.filtered(lambda m: m.move_type in ('in_invoice','out_invoice', 'out_refund','in_refund'))
        for m in self:
            print(m.move_type)
        if not invoices:
            return

        user = self.env.user
        driver_group = self.env.ref('delivery_app_artx.group_driver')
        salesman_group = self.env.ref('delivery_app_artx.group_sale_last_month')
        admin = self.env.ref('base.group_system')

        # if not (driver_group in user.groups_id or salesman_group in user.groups_id):
        #     return
        if admin in user.groups_id:     # skipping this validation for admin
            return

        allowed_days = 0   #no relaxation, change here to add days of delay
        today = fields.Date.context_today(self)
        invalid_invoices = []

        for invoice in invoices:
            invoice_date = invoice.invoice_date or today
            working_days = self._get_working_days(invoice_date, today)
            print(invoice_date, working_days)
            if working_days > allowed_days:
                invalid_invoices.append(invoice.name)

        if invalid_invoices:
            print("invalid invoice")
            raise UserError(_(f"You can only backdate invoices up to {allowed_days} working days. Invalid invoices: %s") % ', '.join(
                invalid_invoices))

    def _get_working_days(self, from_date, to_date):
        # from_date <= to_date
        working_days = 0
        current_date = fields.Date.from_string(from_date)
        end_date = fields.Date.from_string(to_date)
        while current_date < end_date:
            current_date += timedelta(days=1)
            if current_date.weekday() < 5:  # Monday=0, Sunday=6
                working_days += 1
        return working_days

    def _compute_show_reset_to_draft_button(self):
        # EXTENDS account_edi account.move
        super()._compute_show_reset_to_draft_button()

        for move in self:
            if not self.env.user.has_group('base.group_system'):
                move.show_reset_to_draft_button = False
