from . import account_move_inherit
from . import account_payment_register_inherit
from . import purchase_order_inherit
from . import sale_order_inherit