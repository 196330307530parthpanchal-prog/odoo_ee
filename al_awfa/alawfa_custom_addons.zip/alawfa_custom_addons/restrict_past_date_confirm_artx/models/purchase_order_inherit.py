from odoo import models, api
from odoo.exceptions import UserError
from odoo.fields import Date


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    def _check_backdate_restriction(self):
        if self.env.user.has_group('base.group_system'):
            return

        today = Date.context_today(self)

        for rec in self:
            if rec.date_order:
                order_date = rec.date_order.date()

                if order_date < today:
                    raise UserError(
                        "Backdated Purchase Orders are not allowed.\n"
                        "Only today's date is permitted."
                    )

    def button_confirm(self):
        self._check_backdate_restriction()
        return super().button_confirm()