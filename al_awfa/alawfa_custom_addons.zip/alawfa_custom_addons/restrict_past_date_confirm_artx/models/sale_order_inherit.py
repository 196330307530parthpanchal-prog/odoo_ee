from odoo import models, api, fields, _
from odoo.exceptions import UserError
from odoo.fields import Date


class SaleOrder(models.Model):
    _inherit = 'sale.order'

    def _check_backdate_restriction(self):
        if self.env.user.has_group('base.group_system'):
            return

        today = Date.context_today(self)

        for rec in self:
            if rec.date_order:
                # order_date = rec.date_order.date()  # datetime → date
                local_dt = fields.Datetime.context_timestamp(rec, rec.date_order)
                order_date = local_dt.date()

                if order_date < today:
                    raise UserError(
                        f"Backdated Sales Orders are not allowed.\nYou can only use today's date.\n"
                        # f"The date in order is : {order_date} and current : {today}.{local_dt}"
                    )
                # else:
                #     raise UserError(f"SUCCESS\n The date in order is : {order_date} and current : {today}.{local_dt}")

    def action_confirm(self):
        self._check_backdate_restriction()
        return super().action_confirm()