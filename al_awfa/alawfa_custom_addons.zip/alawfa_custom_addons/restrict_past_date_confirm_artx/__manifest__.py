{
    "name": "Areterix Restrict SO/PO invoice/bills confirmation of past date",
    "author": "Manav Fitter",
    "license": "LGPL-3",
    "verion": "17.0.1.1",
    "depends": [
        'delivery_app_artx',
        'base',
        'web',
        'base_automation',
        'mail',
        'product',
        'sale',
        'sale_management',
        'uom',
        'purchase',
        'account',
        'stock',
    ],
    "data": [

    ],
    # 'assets': {
    #     'web.assets_backend': [
    #         'delivery_app_artx/static/src/**/*.js',
    #         'delivery_app_artx/static/src/**/*.xml',
    #         "delivery_app_artx/static/lib/xlsx.full.min.js",
    #         "delivery_app_artx/static/src/scss/import_excel.scss"
    #         "delivery_app_artx/static/src/view/fields/hover_summary_field.js"
    #         "delivery_app_artx/static/src/view/fields/hover_summary_field.xml"
    #     ],
    # },
    'sequence': 1,
    'installable': True,
    'application': False,
    'auto_install': False,
}