/** @odoo-module **/

// The patch lets us add face verification before Odoo's existing check-in/out action.
import { ActivityMenu } from "@hr_attendance/components/attendance_menu/attendance_menu";
import { patch } from "@web/core/utils/patch";

// Location of the face-api library and model files in this module.
const LIB_URL = "/portal_attendance_face_recog_aretx/static/lib/face-api/";


const DETECT_INTERVAL_MS = 3000;    // Wait 3 seconds between face-detection attempts.


const FACE_HITS_REQUIRED = 3;     // Require this many consecutive successful detections before continuing.


let detectorPromise;

// Small reusable delay for the detection loop.
function sleep(ms) {
    return new Promise((resolve) => setTimeout(resolve, ms));
}

// Load face-api and its tiny face detector model the first time verification is needed.
function loadDetector() {
    if (!detectorPromise) {
        detectorPromise = (async () => {
            // Load the library script if it is not already available on the page.
            if (!window.faceapi) {
                await new Promise((resolve, reject) => {
                    const script = document.createElement("script");
                    script.src = LIB_URL + "face-api.js";
                    script.onload = resolve;
                    script.onerror = () => reject(new Error("Could not load the face detector."));
                    document.head.appendChild(script);
                });
            }

            // Prefer WebGL for inference, with CPU as a fallback.
            const faceapi = window.faceapi;
            let webglAvailable = false;

            try {
                webglAvailable = await faceapi.tf.setBackend("webgl");
            } catch {
                webglAvailable = false;
            }

            if (!webglAvailable) {
                await faceapi.tf.setBackend("cpu");
            }

            // Wait for TensorFlow.js and load the face-detection model.
            await faceapi.tf.ready();
            await faceapi.nets.tinyFaceDetector.loadFromUri(LIB_URL + "model");
        })();

        // Allow a later attempt if loading failed.
        detectorPromise.catch(() => {
            detectorPromise = null;
        });
    }

    return detectorPromise;
}

// Show the camera and keep scanning until a face is detected enough times
// or the user cancels. Returns true only after successful verification.
async function verifyFace() {
    if (!navigator.mediaDevices?.getUserMedia) {
        throw new Error("Camera access is unavailable. Use HTTPS and a supported browser.");
    }

    // Build a lightweight camera dialog dynamically, so no separate template is needed.
    const overlay = document.createElement("div");
    overlay.setAttribute("role", "dialog");
    overlay.setAttribute("aria-modal", "true");
    overlay.style.cssText =
        "position:fixed;inset:0;z-index:20000;background:rgba(0,0,0,.65);" +
        "display:flex;align-items:center;justify-content:center;padding:16px;";

    const panel = document.createElement("div");
    panel.style.cssText =
        "background:#fff;border-radius:8px;padding:20px;width:100%;max-width:440px;" +
        "text-align:center;box-shadow:0 4px 20px rgba(0,0,0,.3);";

    const title = document.createElement("h3");
    title.textContent = "Face verification";

    // Live camera preview. Mirroring makes it behave like a typical selfie view.
    const video = document.createElement("video");
    video.autoplay = true;
    video.playsInline = true;
    video.muted = true;
    video.style.cssText =
        "display:block;width:100%;max-height:60vh;object-fit:contain;" +
        "border-radius:8px;transform:scaleX(-1);";

    // Status text is updated while opening the camera and scanning.
    const message = document.createElement("p");
    message.textContent = "Starting camera...";
    message.style.margin = "12px 0";

    // Cancelling closes the dialog and prevents Odoo's attendance action from running.
    const cancelButton = document.createElement("button");
    cancelButton.type = "button";
    cancelButton.className = "btn btn-secondary";
    cancelButton.textContent = "Cancel";

    panel.append(title, video, message, cancelButton);
    overlay.appendChild(panel);
    document.body.appendChild(overlay);

    let cancelled = false;
    let stream = null;

    const cancel = () => {
        cancelled = true;
    };
    const onKeyDown = (event) => {
        if (event.key === "Escape") {
            cancel();
        }
    };

    cancelButton.addEventListener("click", cancel);
    document.addEventListener("keydown", onKeyDown);

    try {
        // Request camera access. Audio is not needed for face detection.
        const media = await navigator.mediaDevices.getUserMedia({
            video: { facingMode: "user" },
            audio: false,
        });

        // If the user cancelled while the browser was asking for camera permission,
        // stop the newly opened camera immediately.
        if (cancelled) {
            media.getTracks().forEach((track) => track.stop());
            return false;
        }

        stream = media;
        video.srcObject = stream;
        await video.play();

        // Wait briefly for the camera to provide usable video frames.
        const videoWaitStarted = Date.now();
        while (video.readyState < 2 && Date.now() - videoWaitStarted < 10000) {
            if (cancelled) {
                return false;
            }
            await sleep(100);
        }

        if (cancelled) {
            return false;
        }
        if (video.readyState < 2) {
            throw new Error("The camera did not start. Please try again.");
        }

        // Load the face model after the camera is ready.
        message.textContent = "Loading face detector...";
        await loadDetector();

        const faceapi = window.faceapi;
        const options = new faceapi.TinyFaceDetectorOptions({
            inputSize: 224,
            scoreThreshold: 0.5,
        });
        let hits = 0;

        // Scan repeatedly. A missed detection resets the consecutive-hit count.
        message.textContent = "Looking for your face...";
        // Keep trying batches until three consecutive detections succeed or the user cancels.
        while (!cancelled) {
            let hits = 0;
        
            for (let attempt = 0; attempt < FACE_HITS_REQUIRED; attempt++) {
                if (cancelled) {
                    return false;
                }
            
                message.textContent = `Scanning...`;
                await sleep(1000);
            
                if (cancelled) {
                    return false;
                }
            
                const face = await faceapi.detectSingleFace(video, options);
            
                if (!face) {
                    message.textContent = "No face detected. Please look at the camera.";
                    break;
                }
            
                hits += 1;
                message.textContent =
                    hits < FACE_HITS_REQUIRED
                        ? "Face detected. Hold still..."
                        : "Face verified. Continuing attendance...";
            }
        
            if (hits === FACE_HITS_REQUIRED) {
                return true;
            }
        }

        return false;
    } finally {
        // Always turn off the camera and remove the dialog, including on errors.
        if (stream) {
            stream.getTracks().forEach((track) => track.stop());
        }
        video.srcObject = null;
        document.removeEventListener("keydown", onKeyDown);
        overlay.remove();
    }
}

// Add a verification step before Odoo's built-in check-in/out action.
// If verification is cancelled or fails, the original action is not called.
patch(ActivityMenu.prototype, {
    async signInOut(...args) {
        // Prevent repeated clicks from opening multiple camera dialogs.
        if (this.paFaceCheckRunning || this.state.gettingPosition) {
            return;
        }

        this.paFaceCheckRunning = true;

        try {
            const faceVerified = await verifyFace();
            if (!faceVerified) {
                return;
            }

            // Run Odoo's original method unchanged after verification.
            // This preserves Odoo's normal attendance recording and counter refresh.
            return await super.signInOut(...args);
        } catch (error) {
            // Tell the user why verification failed; do not record attendance.
            this.notification.add(
                error.message || "Face verification failed. Attendance was not recorded.",
                { type: "danger" }
            );
        } finally {
            // Allow another attempt whether verification succeeded, failed, or was cancelled.
            this.paFaceCheckRunning = false;
        }
    },
});