from odoo import http
from odoo.http import request

from .ess_access import ess_required


class PortalPlannedActivities(http.Controller):

    @http.route('/my/planned_activities', type='http', auth='user', website=True)
    @ess_required
    def portal_planned_activities(self, **kwargs):
        """Read-only list of the planned activities on the logged-in employee's own record."""
        employee = request.env['hr.employee'].sudo().search([('user_id', '=', request.env.user.id)], limit=1)
        # Same activities the chatter shows under 'Planned Activities' - only for the
        # employee linked to the logged-in user, so nobody else's record is ever read.
        activities = request.env['mail.activity'].sudo().search([
            ('res_model', '=', 'hr.employee'),
            ('res_id', '=', employee.id),
            ('user_id', '=', request.env.user.id),
        ], order='date_deadline asc, id asc') if employee else request.env['mail.activity']
        return request.render('pharma_portal_timeoff_aretx.portal_planned_activities_template', {
            'page_name': 'planned_activities',
            'activities': activities,
        })  